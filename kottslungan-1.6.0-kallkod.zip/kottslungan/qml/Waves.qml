// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// En rad vågtoppar som sakta rör sig åt sidan och gungar lite upp och ned.
Item {
    id: waves
    property real tile: height * 4
    property int duration: 4000
    property bool running: true
    clip: true
    Item {
        id: row
        height: waves.height
        width: waves.width + waves.tile
        property real phase: 0
        x: -phase * waves.tile
        y: Math.sin(phase * 2 * Math.PI) * waves.height * 0.12
        Image {
            anchors.fill: parent
            source: "../assets/waves.svg"
            fillMode: Image.Tile
            sourceSize: Qt.size(Math.max(8, Math.round(waves.tile)), Math.max(2, Math.round(waves.height)))
        }
        NumberAnimation on phase { from: 0; to: 1; duration: waves.duration; loops: Animation.Infinite; running: waves.running }
    }
}
