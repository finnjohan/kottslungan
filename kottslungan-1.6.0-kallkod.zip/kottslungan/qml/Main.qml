// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Storage.js" as Storage
import "Levels.js" as Levels
import "I18n.js" as I18n

MainView {
    id: root
    objectName: "mainView"
    applicationName: "kottslunga"
    automaticOrientation: false

    width: units.gu(argValue("width") !== "" ? parseInt(argValue("width"), 10) : 90)
    height: units.gu(argValue("height") !== "" ? parseInt(argValue("height"), 10) : 45)

    readonly property string version: "1.6.0"
    readonly property bool isDark: theme.palette.normal.background.hslLightness < 0.5

    // ---- Kommandoradsflaggor för test och skärmdumpar ---------------------
    // --demo (egen databas med några klarade banor)  --lang=sv|en  --theme=light|dark
    // --page=levels|game|settings  --level=<n>  --width=<gu>  --height=<gu>  --mute
    function argValue(name) {
        var args = Qt.application.arguments
        for (var i = 0; i < args.length; i++) {
            if (args[i] === "--" + name) return "1"
            if (args[i].indexOf("--" + name + "=") === 0) return args[i].substring(name.length + 3)
        }
        return ""
    }
    readonly property bool demo: argValue("demo") !== ""

    // ---- Inställningar --------------------------------------------------
    property string themeSetting: "auto"
    property string langSetting: "auto"
    property bool ambienceOn: true
    property bool effectsOn: true
    readonly property string lang: langSetting === "auto" ? I18n.systemLanguage(Qt.locale().name) : langSetting

    function tr(s) { return I18n.tr(s, lang) }

    function setTheme(value) { themeSetting = value; Storage.setSetting("theme", value); applyTheme() }
    function setLanguage(value) { langSetting = value; Storage.setSetting("language", value) }
    function setAmbience(on) { ambienceOn = on; Storage.setSetting("ambience", on ? "1" : "0") }
    function setEffects(on) { effectsOn = on; Storage.setSetting("effects", on ? "1" : "0") }
    function playSound(name) { sounds.play(name) }

    function applyTheme() {
        if (themeSetting === "dark") theme.name = "Lomiri.Components.Themes.SuruDark"
        else if (themeSetting === "light") theme.name = "Lomiri.Components.Themes.Ambiance"
        else theme.name = ""
    }

    // ---- Framsteg -------------------------------------------------------
    property var progress: ({})
    readonly property int levelCount: Levels.list.length

    function reloadProgress() { progress = Storage.progress() }

    function starsFor(n) { return progress[n] ? progress[n].stars : 0 }
    function bestFor(n) { return progress[n] ? progress[n].best : 0 }
    function unlocked(n) { return n === 1 || starsFor(n - 1) > 0 }
    // Första banan som är öppen men inte klarad, annars den sista
    function nextLevel() {
        for (var n = 1; n <= levelCount; n++) if (unlocked(n) && starsFor(n) === 0) return n
        return levelCount
    }
    function worldStars(w) {
        var s = 0
        for (var n = w.first; n < w.first + w.count; n++) s += starsFor(n)
        return s
    }
    function totalStars() {
        var s = 0
        for (var k in progress) s += progress[k].stars
        return s
    }

    function saveResult(n, stars, score) {
        Storage.saveResult(n, stars, score)
        reloadProgress()
    }

    function resetProgress() {
        Storage.resetProgress()
        reloadProgress()
    }

    function playLevel(n) {
        stack.push(Qt.resolvedUrl("GamePage.qml"), { levelNumber: n })
    }

    Component.onCompleted: {
        if (demo) {
            Storage.useDatabase("kottslungan-demo")
            Storage.resetProgress()
            var demoStars = [3, 3, 2, 3, 1, 3, 2, 3, 3, 2, 3, 2, 1, 3, 3, 2, 3, 3, 2, 3, 3, 2, 3, 3, 2, 3, 3, 3, 2, 3, 3, 2, 3, 3, 2, 3, 3, 2, 3, 3, 3, 2, 3, 3, 2, 3, 3, 3, 2, 3, 3, 2, 3, 3, 3, 2, 3, 3, 2, 3, 3, 3, 2]
            for (var i = 0; i < demoStars.length; i++) Storage.saveResult(i + 1, demoStars[i], 15000 + i * 2500)
        }
        langSetting = argValue("lang") !== "" ? argValue("lang") : Storage.setting("language", "auto")
        themeSetting = argValue("theme") !== "" ? argValue("theme") : Storage.setting("theme", "auto")
        applyTheme()
        var mute = argValue("mute") !== ""
        ambienceOn = !mute && Storage.setting("ambience", "1") === "1"
        effectsOn = !mute && Storage.setting("effects", "1") === "1"
        reloadProgress()
        stack.push(Qt.resolvedUrl("MenuPage.qml"))
        var page = argValue("page")
        if (page === "levels") stack.push(Qt.resolvedUrl("LevelsPage.qml"))
        else if (page === "settings") stack.push(Qt.resolvedUrl("SettingsPage.qml"))
        else if (page === "game") playLevel(argValue("level") !== "" ? parseInt(argValue("level"), 10) : 1)
    }

    PageStack { id: stack }

    // Sidan bestämmer bakgrundsljudet (spelsidan: banans värld), annars sommarskogen
    Sounds {
        id: sounds
        ambienceOn: root.ambienceOn
        effectsOn: root.effectsOn
        world: stack.currentPage && stack.currentPage.ambience !== undefined ? stack.currentPage.ambience : "forest"
    }
}
