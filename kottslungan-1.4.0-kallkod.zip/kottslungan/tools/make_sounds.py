#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Skapar spelets alla ljud från grunden med numpy (inga inspelningar, inga
# lånade ljud). Kör: python3 tools/make_sounds.py  (kräver numpy, scipy, oggenc)
# Bakgrundsljuden blir .ogg och loopar sömlöst; effekterna blir korta .wav.
import os, subprocess, wave
import numpy as np
from scipy.signal import butter, sosfilt

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "sounds")
rng = np.random.default_rng(2026)


def t_of(sec):
    return np.arange(int(sec * SR)) / SR


def periodic_noise(n, lo, hi, tilt=0.0):
    """Brus med frekvenser mellan lo och hi Hz. Skapas i frekvensplanet, så
    det är periodiskt och loopar utan skarv."""
    f = np.fft.rfftfreq(n, 1 / SR)
    # Mjuka kanter (logistiska) så att det inte låter som radiobrus
    w = 1 / (1 + np.exp(-(np.log2(np.maximum(f, 1)) - np.log2(lo)) * 6)) * 1 / (1 + np.exp((np.log2(np.maximum(f, 1)) - np.log2(hi)) * 6))
    spec = (rng.normal(size=len(f)) + 1j * rng.normal(size=len(f))) * w / np.maximum(f, 1) ** tilt
    spec[0] = 0
    x = np.fft.irfft(spec, n)
    return x / np.max(np.abs(x))


def slow_lfo(n, cycles, phase=0.0):
    # Ett helt antal svängningar per loop, så att loopen går ihop
    return 0.5 + 0.5 * np.sin(2 * np.pi * cycles * np.arange(n) / n + phase)


def env(n, attack, release):
    a = max(1, int(attack * SR)); r = max(1, int(release * SR))
    e = np.ones(n)
    e[:a] = np.linspace(0, 1, a)
    e[-r:] *= np.linspace(1, 0, r) ** 2
    return e


def chirp(f0, f1, sec, harm=(1.0, 0.25)):
    t = t_of(sec)
    f = np.geomspace(f0, f1, len(t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = sum(a * np.sin((i + 1) * ph) for i, a in enumerate(harm))
    return y * np.sin(np.pi * t / sec) ** 2


def place(buf, clip, at):
    """Lägger in ett ljud i en loop; det som går över slutet börjar om i början."""
    n = len(buf); i = int(at * SR) % n
    for k in range(0, len(clip)):
        buf[(i + k) % n] += clip[k]


def bird_song(kind):
    if kind == 0:   # tvåtonsvissling, som en talgoxe
        parts = []
        for _ in range(3):
            parts += [chirp(4200, 4000, 0.11), np.zeros(int(0.05 * SR)), chirp(3100, 3000, 0.13), np.zeros(int(0.07 * SR))]
        return np.concatenate(parts)
    if kind == 1:   # snabb drill
        return np.concatenate([np.concatenate([chirp(5200, 3800, 0.035), np.zeros(int(0.018 * SR))]) for _ in range(14)])
    # mjuk fallande ton
    return np.concatenate([chirp(2600, 1900, 0.35, (1, 0.4, 0.1)), np.zeros(int(0.12 * SR)), chirp(2500, 1800, 0.3, (1, 0.4, 0.1))])


def ambience_forest(sec=40):
    n = int(sec * SR)
    wind = periodic_noise(n, 80, 900, tilt=0.8) * (0.25 + 0.35 * slow_lfo(n, 3) * slow_lfo(n, 5, 1.0))
    leaves = periodic_noise(n, 1500, 4500, tilt=0.6) * 0.015 * slow_lfo(n, 4, 2.0)
    birds = np.zeros(n)
    t = 1.5
    while t < sec:
        kind = int(rng.integers(0, 3))
        song = bird_song(kind) * rng.uniform(0.12, 0.25)
        place(birds, song, t)
        t += rng.uniform(2.5, 6.0)
    return 0.55 * wind + leaves + birds


def ambience_winter(sec=40):
    n = int(sec * SR)
    # Vinden viner: två band som sakta glider upp och ned
    out = np.zeros(n)
    for lo, hi, cyc, amp in [(150, 500, 2, 0.5), (500, 1300, 3, 0.25)]:
        out += periodic_noise(n, lo, hi, tilt=0.5) * amp * (0.3 + 0.7 * slow_lfo(n, cyc, rng.uniform(0, 6)) ** 2)
    gust = periodic_noise(n, 700, 2200, tilt=0.6) * 0.06 * slow_lfo(n, 5, 0.5) ** 3
    # Glittrande iskristaller, mycket svaga
    sparkle = np.zeros(n)
    t = 2.0
    while t < sec:
        f = rng.choice([1568, 1760, 2093, 2349, 2637])
        tt = t_of(1.4)
        tone = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2.01 * f * tt)) * np.exp(-tt * 3.5)
        place(sparkle, tone * 0.06, t)
        t += rng.uniform(1.5, 4.5)
    return 0.6 * out + gust + sparkle


# ---- Effekter ---------------------------------------------------------------

def sfx_launch():       # gummibandet smäller och kotten susar iväg
    t = t_of(0.35)
    twang = np.sin(2 * np.pi * (180 - 120 * t) * t) * np.exp(-t * 14)
    whoosh = sosfilt(butter(2, [700, 2600], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.sin(np.pi * t / 0.35) * 0.6
    return 0.8 * twang + whoosh


def thud(f, decay, noise_amt, sec=0.25):
    t = t_of(sec)
    body = np.sin(2 * np.pi * f * t * (1 - 0.3 * t)) * np.exp(-t * decay)
    click = sosfilt(butter(2, 3000, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 60) * noise_amt
    return body + click


def sfx_hit():
    return thud(140, 26, 0.6)


def sfx_break_wood():
    out = thud(220, 30, 0.8, 0.45)
    for k in range(4):
        place(out, thud(rng.uniform(300, 520), 45, 0.5, 0.12) * 0.5, 0.04 + k * 0.06)
    return out


def sfx_break_stone():
    t = t_of(0.55)
    rumble = sosfilt(butter(2, 900, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 7)
    return 0.9 * rumble + 0.6 * thud(90, 12, 0.3, 0.55)


def sfx_break_ice():
    t = t_of(0.6)
    out = np.zeros(len(t))
    for k in range(6):
        f = rng.uniform(2200, 4200)
        tt = t_of(0.35)
        place(out, np.sin(2 * np.pi * f * tt) * np.exp(-tt * 18) * 0.35, k * 0.045)
    crash = sosfilt(butter(2, 2500, "high", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 16) * 0.5
    return out + crash


def sfx_break_snow():   # mjuk puff
    t = t_of(0.35)
    return sosfilt(butter(2, [300, 1800], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.sin(np.pi * t / 0.35) ** 2 * 0.9


def sfx_troll():        # "oj!" – en grumlig ton som faller, och en puff
    t = t_of(0.5)
    f = 260 * np.exp(-t * 2.2)
    ph = 2 * np.pi * np.cumsum(f) / SR
    voice = (np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.25 * np.sin(3 * ph)) * env(len(t), 0.02, 0.25) * 0.5
    puff = sfx_break_snow()
    return voice + np.pad(puff, (0, len(t) - len(puff)))


def sfx_ability():
    return chirp(600, 1800, 0.18, (1, 0.3)) * 0.7


def sfx_burst():
    t = t_of(0.8)
    boom = sosfilt(butter(2, 500, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 5) * 1.2
    return boom + 0.7 * thud(60, 6, 0.0, 0.8)


def marimba(freqs, step, sec):
    out = np.zeros(int(sec * SR))
    for i, f in enumerate(freqs):
        tt = t_of(0.6)
        note = (np.sin(2 * np.pi * f * tt) + 0.25 * np.sin(2 * np.pi * 4 * f * tt) * np.exp(-tt * 20)) * np.exp(-tt * 6)
        place(out, note * 0.6, i * step)
    return out


def sfx_win():
    return marimba([523.25, 659.25, 783.99, 1046.5], 0.12, 1.1)


def sfx_lose():
    return marimba([392.0, 329.63, 261.63], 0.2, 1.1)


# ---- Skriv filer ------------------------------------------------------------

def normalize(y, peak):
    return y / np.max(np.abs(y)) * peak


def write_wav(path, y):
    y = np.clip(y, -1, 1)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((y * 32767).astype("<i2").tobytes())


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, fn in [("forest", ambience_forest), ("winter", ambience_winter)]:
        tmp = os.path.join(OUT, name + ".tmp.wav")
        write_wav(tmp, normalize(fn(), 0.5))
        subprocess.run(["oggenc", "-Q", "-q", "2", "-o", os.path.join(OUT, "ambience-" + name + ".ogg"), tmp], check=True)
        os.remove(tmp)
    effects = {"launch": sfx_launch, "hit": sfx_hit, "break-wood": sfx_break_wood, "break-stone": sfx_break_stone,
               "break-ice": sfx_break_ice, "break-snow": sfx_break_snow, "troll": sfx_troll, "ability": sfx_ability,
               "burst": sfx_burst, "win": sfx_win, "lose": sfx_lose}
    for name, fn in effects.items():
        write_wav(os.path.join(OUT, name + ".wav"), normalize(fn(), 0.8))
    for f in sorted(os.listdir(OUT)):
        print(f, os.path.getsize(os.path.join(OUT, f)) // 1024, "kB")


if __name__ == "__main__":
    main()
