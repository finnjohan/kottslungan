# Changelog

- 1.4.0 – New world: Trolls on the moon, with 10 new levels. Low gravity makes the cones fly slow and far and the towers fall in slow motion. Trolls wear bubble helmets that take the first hard knock, and floating moon rocks fall when you hit them. Stars, the Earth in the sky and calm space music.
- 1.3.0 – New world: Troll cave with 10 new levels at the trolls' secret disco inside the mountain. Bounce cones off the ceiling, bring down stalactites, chandeliers and disco balls, and beat the DJ troll. Disco lights, a blinking dance floor and disco music.
- 1.2.0 – New world: Pirate cove with 10 new levels by the sea. Anything that falls into the water sinks! Pirate trolls, a tough captain and exploding powder kegs. Waves, gulls and moonlight, with background sounds of the sea.
- 1.1.0 – New world: the Winter forest with 10 new levels, frost trolls and snow trolls, snowfall and northern lights. Background sounds and sound effects (can be turned off in Settings).
- 1.0.0 – First version: 10 levels in the summer forest, four kinds of cones, light and dark theme, English and Swedish.
