.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Banorna som data. y är underkanten (marken ligger på y = 0).
// Hjälpfunktionerna bygger stolpar, bjälkar, block och troll.

var T = 0.25        // tjocklek på plankor

function col(x, y, h, mat) { return { mat: mat || "wood", x: x, y: y, w: mat === "stone" ? 0.35 : T, h: h } }
function beam(x, y, w, mat) { return { mat: mat || "wood", x: x, y: y, w: w, h: mat === "stone" ? 0.35 : T } }
function block(x, y, w, h, mat) { return { mat: mat || "wood", x: x, y: y, w: w, h: h } }
function troll(x, y, size) { return { troll: size || "small", x: x, y: y } }
function rock(x, y, w, h) { return { rock: true, x: x, y: y, w: w, h: h } }

// En våning: två stolpar och en bjälke. Returnerar delarna och höjden ovanpå.
function floor(out, x, y, width, height, mat, beamMat) {
    var half = width / 2 - T / 2
    var c = col(x - half, y, height, mat), d = col(x + half, y, height, mat)
    out.push(c, d)
    var b = beam(x, y + height, width + 0.2, beamMat || mat)
    out.push(b)
    return y + height + b.h
}

function level(name, cones, stars, build, world) {
    var items = []
    build(items)
    return { name: name, cones: cones, stars: stars, items: items, world: world || "forest" }
}
function winter(name, cones, stars, build) { return level(name, cones, stars, build, "winter") }
function sea(name, cones, stars, build) { return level(name, cones, stars, build, "sea") }

// Havet: skär och skeppsskrov står fast i vattnet (y = 0 är vattenytan).
// top är höjden ovanför vattnet.
function isle(x, w, top) { return { rock: true, style: "isle", x: x, y: -3, w: w, h: top + 3 } }
function ship(x, w, top) { return { rock: true, style: "ship", x: x, y: -2, w: w, h: top + 2 } }
function keg(x, y) { return { mat: "powder", x: x, y: y, w: 0.7, h: 0.8 } }
function cave(name, cones, stars, build) { return level(name, cones, stars, build, "cave") }

// Grottan: taket ligger på CEIL meter. Hängande föremål lossnar när de träffas.
var CEIL = 9.6
// Droppsten som hänger rakt ned från taket
function stalactite(x, len) { return { mat: "stalactite", x: x, y: CEIL - len, w: 0.6, h: len, hang: 0 } }
// Discokula i en kedja; low är hur långt under taket kulan hänger (ovansidan)
function discoball(x, low, r) { var rr = r || 0.6; return { ball: true, mat: "discoball", x: x, y: CEIL - low - 2 * rr, r: rr, hang: low } }
// Ljuskrona: en bjälke i kedja
function chandelier(x, low, w) { return { mat: "chandelier", x: x, y: CEIL - low - 0.4, w: w || 2.2, h: 0.4, hang: low } }
// Kristall: fast och studsig
function crystal(x, y, w, h) { return { rock: true, style: "crystal", x: x, y: y, w: w, h: h } }

// Månen: låg gravitation. Månsten kan sväva fritt tills den träffas.
function moon(name, cones, stars, build) { return level(name, cones, stars, build, "moon") }
function floater(x, y, w, h, mat) { return { mat: mat || "moonrock", x: x, y: y, w: w, h: h, hang: 0, float: true } }
// En rymdkapsel: plåtväggar, plåttak och ett runt fönster (en tom ruta i mitten)
function capsule(out, x, y, width, height) { return floor(out, x, y, width, height, "metal") }
// Kraterkant: en fast vall av månsten
function crater(x, w, h) { return { rock: true, style: "crater", x: x, y: 0, w: w, h: h } }

// Världarna i den ordning de spelas. first är numret på första banan.
var worlds = [
    { id: "forest", name: "Summer forest", first: 1, count: 10 },
    { id: "winter", name: "Winter forest", first: 11, count: 10 },
    { id: "sea", name: "Pirate cove", first: 21, count: 10 },
    { id: "cave", name: "Troll cave", first: 31, count: 10 },
    { id: "moon", name: "Trolls on the moon", first: 41, count: 10 }
]

function worldOf(n) {
    for (var i = worlds.length - 1; i >= 0; i--) if (n >= worlds[i].first) return worlds[i]
    return worlds[0]
}

var list = [
    // 1. En liten koja
    level("First cone", ["spruce", "spruce", "spruce"], [0, 10000, 15000], function (o) {
        var top = floor(o, 22, 0, 2.4, 2.0, "wood")
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "small"))
    }),

    // 2. Två kojor
    level("Two huts", ["spruce", "spruce", "spruce"], [0, 13000, 18000], function (o) {
        floor(o, 19, 0, 2.2, 1.8, "wood")
        o.push(troll(19, 0, "small"))
        var top = floor(o, 25, 0, 2.6, 2.4, "wood")
        o.push(troll(25, 0, "medium"))
        o.push(troll(25, top, "small"))
    }),

    // 3. Ett högt torn
    level("Watchtower", ["spruce", "pine", "spruce"], [0, 15000, 22000], function (o) {
        var y = floor(o, 23, 0, 2.4, 2.0, "wood")
        o.push(troll(23, 0, "small"))
        y = floor(o, 23, y, 2.4, 2.0, "wood")
        o.push(troll(23, y - 2.0 - T, "medium"))
        y = floor(o, 23, y, 2.0, 1.6, "wood")
        o.push(troll(23, y, "small"))
    }),

    // 4. Ispalatset
    level("Ice palace", ["pine", "pine", "spruce"], [0, 14000, 20000], function (o) {
        o.push(block(20, 0, 0.6, 2.4, "ice"), block(22.4, 0, 0.6, 2.4, "ice"))
        o.push(beam(21.2, 2.4, 3.2, "ice"))
        o.push(troll(21.2, 0, "medium"))
        o.push(block(24.8, 0, 0.6, 2.4 + T, "ice"))
        o.push(beam(23.6, 2.4 + T, 3.2, "ice"))
        o.push(troll(23.6, 0, "small"))
        o.push(block(21.2, 2.4 + T, 0.6, 1.4, "ice"), block(23.6, 2.65 + T, 0.6, 1.2, "ice"))
        o.push(troll(22.4, 2.65 + T, "small"))
    }),

    // 5. Stenbunkern
    level("Stone bunker", ["acorn", "spruce", "acorn"], [0, 13000, 18000], function (o) {
        o.push(block(21, 0, 0.6, 1.6, "stone"), block(24, 0, 0.6, 1.6, "stone"))
        o.push(beam(22.5, 1.6, 3.8, "wood"))
        o.push(troll(22.5, 0, "large"))
        o.push(block(22.5, 1.6 + T, 1.0, 1.0, "wood"))
        o.push(troll(22.5, 2.6 + T, "small"))
    }),

    // 6. På klippan
    level("On the cliff", ["chestnut", "spruce", "pine"], [0, 14000, 20000], function (o) {
        o.push(rock(24, 0, 6, 3))
        var y = floor(o, 23, 3, 2.2, 2.0, "wood")
        o.push(troll(23, 3, "medium"))
        y = floor(o, 25.2, 3, 2.0, 1.6, "ice")
        o.push(troll(25.2, 3, "small"))
        o.push(troll(23, 5.0 + T, "small"))
    }),

    // 7. Två torn och en bro
    level("The bridge", ["spruce", "pine", "acorn", "spruce"], [0, 23000, 32000], function (o) {
        var y1 = floor(o, 19.5, 0, 2.0, 2.4, "wood")
        var top1 = floor(o, 19.5, y1, 1.6, 1.4, "wood")
        o.push(troll(19.5, 0, "small"))
        var y2 = floor(o, 26.5, 0, 2.0, 2.4, "stone", "wood")
        floor(o, 26.5, y2, 1.6, 1.4, "wood")
        o.push(troll(26.5, 0, "medium"))
        o.push(beam(23, top1, 7.6, "wood"))
        o.push(troll(23, top1 + T, "small"))
        o.push(troll(23, 0, "large"))
    }),

    // 8. Pyramiden
    level("Pyramid", ["pine", "chestnut", "spruce"], [0, 13000, 18000], function (o) {
        var s = 1.0, x0 = 20.5
        for (var row = 0; row < 4; row++)
            for (var i = 0; i < 6 - row; i++) {
                var mat = row === 0 ? "stone" : (row === 3 ? "ice" : "wood")
                o.push(block(x0 + row * s / 2 + i * s, row * (s - 0.02), s - 0.02, s - 0.02, mat))
            }
        o.push(troll(x0 + 1.5 * s + 1.0, 4 * (s - 0.02), "medium"))
        o.push(troll(x0 - 1.2, 0, "small"))
        o.push(troll(x0 + 6.4, 0, "small"))
    }),

    // 9. Fästningen
    level("Fortress", ["acorn", "chestnut", "pine", "spruce"], [0, 23000, 32000], function (o) {
        o.push(block(19.5, 0, 0.6, 3.0, "stone"))
        var y = floor(o, 22, 0, 3.0, 2.2, "wood")
        o.push(troll(22, 0, "elder"))
        y = floor(o, 22, y, 2.4, 1.8, "ice", "wood")
        o.push(troll(22, y - 1.8 - T, "small"))
        o.push(block(24.6, 0, 0.6, 3.0, "stone"))
        o.push(beam(25.8, 3.0, 2.8, "wood"))
        o.push(block(27, 0, 0.6, 3.0, "stone"))
        o.push(troll(25.8, 0, "medium"))
        o.push(troll(25.8, 3.0 + T, "small"))
    }),

    // 10. Trollens by
    level("Troll village", ["spruce", "pine", "acorn", "chestnut", "spruce"], [0, 32000, 46000], function (o) {
        floor(o, 17.5, 0, 2.0, 1.8, "wood")
        o.push(troll(17.5, 0, "small"))
        o.push(rock(22.5, 0, 3, 1.5))
        var y = floor(o, 22.5, 1.5, 2.4, 2.0, "stone", "wood")
        o.push(troll(22.5, 1.5, "large"))
        y = floor(o, 22.5, y, 2.0, 1.6, "wood")
        o.push(troll(22.5, y - 1.6 - T, "small"))
        o.push(troll(22.5, y, "medium"))
        var y3 = floor(o, 27.5, 0, 2.4, 2.6, "ice", "wood")
        floor(o, 27.5, y3, 2.0, 1.6, "ice", "wood")
        o.push(troll(27.5, 0, "elder"))
        o.push(troll(27.5, y3, "small"))
    }),
    // ---- Vinterskogen ------------------------------------------------------

    // 11. Första snön
    winter("First snow", ["spruce", "spruce", "spruce"], [0, 14000, 20000], function (o) {
        var top = floor(o, 22, 0, 2.4, 2.0, "wood", "snow")
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "frost"))
        o.push(block(25.5, 0, 1.0, 1.0, "snow"), block(25.5, 1.0, 0.8, 0.8, "snow"))
        o.push(troll(25.5, 1.8, "small"))
    }),

    // 12. Igloon
    winter("The igloo", ["spruce", "pine", "spruce"], [0, 14000, 20000], function (o) {
        var x0 = 20.2, s = 0.8
        for (var r = 0; r < 2; r++) {
            o.push(block(x0 - r * 0.05, r * s, s, s, "snow"))
            o.push(block(x0 + 3.0 + r * 0.05, r * s, s, s, "snow"))
        }
        o.push(beam(x0 + 1.5, 2 * s, 4.0, "ice"))
        o.push(block(x0 + 0.8, 2 * s + T, 0.9, 0.7, "snow"), block(x0 + 2.2, 2 * s + T, 0.9, 0.7, "snow"))
        o.push(block(x0 + 1.5, 2 * s + T + 0.7, 1.6, 0.6, "snow"))
        o.push(troll(x0 + 1.5, 0, "medium"))
        o.push(troll(x0 + 1.5, 2 * s + T + 1.3, "frost"))
        o.push(troll(26.5, 0, "small"))
    }),

    // 13. Isen på sjön: hal mark och istorn
    winter("Frozen lake", ["pine", "spruce", "pine"], [0, 18000, 26000], function (o) {
        var y = floor(o, 20.5, 0, 2.2, 2.2, "ice")
        o.push(troll(20.5, 0, "frost"))
        o.push(troll(20.5, y, "small"))
        y = floor(o, 24.5, 0, 2.2, 1.6, "ice")
        y = floor(o, 24.5, y, 1.8, 1.6, "ice")
        o.push(troll(24.5, 0, "medium"))
        o.push(troll(24.5, y, "frost"))
    }),

    // 14. Snötrollets lya
    winter("Snow troll's den", ["acorn", "chestnut", "spruce"], [0, 12000, 17000], function (o) {
        o.push(rock(26.5, 0, 4, 1.2))
        o.push(block(20.8, 0, 0.6, 2.4, "stone"), block(24.2, 0, 0.6, 2.4, "stone"))
        o.push(beam(22.5, 2.4, 4.2, "wood"))
        o.push(block(22.5, 2.4 + T, 2.0, 0.7, "snow"))
        o.push(troll(22.5, 0, "snow"))
        o.push(troll(26.5, 1.2, "small"))
    }),

    // 15. Istappstornet
    winter("Icicle tower", ["pine", "acorn", "spruce", "pine"], [0, 20000, 29000], function (o) {
        var y = floor(o, 23.5, 0, 2.6, 2.0, "ice", "wood")
        o.push(troll(23.5, 0, "medium"))
        y = floor(o, 23.5, y, 2.2, 1.8, "ice", "wood")
        o.push(troll(23.5, y - 1.8 - T, "frost"))
        y = floor(o, 23.5, y, 1.8, 1.4, "ice")
        o.push(troll(23.5, y - 1.4 - T, "small"))
        o.push(troll(23.5, y, "frost"))
    }),

    // 16. Hoppbacken: trappsteg av klippa
    winter("Ski jump", ["spruce", "pine", "acorn"], [0, 13000, 18000], function (o) {
        o.push(rock(20.5, 0, 2.0, 1.0), rock(23.0, 0, 3.0, 2.0), rock(26.5, 0, 4.0, 3.2))
        o.push(block(20.5, 1.0, 0.9, 0.9, "snow"))
        o.push(troll(20.5, 1.9, "small"))
        floor(o, 23.0, 2.0, 1.8, 1.4, "wood", "snow")
        o.push(troll(23.0, 2.0, "frost"))
        floor(o, 26.5, 3.2, 2.0, 1.6, "ice", "wood")
        o.push(troll(26.5, 3.2, "medium"))
    }),

    // 17. Vedboden
    winter("Woodshed", ["acorn", "spruce", "chestnut", "spruce"], [0, 24000, 34000], function (o) {
        // Vedtravar av liggande klabbar
        for (var r = 0; r < 3; r++) {
            o.push(block(19.6, r * 0.48, 1.6, 0.48, "wood"))
            o.push(block(27.4, r * 0.48, 1.6, 0.48, "wood"))
        }
        o.push(troll(19.6, 1.44, "small"))
        o.push(troll(27.4, 1.44, "small"))
        var y = floor(o, 23.5, 0, 3.4, 2.2, "wood")
        o.push(troll(23.5, 0, "snow"))
        o.push(block(22.55, y, 0.5, 1.2, "snow"), block(24.45, y, 0.5, 1.2, "snow"))
        o.push(beam(23.5, y + 1.2, 2.6, "wood"))
        o.push(troll(23.5, y, "frost"))
    }),

    // 18. Frusna fästningen
    winter("Frozen fortress", ["acorn", "pine", "chestnut", "spruce"], [0, 28000, 40000], function (o) {
        o.push(block(19.8, 0, 0.6, 2.8, "stone"))
        var y = floor(o, 22.3, 0, 3.0, 2.0, "ice", "stone")
        o.push(troll(22.3, 0, "elder"))
        y = floor(o, 22.3, y, 2.4, 1.6, "ice", "wood")
        o.push(troll(22.3, y - 1.6 - T, "frost"))
        o.push(troll(22.3, y, "small"))
        o.push(block(25.0, 0, 0.6, 2.8, "stone"))
        o.push(beam(26.3, 2.8, 3.0, "ice"))
        o.push(block(27.6, 0, 0.6, 2.8, "stone"))
        o.push(troll(26.3, 0, "medium"))
        o.push(troll(26.3, 2.8 + T, "frost"))
    }),

    // 19. Norrskenstornet
    winter("Aurora tower", ["pine", "acorn", "chestnut", "pine", "spruce"], [0, 28000, 40000], function (o) {
        var y = floor(o, 24, 0, 2.8, 2.0, "stone", "wood")
        o.push(troll(24, 0, "large"))
        y = floor(o, 24, y, 2.4, 1.8, "wood")
        o.push(troll(24, y - 1.8 - T, "medium"))
        y = floor(o, 24, y, 2.0, 1.6, "ice", "wood")
        o.push(troll(24, y - 1.6 - T, "frost"))
        o.push(block(24, y, 1.4, 1.0, "snow"))
        o.push(troll(24, y + 1.0, "small"))
        o.push(block(19.5, 0, 1.0, 1.0, "snow"))
        o.push(troll(19.5, 1.0, "frost"))
    }),

    // 20. Vinterborgen
    winter("Winter castle", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 36000, 51000], function (o) {
        floor(o, 17.5, 0, 2.0, 1.6, "ice", "snow")
        o.push(troll(17.5, 0, "frost"))
        o.push(rock(22.5, 0, 3.4, 1.4))
        var y = floor(o, 22.5, 1.4, 2.6, 2.0, "stone", "wood")
        o.push(troll(22.5, 1.4, "snow"))
        y = floor(o, 22.5, y, 2.0, 1.6, "ice", "wood")
        o.push(troll(22.5, y - 1.6 - T, "small"))
        o.push(troll(22.5, y, "frost"))
        var y3 = floor(o, 27.5, 0, 2.4, 2.4, "stone", "wood")
        floor(o, 27.5, y3, 2.0, 1.6, "snow", "wood")
        o.push(troll(27.5, 0, "elder"))
        o.push(troll(27.5, y3, "medium"))
    }),
    // ---- Sjörövarviken --------------------------------------------------------

    // 21. Första skäret
    sea("Ahoy!", ["spruce", "spruce", "spruce"], [0, 14000, 19000], function (o) {
        o.push(isle(22, 5, 0.6))
        var top = floor(o, 21.5, 0.6, 2.2, 1.8, "wood")
        o.push(troll(21.5, 0.6, "small"))
        o.push(troll(21.5, top, "small"))
        o.push(troll(23.7, 0.6, "medium"))
    }),

    // 22. Vraket
    sea("Shipwreck", ["spruce", "pine", "spruce"], [0, 14000, 20000], function (o) {
        o.push(ship(22.5, 7, 1.2))
        o.push(block(20.0, 1.2, 0.9, 0.9, "wood"), keg(21.2, 1.2))
        o.push(troll(20.0, 2.1, "small"))
        var top = floor(o, 23.6, 1.2, 2.4, 2.0, "wood")
        o.push(troll(23.6, 1.2, "medium"))
        o.push(troll(23.6, top, "small"))
    }),

    // 23. Krutfatet
    sea("Powder keg", ["acorn", "spruce", "spruce"], [0, 15000, 21000], function (o) {
        o.push(isle(22.5, 7, 0.5))
        o.push(block(20.0, 0.5, 0.6, 2.2, "stone"), block(25.0, 0.5, 0.6, 2.2, "stone"))
        o.push(beam(22.5, 2.7, 5.6, "wood"))
        o.push(keg(22.5, 0.5))
        o.push(troll(21.3, 0.5, "small"), troll(23.7, 0.5, "small"))
        o.push(troll(22.5, 2.7 + T, "medium"))
    }),

    // 24. Fyren
    sea("Lighthouse", ["pine", "acorn", "spruce", "spruce"], [0, 24000, 35000], function (o) {
        o.push(isle(23.5, 4.6, 0.8))
        var y = floor(o, 23.5, 0.8, 2.4, 2.0, "stone", "wood")
        o.push(troll(23.5, 0.8, "medium"))
        y = floor(o, 23.5, y, 2.0, 1.8, "stone", "wood")
        o.push(troll(23.5, y - 1.8 - T, "small"))
        y = floor(o, 23.5, y, 1.6, 1.4, "wood")
        o.push(troll(23.5, y - 1.4 - T, "small"))
        o.push(troll(23.5, y, "captain"))
    }),

    // 25. Två skär och en bro
    sea("Two skerries", ["spruce", "pine", "acorn", "spruce"], [0, 18000, 26000], function (o) {
        o.push(isle(18.5, 3, 0.8), isle(26.5, 3.4, 0.8))
        var y1 = floor(o, 18.5, 0.8, 2.0, 2.2, "wood")
        var y2 = floor(o, 26.5, 0.8, 2.0, 2.2, "stone", "wood")
        o.push(troll(18.5, 0.8, "small"), troll(26.5, 0.8, "medium"))
        o.push(beam(22.5, y1, 8.4, "wood"))
        o.push(troll(22.5, y1 + T, "medium"))
        o.push(troll(19.5, y1 + T, "small"))
    }),

    // 26. Kaptenens skepp
    sea("Captain's ship", ["acorn", "chestnut", "spruce", "pine"], [0, 20000, 28000], function (o) {
        o.push(ship(23, 8, 1.4))
        o.push(block(19.6, 1.4, 0.4, 1.6, "wood"))
        o.push(keg(20.5, 1.4))
        var y = floor(o, 23.2, 1.4, 3.0, 2.0, "wood")
        o.push(troll(23.2, 1.4, "captain"))
        o.push(block(23.2, y, 1.2, 0.8, "wood"))
        o.push(troll(23.2, y + 0.8, "small"))
        o.push(block(26.4, 1.4, 0.4, 1.6, "wood"))
        o.push(troll(25.6, 1.4, "small"))
    }),

    // 27. Skattön
    sea("Treasure island", ["pine", "spruce", "chestnut", "spruce"], [0, 18000, 26000], function (o) {
        o.push(isle(23, 9, 0.6))
        var s = 1.0, x0 = 21
        for (var row = 0; row < 3; row++)
            for (var i = 0; i < 4 - row; i++)
                o.push(block(x0 + row * s / 2 + i * s, 0.6 + row * (s - 0.02), s - 0.02, s - 0.02, row === 1 ? "stone" : "wood"))
        o.push(troll(x0 + 1.5 * s, 0.6 + 3 * (s - 0.02), "medium"))
        o.push(troll(19.3, 0.6, "small"))
        o.push(keg(25.3, 0.6))
        o.push(troll(26.6, 0.6, "medium"))
    }),

    // 28. Flottan: två skepp
    sea("The fleet", ["spruce", "acorn", "pine", "chestnut"], [0, 23000, 34000], function (o) {
        o.push(ship(18.8, 5, 1.0), ship(26.2, 5.2, 1.4))
        var y = floor(o, 18.8, 1.0, 2.2, 1.8, "wood")
        o.push(troll(18.8, 1.0, "medium"), troll(18.8, y, "small"))
        o.push(keg(17.2, 1.0))
        y = floor(o, 26.2, 1.4, 2.4, 2.0, "wood", "stone")
        o.push(troll(26.2, 1.4, "captain"))
        o.push(keg(24.6, 1.4))
        o.push(troll(26.2, y, "small"))
    }),

    // 29. Hamnfästet
    sea("Harbour fort", ["acorn", "chestnut", "pine", "spruce", "spruce"], [0, 26000, 37000], function (o) {
        o.push(isle(23.5, 8.5, 1.0))
        o.push(block(19.8, 1.0, 0.6, 2.6, "stone"))
        var y = floor(o, 22.4, 1.0, 3.0, 2.2, "wood", "stone")
        o.push(troll(22.4, 1.0, "large"))
        y = floor(o, 22.4, y, 2.2, 1.6, "wood")
        o.push(troll(22.4, y - 1.6 - T, "small"))
        o.push(block(25.0, 1.0, 0.6, 2.6, "stone"), block(27.2, 1.0, 0.6, 2.6, "stone"))
        o.push(keg(25.7, 1.0), keg(26.5, 1.0))
        o.push(beam(26.1, 3.6, 2.8, "wood"))
        o.push(troll(26.1, 3.6 + T, "medium"))
        o.push(troll(22.4, y, "small"))
    }),

    // 30. Sjörövarborgen
    sea("Pirate fortress", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 39000, 56000], function (o) {
        o.push(ship(17.5, 4, 1.0))
        floor(o, 17.5, 1.0, 2.0, 1.6, "wood")
        o.push(troll(17.5, 1.0, "small"))
        o.push(isle(24.5, 9, 0.8))
        var y = floor(o, 22.3, 0.8, 2.6, 2.0, "stone", "wood")
        o.push(troll(22.3, 0.8, "captain"))
        y = floor(o, 22.3, y, 2.0, 1.6, "wood")
        o.push(troll(22.3, y - 1.6 - T, "medium"))
        o.push(troll(22.3, y, "small"))
        o.push(keg(24.6, 0.8))
        var y3 = floor(o, 27, 0.8, 2.4, 2.4, "stone", "wood")
        floor(o, 27, y3, 2.0, 1.4, "wood")
        o.push(troll(27, 0.8, "elder"))
        o.push(troll(27, y3, "medium"))
    }),
    // ---- Trollgrottan ---------------------------------------------------------

    // 31. In i berget: en droppsten hänger över trollen
    cave("Into the mountain", ["spruce", "spruce", "spruce"], [0, 14000, 19000], function (o) {
        var top = floor(o, 22, 0, 2.4, 2.0, "wood")
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "small"))
        o.push(stalactite(22, 2.2))
        o.push(troll(25.5, 0, "medium"))
        o.push(stalactite(25.5, 2.6))
    }),

    // 32. Droppstenssalen
    cave("Dripstone hall", ["spruce", "pine", "spruce"], [0, 14000, 20000], function (o) {
        floor(o, 19.5, 0, 2.2, 1.8, "wood")
        o.push(troll(19.5, 0, "small"))
        var y = floor(o, 24.5, 0, 2.6, 2.2, "stone", "wood")
        o.push(troll(24.5, 0, "medium"))
        o.push(troll(24.5, y, "small"))
        o.push(stalactite(19.5, 2.4), stalactite(22.0, 3.2), stalactite(24.5, 2.2), stalactite(27.0, 2.8))
    }),

    // 33. Kristallgruvan: en studsig kristallvägg står i vägen
    cave("Crystal mine", ["pine", "spruce", "acorn"], [0, 14000, 19000], function (o) {
        o.push(crystal(16.5, 0, 0.9, 2.6))
        var y = floor(o, 22, 0, 2.4, 2.0, "wood")
        o.push(troll(22, 0, "medium"))
        o.push(troll(22, y, "small"))
        o.push(crystal(26.5, 0, 1.4, 1.2))
        o.push(troll(26.5, 1.2, "small"))
        o.push(stalactite(24.3, 3.0))
    }),

    // 34. Dansgolvet under discokulan
    cave("Dance floor", ["spruce", "pine", "spruce"], [0, 15000, 21000], function (o) {
        o.push(rock(23.5, 0, 9, 0.5))
        o.push(troll(20.5, 0.5, "small"), troll(22.5, 0.5, "medium"), troll(24.5, 0.5, "small"), troll(26.5, 0.5, "medium"))
        o.push(discoball(23.5, 2.6, 0.75))
    }),

    // 35. Discokulan över tornet
    cave("Disco ball", ["acorn", "spruce", "pine"], [0, 16000, 23000], function (o) {
        var y = floor(o, 23.5, 0, 2.6, 2.2, "stone", "wood")
        o.push(troll(23.5, 0, "large"))
        y = floor(o, 23.5, y, 2.2, 1.8, "wood")
        o.push(troll(23.5, y - 1.8 - T, "small"))
        o.push(discoball(23.5, 0.6, 0.7))
        o.push(block(19.5, 0, 0.9, 0.9, "wood"))
        o.push(troll(19.5, 0.9, "small"))
    }),

    // 36. Ekosalen: höga torn nästan upp till taket
    cave("Echo hall", ["pine", "acorn", "spruce", "chestnut"], [0, 24000, 35000], function (o) {
        var y = floor(o, 21, 0, 2.2, 2.4, "stone", "wood")
        y = floor(o, 21, y, 2.0, 2.2, "wood")
        o.push(troll(21, 0, "medium"), troll(21, y - 2.2 - T, "small"))
        var y2 = floor(o, 26, 0, 2.2, 2.6, "wood")
        y2 = floor(o, 26, y2, 2.0, 2.2, "ice", "wood")
        o.push(troll(26, 0, "medium"), troll(26, y2 - 2.2 - T, "small"), troll(26, y2, "small"))
        o.push(stalactite(23.5, 3.6))
    }),

    // 37. Glittergrottan
    cave("Glitter cave", ["spruce", "pine", "acorn", "spruce"], [0, 19000, 27000], function (o) {
        o.push(crystal(18.5, 0, 1.2, 1.6))
        o.push(troll(18.5, 1.6, "small"))
        var y = floor(o, 22.5, 0, 2.6, 2.0, "stone", "wood")
        o.push(troll(22.5, 0, "large"))
        o.push(block(22.5, y, 1.0, 1.0, "ice"))
        o.push(troll(22.5, y + 1.0, "small"))
        o.push(crystal(26.8, 0, 1.0, 2.8))
        o.push(troll(28.0, 0, "medium"))
        o.push(stalactite(28.0, 3.4), stalactite(20.6, 2.4))
    }),

    // 38. Ljuskronan
    cave("Chandelier", ["spruce", "acorn", "pine", "spruce"], [0, 21000, 30000], function (o) {
        o.push(block(20.5, 0, 0.6, 1.6, "stone"), block(26.5, 0, 0.6, 1.6, "stone"))
        o.push(beam(23.5, 1.6, 6.8, "wood"))
        o.push(troll(22.0, 0, "medium"), troll(25.0, 0, "small"))
        o.push(troll(21.8, 1.6 + T, "small"), troll(25.2, 1.6 + T, "small"))
        o.push(chandelier(23.5, 1.6, 3.0))
        o.push(troll(23.5, 1.6 + T, "medium"))
    }),

    // 39. Bakom scenen: krutfat och droppsten
    cave("Backstage", ["acorn", "chestnut", "pine", "spruce"], [0, 19000, 27000], function (o) {
        o.push(block(19.8, 0, 0.6, 2.4, "stone"))
        var y = floor(o, 22.5, 0, 3.0, 2.2, "wood", "stone")
        o.push(keg(21.75, 0), troll(23.0, 0, "medium"))
        o.push(troll(22.5, y, "small"))
        o.push(block(25.3, 0, 0.6, 2.4, "stone"))
        o.push(keg(26.4, 0))
        o.push(troll(27.5, 0, "large"))
        o.push(stalactite(27.5, 3.0), stalactite(24.4, 2.6))
    }),

    // 40. Trolldiskot: diskjockeyn står på scenen
    cave("Troll disco", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 37000, 53000], function (o) {
        floor(o, 17.5, 0, 2.0, 1.6, "wood")
        o.push(troll(17.5, 0, "small"))
        o.push(rock(23.8, 0, 6.4, 1.0))
        var y = floor(o, 22.2, 1.0, 2.6, 2.0, "stone", "wood")
        o.push(troll(22.2, 1.0, "dj"))
        o.push(troll(22.2, y, "medium"))
        o.push(block(25.0, 1.0, 1.2, 0.9, "wood"), keg(26.6, 1.0))
        o.push(troll(25.0, 1.9, "small"))
        var y3 = floor(o, 28.3, 0, 2.2, 2.2, "stone", "wood")
        o.push(troll(28.3, 0, "elder"), troll(28.3, y3, "medium"))
        o.push(discoball(24.6, 1.2, 0.75))
        o.push(stalactite(19.8, 2.6), stalactite(28.3, 2.0))
    }),

    // ---- Trollen på månen (41–50) ------------------------------------------

    // 41. Ett litet steg: en rymdkapsel och låg gravitation
    moon("One small step", ["spruce", "spruce", "spruce"], [0, 11000, 15000], function (o) {
        var top = capsule(o, 22, 0, 2.4, 2.0)
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "small"))
    }),

    // 42. Månbasen: två kapslar, och trollen har bubbelhjälm
    moon("Moon base", ["spruce", "pine", "spruce", "spruce"], [0, 15000, 22000], function (o) {
        capsule(o, 19.5, 0, 2.2, 1.8)
        o.push(troll(19.5, 0, "small"))
        var top = capsule(o, 25, 0, 2.6, 2.2)
        o.push(troll(25, 0, "medium"))
        o.push(troll(25, top, "small"))
    }),

    // 43. Svävande stenar: troll på stenar som svävar fritt
    moon("Floating rocks", ["spruce", "pine", "spruce"], [0, 12000, 17000], function (o) {
        o.push(floater(19.5, 3.2, 1.8, 0.6))
        o.push(troll(19.5, 3.8, "small"))
        o.push(floater(23.5, 5.0, 2.0, 0.6))
        o.push(troll(23.5, 5.6, "medium"))
        o.push(block(26.5, 0, 1.0, 1.0, "moonrock"))
        o.push(troll(26.5, 1.0, "small"))
    }),

    // 44. Kratern: trollen gömmer sig mellan kraterkanterna
    moon("Crater", ["pine", "acorn", "spruce", "spruce"], [0, 18000, 26000], function (o) {
        o.push(crater(19.6, 1.4, 1.6), crater(27.4, 1.4, 1.6))
        o.push(troll(21.8, 0, "medium"), troll(25.2, 0, "small"))
        var y = capsule(o, 23.5, 0, 2.0, 1.6)
        o.push(troll(23.5, 0, "small"))
        o.push(troll(23.5, y, "small"))
        o.push(troll(27.4, 1.6, "small"))
    }),

    // 45. Startplattan: ett högt raketttorn av plåt
    moon("Launch pad", ["spruce", "pine", "acorn", "spruce"], [0, 21000, 30000], function (o) {
        var y = floor(o, 23.5, 0, 2.6, 2.2, "moonrock", "metal")
        o.push(troll(23.5, 0, "medium"))
        y = capsule(o, 23.5, y, 2.2, 2.0)
        o.push(troll(23.5, y - 2.0 - T, "small"))
        y = capsule(o, 23.5, y, 1.8, 1.6)
        o.push(troll(23.5, y - 1.6 - T, "small"))
        o.push(troll(23.5, y, "small"))
    }),

    // 46. Satelliten: en lång plåtbalk svävar över basen
    moon("Satellite", ["pine", "spruce", "acorn", "spruce"], [0, 18000, 25000], function (o) {
        o.push(floater(23.5, 5.6, 5.0, 0.4, "metal"))
        o.push(troll(22.0, 6.0, "small"), troll(25.0, 6.0, "small"))
        var y = floor(o, 23.5, 0, 2.6, 2.0, "moonrock", "metal")
        o.push(troll(23.5, 0, "large"))
        o.push(block(23.5, y, 1.0, 1.0, "moonrock"))
        o.push(crater(18.8, 1.2, 1.4))
    }),

    // 47. Asteroidbältet: många svävande stenar på olika höjd
    moon("Asteroid belt", ["pine", "spruce", "chestnut", "pine"], [0, 21000, 29000], function (o) {
        o.push(floater(18.5, 2.6, 1.4, 0.6)); o.push(troll(18.5, 3.2, "small"))
        o.push(floater(21.5, 4.6, 1.6, 0.6)); o.push(troll(21.5, 5.2, "medium"))
        o.push(floater(24.5, 3.2, 1.4, 0.6)); o.push(troll(24.5, 3.8, "small"))
        o.push(floater(27.3, 5.4, 1.6, 0.6)); o.push(troll(27.3, 6.0, "small"))
        o.push(block(26.0, 0, 1.2, 1.2, "moonrock"))
        o.push(troll(26.0, 1.2, "small"))
    }),

    // 48. Månens baksida: sten och plåt, och en sten som svävar över tornet
    moon("Dark side", ["acorn", "chestnut", "spruce", "pine"], [0, 23000, 33000], function (o) {
        o.push(crater(18.2, 1.2, 1.2))
        o.push(troll(18.2, 1.2, "small"))
        var y = floor(o, 22.5, 0, 2.6, 2.2, "moonrock", "metal")
        o.push(troll(22.5, 0, "large"))
        y = capsule(o, 22.5, y, 2.2, 1.8)
        o.push(troll(22.5, y - 1.8 - T, "small"))
        o.push(floater(22.5, y + 1.6, 1.4, 0.7))
        var y2 = floor(o, 27, 0, 2.2, 2.0, "moonrock", "metal")
        o.push(troll(27, 0, "medium"), troll(27, y2, "small"))
    }),

    // 49. Rymdstationen: en kapsel ute i rymden, på en svävande plattform
    moon("Space station", ["spruce", "pine", "acorn", "chestnut"], [0, 22000, 32000], function (o) {
        o.push(floater(24.5, 3.4, 4.2, 0.4, "metal"))
        var y = capsule(o, 24.5, 3.8, 2.4, 1.8)
        o.push(troll(24.5, 3.8, "medium"))
        o.push(troll(24.5, y, "small"))
        o.push(floater(19.5, 5.2, 1.4, 0.6)); o.push(troll(19.5, 5.8, "small"))
        capsule(o, 20.5, 0, 2.0, 1.6)
        o.push(troll(20.5, 0, "small"))
        o.push(block(28.2, 0, 1.0, 1.4, "metal"))
        o.push(troll(28.2, 1.4, "small"))
    }),

    // 50. Månborgen: befälhavaren i rymddräkt
    moon("Moon fortress", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 36000, 52000], function (o) {
        capsule(o, 17.5, 0, 2.0, 1.6)
        o.push(troll(17.5, 0, "small"))
        o.push(rock(23.8, 0, 6.4, 1.0))
        var y = floor(o, 22.2, 1.0, 2.6, 2.0, "moonrock", "metal")
        o.push(troll(22.2, 1.0, "astronaut"))
        o.push(troll(22.2, y, "medium"))
        o.push(block(25.2, 1.0, 1.2, 1.0, "metal"))
        o.push(troll(25.2, 2.0, "small"))
        var y3 = capsule(o, 28.3, 0, 2.2, 2.2)
        o.push(troll(28.3, 0, "elder"), troll(28.3, y3, "medium"))
        o.push(floater(25.2, 5.4, 1.6, 0.6)); o.push(troll(25.2, 6.0, "small"))
    })
]
