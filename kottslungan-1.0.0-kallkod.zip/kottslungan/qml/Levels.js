.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Banorna som data. y är underkanten (marken ligger på y = 0).
// Hjälpfunktionerna bygger stolpar, bjälkar, block och troll.

var T = 0.25        // tjocklek på plankor

function col(x, y, h, mat) { return { mat: mat || "wood", x: x, y: y, w: mat === "stone" ? 0.35 : T, h: h } }
function beam(x, y, w, mat) { return { mat: mat || "wood", x: x, y: y, w: w, h: mat === "stone" ? 0.35 : T } }
function block(x, y, w, h, mat) { return { mat: mat || "wood", x: x, y: y, w: w, h: h } }
function troll(x, y, size) { return { troll: size || "small", x: x, y: y } }
function rock(x, y, w, h) { return { rock: true, x: x, y: y, w: w, h: h } }

// En våning: två stolpar och en bjälke. Returnerar delarna och höjden ovanpå.
function floor(out, x, y, width, height, mat, beamMat) {
    var half = width / 2 - T / 2
    var c = col(x - half, y, height, mat), d = col(x + half, y, height, mat)
    out.push(c, d)
    var b = beam(x, y + height, width + 0.2, beamMat || mat)
    out.push(b)
    return y + height + b.h
}

function level(name, cones, stars, build) {
    var items = []
    build(items)
    return { name: name, cones: cones, stars: stars, items: items }
}

var list = [
    // 1. En liten koja
    level("First cone", ["spruce", "spruce", "spruce"], [0, 10000, 15000], function (o) {
        var top = floor(o, 22, 0, 2.4, 2.0, "wood")
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "small"))
    }),

    // 2. Två kojor
    level("Two huts", ["spruce", "spruce", "spruce"], [0, 13000, 18000], function (o) {
        floor(o, 19, 0, 2.2, 1.8, "wood")
        o.push(troll(19, 0, "small"))
        var top = floor(o, 25, 0, 2.6, 2.4, "wood")
        o.push(troll(25, 0, "medium"))
        o.push(troll(25, top, "small"))
    }),

    // 3. Ett högt torn
    level("Watchtower", ["spruce", "pine", "spruce"], [0, 15000, 22000], function (o) {
        var y = floor(o, 23, 0, 2.4, 2.0, "wood")
        o.push(troll(23, 0, "small"))
        y = floor(o, 23, y, 2.4, 2.0, "wood")
        o.push(troll(23, y - 2.0 - T, "medium"))
        y = floor(o, 23, y, 2.0, 1.6, "wood")
        o.push(troll(23, y, "small"))
    }),

    // 4. Ispalatset
    level("Ice palace", ["pine", "pine", "spruce"], [0, 14000, 20000], function (o) {
        o.push(block(20, 0, 0.6, 2.4, "ice"), block(22.4, 0, 0.6, 2.4, "ice"))
        o.push(beam(21.2, 2.4, 3.2, "ice"))
        o.push(troll(21.2, 0, "medium"))
        o.push(block(24.8, 0, 0.6, 2.4 + T, "ice"))
        o.push(beam(23.6, 2.4 + T, 3.2, "ice"))
        o.push(troll(23.6, 0, "small"))
        o.push(block(21.2, 2.4 + T, 0.6, 1.4, "ice"), block(23.6, 2.65 + T, 0.6, 1.2, "ice"))
        o.push(troll(22.4, 2.65 + T, "small"))
    }),

    // 5. Stenbunkern
    level("Stone bunker", ["acorn", "spruce", "acorn"], [0, 13000, 18000], function (o) {
        o.push(block(21, 0, 0.6, 1.6, "stone"), block(24, 0, 0.6, 1.6, "stone"))
        o.push(beam(22.5, 1.6, 3.8, "wood"))
        o.push(troll(22.5, 0, "large"))
        o.push(block(22.5, 1.6 + T, 1.0, 1.0, "wood"))
        o.push(troll(22.5, 2.6 + T, "small"))
    }),

    // 6. På klippan
    level("On the cliff", ["chestnut", "spruce", "pine"], [0, 14000, 20000], function (o) {
        o.push(rock(24, 0, 6, 3))
        var y = floor(o, 23, 3, 2.2, 2.0, "wood")
        o.push(troll(23, 3, "medium"))
        y = floor(o, 25.2, 3, 2.0, 1.6, "ice")
        o.push(troll(25.2, 3, "small"))
        o.push(troll(23, 5.0 + T, "small"))
    }),

    // 7. Två torn och en bro
    level("The bridge", ["spruce", "pine", "acorn", "spruce"], [0, 23000, 32000], function (o) {
        var y1 = floor(o, 19.5, 0, 2.0, 2.4, "wood")
        var top1 = floor(o, 19.5, y1, 1.6, 1.4, "wood")
        o.push(troll(19.5, 0, "small"))
        var y2 = floor(o, 26.5, 0, 2.0, 2.4, "stone", "wood")
        floor(o, 26.5, y2, 1.6, 1.4, "wood")
        o.push(troll(26.5, 0, "medium"))
        o.push(beam(23, top1, 7.6, "wood"))
        o.push(troll(23, top1 + T, "small"))
        o.push(troll(23, 0, "large"))
    }),

    // 8. Pyramiden
    level("Pyramid", ["pine", "chestnut", "spruce"], [0, 13000, 18000], function (o) {
        var s = 1.0, x0 = 20.5
        for (var row = 0; row < 4; row++)
            for (var i = 0; i < 6 - row; i++) {
                var mat = row === 0 ? "stone" : (row === 3 ? "ice" : "wood")
                o.push(block(x0 + row * s / 2 + i * s, row * (s - 0.02), s - 0.02, s - 0.02, mat))
            }
        o.push(troll(x0 + 1.5 * s + 1.0, 4 * (s - 0.02), "medium"))
        o.push(troll(x0 - 1.2, 0, "small"))
        o.push(troll(x0 + 6.4, 0, "small"))
    }),

    // 9. Fästningen
    level("Fortress", ["acorn", "chestnut", "pine", "spruce"], [0, 23000, 32000], function (o) {
        o.push(block(19.5, 0, 0.6, 3.0, "stone"))
        var y = floor(o, 22, 0, 3.0, 2.2, "wood")
        o.push(troll(22, 0, "elder"))
        y = floor(o, 22, y, 2.4, 1.8, "ice", "wood")
        o.push(troll(22, y - 1.8 - T, "small"))
        o.push(block(24.6, 0, 0.6, 3.0, "stone"))
        o.push(beam(25.8, 3.0, 2.8, "wood"))
        o.push(block(27, 0, 0.6, 3.0, "stone"))
        o.push(troll(25.8, 0, "medium"))
        o.push(troll(25.8, 3.0 + T, "small"))
    }),

    // 10. Trollens by
    level("Troll village", ["spruce", "pine", "acorn", "chestnut", "spruce"], [0, 32000, 46000], function (o) {
        floor(o, 17.5, 0, 2.0, 1.8, "wood")
        o.push(troll(17.5, 0, "small"))
        o.push(rock(22.5, 0, 3, 1.5))
        var y = floor(o, 22.5, 1.5, 2.4, 2.0, "stone", "wood")
        o.push(troll(22.5, 1.5, "large"))
        y = floor(o, 22.5, y, 2.0, 1.6, "wood")
        o.push(troll(22.5, y - 1.6 - T, "small"))
        o.push(troll(22.5, y, "medium"))
        var y3 = floor(o, 27.5, 0, 2.4, 2.6, "ice", "wood")
        floor(o, 27.5, y3, 2.0, 1.6, "ice", "wood")
        o.push(troll(27.5, 0, "elder"))
        o.push(troll(27.5, y3, "small"))
    })
]
