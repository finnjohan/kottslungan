// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// Himmel, sol eller måne, kullar med granar och mark. groundY är markens
// y-koordinat i pixlar uppifrån.
Item {
    id: scene
    property real groundY: height * 0.85
    property bool night: false

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: scene.night ? "#0E1A33" : "#7EC3EC" }
            GradientStop { position: 0.75; color: scene.night ? "#2C3A5C" : "#D6EEF8" }
        }
    }
    // Sol eller måne
    Rectangle {
        x: parent.width * 0.78; y: parent.height * 0.1
        width: Math.min(parent.width, parent.height) * 0.12; height: width; radius: width / 2
        color: scene.night ? "#F2EBC8" : "#FFD95A"
        opacity: scene.night ? 0.9 : 1
    }
    Rectangle {
        visible: scene.night
        x: parent.width * 0.78 + width * 0.35; y: parent.height * 0.1 - width * 0.12
        width: Math.min(parent.width, parent.height) * 0.12; height: width; radius: width / 2
        color: "#13213D"
    }
    Repeater {
        model: scene.night ? 18 : 0
        Rectangle {
            width: 2; height: 2; radius: 1; color: "#FFFFFF"; opacity: 0.6 + (index % 3) * 0.13
            x: (index * 137) % scene.width; y: (index * 59) % (scene.groundY * 0.45)
        }
    }
    Image {
        source: "../assets/hills.svg"
        width: parent.width
        height: parent.height * 0.36
        y: scene.groundY - height + 2
        sourceSize: Qt.size(1600, 300)
        opacity: scene.night ? 0.45 : 1
    }
    // Marken: gräs och jord
    Rectangle {
        y: scene.groundY
        width: parent.width; height: parent.height - y
        color: scene.night ? "#3B2A1E" : "#6B4A2E"
        Rectangle { width: parent.width; height: Math.max(6, parent.height * 0.18); color: scene.night ? "#2F5A33" : "#5FA04A" }
    }
}
