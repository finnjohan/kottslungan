.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

var languages = [
    { code: "en", name: "English" },
    { code: "sv", name: "Svenska" }
]

var sv = {
    // Meny
    "Fling cones at the forest trolls": "Slunga kottar på skogstrollen",
    "Play": "Spela",
    "Levels": "Banor",
    "Settings": "Inställningar",

    // Banor
    "First cone": "Första kotten",
    "Two huts": "Två kojor",
    "Watchtower": "Utkikstornet",
    "Ice palace": "Ispalatset",
    "Stone bunker": "Stenbunkern",
    "On the cliff": "På klippan",
    "The bridge": "Bron",
    "Pyramid": "Pyramiden",
    "Fortress": "Fästningen",
    "Troll village": "Trollbyn",

    // Spelet
    "Level %1": "Bana %1",
    "Trolls left: %1": "Troll kvar: %1",
    "Pine cone: tap in flight to split into three": "Tallkotte: tryck i luften för att dela den i tre",
    "Acorn: tap in flight for a burst of speed": "Ekollon: tryck i luften för extra fart",
    "Chestnut: tap in flight to burst": "Kastanj: tryck i luften så spricker den",
    "Pull back the cone and let go": "Dra kotten bakåt och släpp",
    "Level cleared!": "Banan klarad!",
    "Out of cones!": "Slut på kottar!",
    "Score: %1": "Poäng: %1",
    "New best!": "Nytt rekord!",
    "The trolls are still there. Try a different angle!": "Trollen är kvar. Prova en annan vinkel!",
    "Play again": "Spela igen",
    "Next": "Nästa",

    // Inställningar
    "Theme": "Tema",
    "Automatic": "Automatiskt",
    "Light (day)": "Ljust (dag)",
    "Dark (evening)": "Mörkt (kväll)",
    "Language": "Språk",
    "Automatic (system language)": "Automatiskt (systemets språk)",
    "Progress": "Framsteg",
    "Reset progress": "Nollställ framsteg",
    "Reset progress?": "Nollställa framstegen?",
    "All stars and best scores will be deleted.": "Alla stjärnor och rekord tas bort.",
    "Reset": "Nollställ",
    "Cancel": "Avbryt",
    "About": "Om",
    "Help the squirrel fling cones at the trolls who have taken over the forest. An original game in the classic slingshot genre – all characters and levels are made for this game.":
        "Hjälp ekorren att slunga kottar på trollen som har tagit över skogen. Ett eget spel i den klassiska slangbellegenren – alla figurer och banor är gjorda för det här spelet.",
    "The physics engine is written for this game and follows the ideas in Box2D-Lite by Erin Catto.":
        "Fysikmotorn är skriven för det här spelet och bygger på idéerna i Box2D-Lite av Erin Catto.",
    "Version %1": "Version %1"
}

var tables = { sv: sv }

function systemLanguage(localeName) {
    return (localeName || "en").substring(0, 2) === "sv" ? "sv" : "en"
}

function tr(s, lang) {
    var t = tables[lang]
    return (t && t[s] !== undefined) ? t[s] : s
}
