// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Levels.js" as Levels

Page {
    id: page
    header: PageHeader {
        id: header
        title: root.tr("Levels")
        trailingActionBar.actions: [
            Action { iconName: "settings"; text: root.tr("Settings"); onTriggered: stack.push(Qt.resolvedUrl("SettingsPage.qml")) }
        ]
    }

    GridView {
        id: grid
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom; margins: units.gu(2) }
        readonly property int columns: Math.max(3, Math.floor(width / units.gu(16)))
        cellWidth: width / columns
        cellHeight: units.gu(14)
        clip: true
        model: root.levelCount
        delegate: Item {
            width: grid.cellWidth; height: grid.cellHeight
            readonly property int n: index + 1
            readonly property bool open: root.unlocked(n)
            AbstractButton {
                anchors { fill: parent; margins: units.gu(0.8) }
                enabled: parent.open
                onClicked: root.playLevel(parent.n)
                Rectangle {
                    anchors.fill: parent
                    radius: units.gu(1.5)
                    color: parent.parent.open ? (root.isDark ? "#2F4A30" : "#E3F1DA") : theme.palette.normal.base
                    border.color: parent.parent.open ? "#5E8F4A" : theme.palette.normal.base
                    border.width: units.dp(2)
                    opacity: parent.parent.open ? 1 : 0.6
                }
                Column {
                    anchors.centerIn: parent
                    width: parent.width - units.gu(1)
                    spacing: units.gu(0.4)
                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: parent.parent.parent.n
                        textSize: Label.XLarge
                        font.weight: Font.Bold
                    }
                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: parent.width
                        horizontalAlignment: Text.AlignHCenter
                        elide: Text.ElideRight
                        text: root.tr(Levels.list[index].name)
                        textSize: Label.Small
                    }
                    Item {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: lock.visible ? lock.width : levelStars.width
                        height: units.gu(2.2)
                        Stars { id: levelStars; visible: !lock.visible; count: root.starsFor(index + 1); size: units.gu(2.2) }
                        Icon { id: lock; visible: !root.unlocked(index + 1); name: "lock"; width: units.gu(2.2); height: width
                               color: theme.palette.normal.backgroundSecondaryText }
                    }
                }
            }
        }
    }
}
