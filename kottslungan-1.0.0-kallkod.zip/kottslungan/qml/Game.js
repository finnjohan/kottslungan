.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Spelregler utan QML-beroenden: banan byggs upp i fysikvärlden, kottar
// skjuts, stötar ger skada, troll och block försvinner, poäng och stjärnor.
.import "Physics.js" as P

var WORLD_W = 29.5
var WORLD_H = 18
var SLING_X = 4.2
var SLING_Y = 3.3
var MAX_PULL = 2.2
var MAX_SPEED = 21
var DT = 1 / 60
var SETTLE_TIME = 1.2         // ingen skada medan banan sätter sig

// ---- Kottar ----------------------------------------------------------------
// ability: "none" | "split" | "dash" | "burst"
var CONES = {
    spruce:   { r: 0.32, density: 6,  ability: "none",  name: "Spruce cone" },
    pine:     { r: 0.28, density: 6,  ability: "split", name: "Pine cone" },
    acorn:    { r: 0.25, density: 10, ability: "dash",  name: "Acorn" },
    chestnut: { r: 0.36, density: 6,  ability: "burst", name: "Chestnut" }
}

// ---- Material och troll -----------------------------------------------------
var MATERIALS = {
    wood:  { density: 2.0, friction: 0.7, hp: 9,  score: 500 },
    stone: { density: 5.0, friction: 0.8, hp: 22, score: 1000 },
    ice:   { density: 1.5, friction: 0.15, hp: 4, score: 300 }
}

var TROLLS = {
    small:  { r: 0.40, density: 2, hp: 4,  score: 5000 },
    medium: { r: 0.55, density: 2, hp: 8,  score: 5000 },
    large:  { r: 0.75, density: 2, hp: 14, score: 7000 },
    elder:  { r: 0.70, density: 2.5, hp: 20, score: 10000 }
}

var HIT_THRESHOLD = 1.2       // impulser under detta gör ingen skada
var CONE_BONUS = 3000         // per kotte som blir över

// ---- Ny omgång ---------------------------------------------------------------

function newGame(level) {
    var g = {
        level: level,
        world: P.makeWorld(),
        queue: level.cones.slice(),
        current: null,         // kotten i slangbellan eller i luften
        flying: [],            // alla kottar i rörelse (delning ger flera)
        state: "aim",          // aim | flying | waiting | won | lost
        score: 0,
        trolls: 0,
        events: [],
        time: 0,
        stateTime: 0,
        abilityUsed: false,
        pullX: 0, pullY: 0
    }
    // Marken
    P.addBody(g.world, P.makeBody({ shape: "box", x: WORLD_W / 2, y: -1, w: 200, h: 2, isStatic: true,
                                    friction: 0.9, kind: "ground" }))
    var items = level.items
    for (var i = 0; i < items.length; i++) addItem(g, items[i])
    loadNext(g)
    return g
}

function addItem(g, it) {
    var b
    if (it.troll) {
        var t = TROLLS[it.troll]
        // Hög vinkeldämpning fungerar som rullmotstånd: trollen står kvar
        b = P.makeBody({ shape: "circle", x: it.x, y: it.y + t.r, r: t.r, density: t.density, friction: 0.8,
                         angularDamping: 12,
                         kind: "troll", data: { type: it.troll, hp: t.hp, maxHp: t.hp } })
        g.trolls++
    } else if (it.rock) {
        b = P.makeBody({ shape: "box", x: it.x, y: it.y + it.h / 2, w: it.w, h: it.h, isStatic: true,
                         friction: 0.9, kind: "rock" })
    } else {
        var m = MATERIALS[it.mat]
        b = P.makeBody({ shape: "box", x: it.x, y: it.y + it.h / 2, w: it.w, h: it.h, angle: it.angle || 0,
                         density: m.density, friction: m.friction,
                         kind: "block", data: { mat: it.mat, hp: m.hp * Math.max(1, it.w * it.h * 1.5), maxHp: 0 } })
        b.data.maxHp = b.data.hp
    }
    P.addBody(g.world, b)
    g.events.push({ type: "add", body: b })
    return b
}

function loadNext(g) {
    g.abilityUsed = false
    g.pullX = 0; g.pullY = 0
    if (g.queue.length === 0) { g.current = null; return false }
    var type = g.queue.shift()
    var c = CONES[type]
    // Kotten ligger i slangbellan men är inte med i fysiken förrän den skjuts
    g.current = P.makeBody({ shape: "circle", x: SLING_X, y: SLING_Y, r: c.r, density: c.density,
                             friction: 0.5, restitution: 0.25, kind: "cone", data: { type: type, launched: false, still: 0, age: 0 } })
    g.events.push({ type: "load", body: g.current })
    g.state = "aim"
    g.stateTime = 0
    return true
}

// ---- Sikte och skott -------------------------------------------------------

// Sätter hur långt kotten dras bakåt (relativt slangbellan). Returnerar
// kottens position.
function aim(g, dx, dy) {
    if (g.state !== "aim" || !g.current) return null
    var d = Math.sqrt(dx * dx + dy * dy)
    if (d > MAX_PULL) { dx *= MAX_PULL / d; dy *= MAX_PULL / d }
    // Kotten får inte dras ned genom marken
    if (SLING_Y + dy < g.current.r) dy = g.current.r - SLING_Y
    g.pullX = dx; g.pullY = dy
    g.current.x = SLING_X + dx
    g.current.y = SLING_Y + dy
    return { x: g.current.x, y: g.current.y }
}

function launchVelocity(dx, dy) {
    var d = Math.sqrt(dx * dx + dy * dy)
    if (d < 1e-6) return { vx: 0, vy: 0 }
    var s = MAX_SPEED * Math.min(1, d / MAX_PULL)
    return { vx: -dx / d * s, vy: -dy / d * s }
}

// Banan som kotten skulle ta (utan hinder), för de prickade punkterna.
function trajectory(g, count, every) {
    var v = launchVelocity(g.pullX, g.pullY)
    var x = SLING_X + g.pullX, y = SLING_Y + g.pullY, vx = v.vx, vy = v.vy
    var out = []
    var ld = 1 / (1 + DT * P.LINEAR_DAMPING)
    for (var i = 1; i <= count * every; i++) {
        vy += DT * P.GRAVITY
        vx *= ld; vy *= ld
        x += DT * vx; y += DT * vy
        if (y < 0) break
        if (i % every === 0) out.push({ x: x, y: y })
    }
    return out
}

function launch(g) {
    if (g.state !== "aim" || !g.current) return false
    var d = Math.sqrt(g.pullX * g.pullX + g.pullY * g.pullY)
    if (d < 0.35) {            // för lite drag: lägg tillbaka
        aim(g, 0, 0)
        return false
    }
    var v = launchVelocity(g.pullX, g.pullY)
    var c = g.current
    c.vx = v.vx; c.vy = v.vy
    c.w = -v.vx * 0.8
    c.data.launched = true
    P.addBody(g.world, c)
    g.flying = [c]
    g.state = "flying"
    g.stateTime = 0
    g.events.push({ type: "launch", body: c })
    return true
}

// Tryck under flygningen: kottens förmåga.
function useAbility(g) {
    if (g.state !== "flying" || g.abilityUsed || !g.current || !g.current.alive) return false
    var c = g.current, type = c.data.type, ab = CONES[type].ability
    if (ab === "none") return false
    g.abilityUsed = true
    if (ab === "split") {
        var sp = P.speed(c), ang = Math.atan2(c.vy, c.vx)
        for (var k = -1; k <= 1; k += 2) {
            var a = ang + k * 0.22
            var n = P.makeBody({ shape: "circle", x: c.x, y: c.y + k * 0.05, r: c.r, density: c.density, friction: 0.5,
                                 restitution: 0.25, kind: "cone",
                                 data: { type: type, launched: true, still: 0, age: c.data.age, child: true } })
            n.vx = Math.cos(a) * sp; n.vy = Math.sin(a) * sp; n.w = c.w
            P.addBody(g.world, n)
            g.flying.push(n)
            g.events.push({ type: "add", body: n })
        }
    } else if (ab === "dash") {
        var s = P.speed(c)
        if (s > 0.1) { var f = Math.min(36, s * 2.2) / s; c.vx *= f; c.vy *= f }
        // Ekollonet blir tyngre i farten och slår igenom trä
        c.data.dash = true
    } else if (ab === "burst") {
        burst(g, c)
    }
    g.events.push({ type: "ability", body: c, ability: ab })
    return true
}

function burst(g, c) {
    var hit = P.explode(g.world, c.x, c.y, 3.0, 50)
    for (var i = 0; i < hit.length; i++) {
        var b = hit[i].body
        if (b === c) continue
        damage(g, b, hit[i].power * 0.2, c.x, c.y)
    }
    g.events.push({ type: "burst", x: c.x, y: c.y })
    removeCone(g, c)
}

// ---- Skada -----------------------------------------------------------------

function damage(g, b, amount, x, y) {
    if (!b.alive || (b.kind !== "troll" && b.kind !== "block")) return
    b.data.hp -= amount
    g.events.push({ type: "hurt", body: b })
    if (b.data.hp <= 0) destroy(g, b, x, y)
}

function destroy(g, b, x, y) {
    if (!b.alive) return
    var pts = 0
    if (b.kind === "troll") { pts = TROLLS[b.data.type].score; g.trolls-- }
    else if (b.kind === "block") pts = MATERIALS[b.data.mat].score
    P.removeBody(g.world, b)
    g.score += pts
    g.events.push({ type: "destroy", body: b, points: pts, x: b.x, y: b.y })
}

function removeCone(g, c) {
    if (c.alive) P.removeBody(g.world, c)
    c.alive = false
    var i = g.flying.indexOf(c)
    if (i >= 0) g.flying.splice(i, 1)
    g.events.push({ type: "remove", body: c })
}

function _handleHits(g, hits) {
    if (g.time < SETTLE_TIME) return
    for (var i = 0; i < hits.length; i++) {
        var h = hits[i], imp = h.impulse
        if (imp < HIT_THRESHOLD) continue
        var a = h.a, b = h.b
        var amount = imp - HIT_THRESHOLD
        // Ekollon i full fart slår extra hårt
        if ((a.kind === "cone" && a.data.dash) || (b.kind === "cone" && b.data.dash)) amount *= 1.6
        if (a.kind !== "cone") damage(g, a, amount, h.x, h.y)
        if (b.kind !== "cone") damage(g, b, amount, h.x, h.y)
        if (amount > 2) g.events.push({ type: "impact", x: h.x, y: h.y, power: amount })
    }
}

// ---- Uppdatering -------------------------------------------------------------

function update(g, dt) {
    var steps = Math.max(1, Math.min(4, Math.round(dt / DT)))
    for (var s = 0; s < steps; s++) _step(g)
}

function _step(g) {
    if (g.state === "won" || g.state === "lost") {
        P.step(g.world, DT)
        return
    }
    var hits = P.step(g.world, DT)
    g.time += DT
    g.stateTime += DT
    _handleHits(g, hits)

    // Troll och block som ramlar utanför världen
    for (var i = g.world.bodies.length - 1; i >= 0; i--) {
        var b = g.world.bodies[i]
        if (b.invMass === 0) continue
        if (b.y < -4 || b.x < -6 || b.x > WORLD_W + 8) {
            if (b.kind === "cone") removeCone(g, b)
            else destroy(g, b, b.x, b.y)
        }
    }

    // Kottar som stannat eller flugit länge försvinner
    for (i = g.flying.length - 1; i >= 0; i--) {
        var c = g.flying[i]
        c.data.age += DT
        c.data.still = P.speed(c) < 0.3 ? c.data.still + DT : 0
        if (c.data.still > 1.0 || c.data.age > 9) removeCone(g, c)
    }

    if (g.state === "flying" && g.flying.length === 0) { g.state = "waiting"; g.stateTime = 0 }

    // Alla troll borta: vänta en kort stund (eller tills allt lugnat sig) och vinn
    if (g.trolls === 0) {
        g.clearTime = (g.clearTime || 0) + DT
        if (g.clearTime > 2.5 || (g.clearTime > 0.8 && P.isSettled(g.world, 0.25))) {
            var left = g.queue.length + (g.current && !g.current.data.launched ? 1 : 0)
            var bonus = left * CONE_BONUS
            g.score += bonus
            g.state = "won"
            g.events.push({ type: "won", bonus: bonus, left: left })
        }
        return
    }

    // Allt har lugnat sig efter skottet: nästa kotte, eller förlust om de är slut
    if (g.state === "waiting" && (P.isSettled(g.world, 0.25) || g.stateTime > 6)) {
        if (!loadNext(g)) {
            g.state = "lost"
            g.events.push({ type: "lost" })
        }
    }
}

function stars(level, score) {
    var s = 0
    for (var i = 0; i < level.stars.length; i++) if (score >= level.stars[i]) s = i + 1
    return s
}

function takeEvents(g) {
    var e = g.events
    g.events = []
    return e
}
