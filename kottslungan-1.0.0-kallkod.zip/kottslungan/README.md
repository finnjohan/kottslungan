# Kottslungan – fysikspel för Ubuntu Touch

Hjälp ekorren att slunga kottar på trollen som har tagit över skogen. Kottslungan är
ett eget spel i den klassiska slangbellegenren. Figurer, banor, grafik och fysikmotor
är gjorda för det här spelet.

## Spelet
- Dra kotten bakåt och släpp. Prickarna visar banan.
- **Kottarna:**
  - **Grankotte:** vanlig kotte.
  - **Tallkotte:** tryck i luften så delar den sig i tre.
  - **Ekollon:** tryck i luften för extra fart. Det slår extra hårt.
  - **Kastanj:** tryck i luften så spricker den och knuffar undan allt runt omkring.
- **Trollen** finns i fyra storlekar: små, mellan, stora (med näverhatt) och gamla (med skägg).
- **Material:** trä, sten och is, plus klippor som inte går att rubba.
- **Poäng:** troll ger 5 000–10 000 poäng och block 300–1 000. Varje kotte som blir över ger 3 000 i bonus.
- **10 banor** med 1–3 stjärnor vardera. Nästa bana låses upp när den förra är klarad.
- Ljust tema ger dagsljus och mörkt tema kvällshimmel. Svenska och engelska.

## Teknik
- Ren QML och JavaScript. Inga behörigheter behövs.
- `qml/Physics.js` är en egen fysikmotor för lådor och cirklar. Den bygger på idéerna i
  [Box2D-Lite](https://github.com/erincatto/box2d-lite) av Erin Catto (zlib): klippta kontaktpunkter,
  ackumulerade impulser och warm starting, vilket gör att torn står stabilt.
- `qml/Game.js` innehåller reglerna: skada utifrån stötens impuls, förmågor, vinst och förlust, poäng och stjärnor.
- `qml/Levels.js` innehåller banorna som data, byggda med små hjälpfunktioner (`floor`, `col`, `beam`, `block`, `troll`, `rock`).
- Grafiken ritas med QML-objekt och SVG-bilder i `assets/`.

## Testa
```bash
node tests/levels.test.js     # varje bana står stilla och går att klara (en enkel datorspelare provar sikten)
node tests/i18n.test.js       # alla texter finns på svenska
GRID_UNIT_PX=16 UITK_ICON_THEME=suru qmlscene -I . qml/Main.qml --demo --lang=sv
```
Flaggor: `--demo` (egen databas med några klarade banor), `--lang`, `--theme`,
`--page=levels|settings|game`, `--level=<n>`, `--width=<gu>` och `--height=<gu>`.

## Bygga och installera
```bash
clickable build            # eller: click build <katalog>
adb push kottslungan_1.0.0_all.click /home/phablet/Downloads/
adb shell gdbus call --system --dest com.lomiri.click --object-path /com/lomiri/click \
    --method com.lomiri.click.Install /home/phablet/Downloads/kottslungan_1.0.0_all.click
```

## Licens
Copyright © 2026 Johan Finn. GNU General Public License v3.0 eller senare, se [LICENSE](LICENSE).
