#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Grafik och ljud för världen Trollen på månen (1.4.0). Allt skapas från grunden.
# Kör: python3 tools/make_moon.py   (kräver numpy, scipy och oggenc)
import math
import os
import random
import subprocess
import wave

import numpy as np
from scipy.signal import butter, sosfilt

ROOT = os.path.join(os.path.dirname(__file__), "..", "assets")
SND = os.path.join(ROOT, "sounds")


def save(name, w, h, body, viewbox=None):
    vb = viewbox or f"0 0 {w} {h}"
    with open(os.path.join(ROOT, name), "w") as f:
        f.write(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="{vb}">\n{body}\n</svg>\n')


# ---- Jorden, sedd från månen ---------------------------------------------------
# Qt:s SVG-stöd (SVG Tiny) klarar inte clipPath, så allt hålls innanför cirkeln
# för hand: kontinenternas hörn dras in mot mitten och natten är en skära.
def _inside(x, y, rmax):
    dx, dy = x - 64, y - 64
    d = math.hypot(dx, dy)
    if d > rmax:
        x, y = 64 + dx / d * rmax, 64 + dy / d * rmax
    return x, y


def earth():
    rnd = random.Random(41)
    b = ['<defs><radialGradient id="o" cx="0.4" cy="0.38" r="0.7"><stop offset="0" stop-color="#5BB6F0"/>'
         '<stop offset="1" stop-color="#1D5FA8"/></radialGradient></defs>',
         '<circle cx="64" cy="64" r="62" fill="#7EC8FF" opacity="0.25"/>',
         '<circle cx="64" cy="64" r="58" fill="url(#o)"/>']
    for (cx, cy, rx, ry, col) in [(40, 42, 22, 14, "#5E9E48"), (52, 52, 12, 18, "#6FA850"), (86, 74, 18, 24, "#7A9A48"),
                                  (92, 92, 10, 8, "#A88A55"), (30, 86, 14, 9, "#5E9E48")]:
        pts = []
        for k in range(14):
            a = 2 * math.pi * k / 14
            r = rnd.uniform(0.75, 1.15)
            x, y = _inside(cx + rx * r * math.cos(a), cy + ry * r * math.sin(a), 56)
            pts.append(f"{x:.1f},{y:.1f}")
        b.append(f'<polygon points="{" ".join(pts)}" fill="{col}" stroke-linejoin="round"/>')
    for i in range(9):
        x, y = _inside(rnd.uniform(14, 114), rnd.uniform(14, 114), 42)
        b.append(f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="{rnd.uniform(7, 12):.1f}" ry="{rnd.uniform(2.5, 4.5):.1f}" fill="#FFFFFF" opacity="0.75"/>')
    # Natten: en skära på högra sidan (ytterkanten plus en elliptisk skuggränsa)
    b.append('<path d="M64 6 A 58 58 0 0 1 64 122 A 26 58 0 0 0 64 6 Z" fill="#04101F" opacity="0.5"/>')
    b.append('<path d="M22 38 A 50 50 0 0 1 64 12" stroke="#FFFFFF" stroke-width="3" fill="none" opacity="0.45" stroke-linecap="round"/>')
    save("earth.svg", 128, 128, "\n".join(b))


# ---- Månlandskapet i fjärran: kullar, kratrar, kupoler och en raket ---------------
def moon_far():
    rnd = random.Random(42)
    W, H = 1600, 300
    b = []
    for layer, (base, col, amp) in enumerate([(150, "#5E5F66", 40), (205, "#7D7E86", 26)]):
        pts = [(0, H)]
        for x in range(0, W + 1, 40):
            y = base - amp * (0.5 + 0.5 * math.sin(x / (170 + layer * 60) + layer * 2)) - rnd.uniform(0, amp * 0.25)
            pts.append((x, y))
        pts.append((W, H))
        b.append(f'<polygon points="{" ".join(f"{x:.0f},{y:.0f}" for x, y in pts)}" fill="{col}"/>')
        for i in range(10):
            x = rnd.uniform(30, W - 30)
            y = base + rnd.uniform(10, 60) + layer * 20
            r = rnd.uniform(14, 34)
            b.append(f'<ellipse cx="{x:.0f}" cy="{y:.0f}" rx="{r:.0f}" ry="{r * 0.3:.0f}" fill="#000000" opacity="0.18"/>')
            b.append(f'<ellipse cx="{x:.0f}" cy="{y - r * 0.08:.0f}" rx="{r * 0.9:.0f}" ry="{r * 0.22:.0f}" fill="#FFFFFF" opacity="0.08"/>')
    # Trollens bas: kupoler, en antenn och en raket
    for (x, r) in [(1080, 44), (1160, 30), (1010, 24)]:
        b.append(f'<path d="M{x - r} 214 A {r} {r} 0 0 1 {x + r} 214 Z" fill="#B9C4CF" stroke="#6E7884" stroke-width="3"/>')
        b.append(f'<path d="M{x - r * 0.6} 200 A {r * 0.6} {r * 0.5} 0 0 1 {x + r * 0.1} {214 - r * 0.85}" stroke="#FFFFFF" stroke-width="4" fill="none" opacity="0.5"/>')
    b.append('<path d="M1230 214 L1230 140 M1214 150 L1246 150 M1218 162 L1242 162" stroke="#9AA4AE" stroke-width="4"/>')
    b.append('<circle cx="1230" cy="136" r="6" fill="#FF5A4A"/>')
    b.append('<path d="M360 196 L360 120 Q372 92 384 120 L384 196 Z" fill="#E8ECF0" stroke="#7A848E" stroke-width="3"/>')
    b.append('<path d="M360 170 L346 198 L360 196 Z M384 170 L398 198 L384 196 Z" fill="#D9534F"/>')
    b.append('<circle cx="372" cy="140" r="7" fill="#5BB6F0" stroke="#7A848E" stroke-width="2"/>')
    save("moon-far.svg", W, H, "\n".join(b))


# ---- Troll med antenn (små och mellan) och befälhavaren i rymddräkt -------------
TROLL_FACE = '''  <path d="M26 40 q10 -8 20 0" stroke="{hair}" stroke-width="6" fill="none" stroke-linecap="round"/>
  <path d="M54 40 q10 -8 20 0" stroke="{hair}" stroke-width="6" fill="none" stroke-linecap="round"/>
  <circle cx="37" cy="47" r="6" fill="#FFFFFF"/><circle cx="63" cy="47" r="6" fill="#FFFFFF"/>
  <circle cx="35" cy="48" r="3" fill="#1A1A1A"/><circle cx="61" cy="48" r="3" fill="#1A1A1A"/>
  <path d="M48 48 q-6 22 -2 30 q8 6 14 0 q2 -10 -6 -30z" fill="{nose}" stroke="{line}" stroke-width="2"/>
  <path d="M34 82 q6 -4 12 0 M58 82 q6 -4 10 0" stroke="{line}" stroke-width="3" fill="none" stroke-linecap="round"/>'''


def troll_svg(name, skin, line, nose, hair, extra_back="", extra_front=""):
    b = [f'<path d="M10 46 q-10 -14 -2 -24 q10 4 14 16z" fill="{skin}" stroke="{line}" stroke-width="2"/>',
         f'<path d="M90 46 q10 -14 2 -24 q-10 4 -14 16z" fill="{skin}" stroke="{line}" stroke-width="2"/>',
         extra_back,
         f'<circle cx="50" cy="54" r="44" fill="{skin}" stroke="{line}" stroke-width="3"/>',
         '<ellipse cx="38" cy="38" rx="14" ry="9" fill="#FFFFFF" opacity="0.18"/>',
         TROLL_FACE.format(hair=hair, nose=nose, line=line),
         extra_front]
    with open(os.path.join(ROOT, name), "w") as f:
        f.write('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">\n' + "\n".join(x for x in b if x) + "\n</svg>\n")


def antenna(color):
    return (f'<path d="M50 12 L50 6" stroke="#8C949C" stroke-width="3" stroke-linecap="round"/>'
            f'<circle cx="50" cy="5" r="4.5" fill="{color}" stroke="#5A6068" stroke-width="1.5"/>')


def trolls():
    troll_svg("troll-small-moon.svg", "#9A8A70", "#5E5040", "#B49A7A", "#4A3A2A", extra_front=antenna("#FF5A4A"))
    troll_svg("troll-medium-moon.svg", "#7F8F62", "#4A5634", "#98A672", "#3A3020", extra_front=antenna("#FFD84A"))
    # Befälhavaren: vit rymddräkt runt halsen, ett märke med en kotte och två antenner
    suit = ('<path d="M10 82 Q50 104 90 82 L94 100 L6 100 Z" fill="#EEF2F6" stroke="#8A96A2" stroke-width="3"/>'
            '<rect x="24" y="92" width="52" height="6" rx="3" fill="#D9534F"/>'
            '<circle cx="76" cy="88" r="6" fill="#2F6FB4" stroke="#FFFFFF" stroke-width="2"/>'
            '<ellipse cx="76" cy="88" rx="2.2" ry="3.4" fill="#C9A066"/>')
    ant = ('<path d="M36 14 L31 6 M64 14 L69 6" stroke="#8C949C" stroke-width="3" stroke-linecap="round"/>'
           '<circle cx="31" cy="5" r="4.5" fill="#7CFF8A" stroke="#4A6050" stroke-width="1.5"/>'
           '<circle cx="69" cy="5" r="4.5" fill="#7CFF8A" stroke="#4A6050" stroke-width="1.5"/>')
    troll_svg("troll-astronaut.svg", "#6E9A8A", "#3A5A4E", "#86B2A0", "#2A3A34", extra_front=suit + ant)


# ---- Ljud ----------------------------------------------------------------------
SR = 22050
rng = np.random.default_rng(4140)


def t_of(sec):
    return np.arange(int(sec * SR)) / SR


def band(x, lo, hi):
    return sosfilt(butter(2, [lo, hi], "band", fs=SR, output="sos"), x)


def low(x, f):
    return sosfilt(butter(2, f, "low", fs=SR, output="sos"), x)


def place(buf, clip, at, wrap=False):
    i = int(at * SR) % len(buf) if wrap else int(at * SR)
    n = min(len(clip), len(buf) - i)
    buf[i:i + n] += clip[:n]
    if wrap and n < len(clip):
        buf[:len(clip) - n] += clip[n:]


def write_wav(path, x):
    x = np.asarray(x, dtype=float)
    x = x / (np.max(np.abs(x)) or 1) * 0.85
    fade = min(len(x), int(0.01 * SR))
    x[-fade:] *= np.linspace(1, 0, fade)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((x * 32767).astype("<i2").tobytes())


def sfx_pop():            # bubbelhjälmen spricker: ett plopp och glasklirr
    t = t_of(0.5)
    plop = np.sin(2 * np.pi * np.cumsum(np.geomspace(420, 1500, len(t))) / SR) * np.exp(-t * 30)
    tink = np.zeros(len(t))
    for k in range(5):
        tt = t_of(0.3)
        f = rng.uniform(2600, 5200)
        place(tink, (np.sin(2 * np.pi * f * tt) + 0.4 * np.sin(2 * np.pi * f * 2.76 * tt)) * np.exp(-tt * 22), 0.02 + 0.035 * k)
    hiss = band(rng.normal(size=len(t)), 2000, 8000) * np.exp(-t * 18)
    return 0.8 * plop + 0.35 * tink + 0.25 * hiss


def sfx_metal():          # plåt som går sönder: ett klang med oharmoniska deltoner
    t = t_of(0.8)
    out = np.zeros(len(t))
    for f, a, d in [(310, 1, 6), (742, 0.7, 8), (1290, 0.5, 10), (1980, 0.35, 13), (2870, 0.25, 16)]:
        out += a * np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) * np.exp(-t * d)
    clank = band(rng.normal(size=len(t)), 800, 6000) * np.exp(-t * 40)
    return 0.6 * out + 0.6 * clank


def ambience_moon(sec=40.0):
    # Lugn rymdmusik: fyra ackord à 10 s med mjuka pads, ett långsamt svep,
    # några pip från basen och ett lågt brum. Allt läggs runt i bufferten så att
    # loopen går jämnt ut, och filtret körs två varv så att skarven inte klickar.
    n = int(sec * SR)
    out = np.zeros(n)
    chords = [[146.83, 220.0, 261.63, 329.63], [116.54, 174.61, 220.0, 293.66],
              [174.61, 220.0, 261.63, 329.63], [130.81, 196.0, 246.94, 293.66]]
    seg = sec / 4
    for i, ch in enumerate(chords):
        L = seg + 4
        tt = t_of(L)
        env = np.minimum(1, tt / 3) * np.minimum(1, (L - tt) / 3)
        pad = np.zeros(len(tt))
        for f in ch:
            for det in (-0.6, 0.6):
                pad += np.sin(2 * np.pi * (f + det) * tt) + 0.3 * np.sin(2 * np.pi * 2 * (f + det) * tt)
        place(out, pad * env * 0.18, i * seg - 2, wrap=True)
    tt = np.arange(n) / SR
    out += 0.25 * np.sin(2 * np.pi * 55 * tt) * (0.6 + 0.4 * np.sin(2 * np.pi * tt * 2 / sec))
    notes = [587.33, 659.25, 880.0, 987.77, 1174.66, 1318.5]
    for k in range(18):
        tb = t_of(0.35)
        f = notes[rng.integers(len(notes))]
        beep = np.sin(2 * np.pi * f * tb) * np.exp(-tb * 9) * 0.35
        place(out, beep, rng.uniform(0, sec), wrap=True)
    sos = butter(2, 2400, "low", fs=SR, output="sos")
    out = sosfilt(sos, np.concatenate([out, out]))[n:]
    out += 0.35 * np.roll(out, int(0.45 * SR))          # eko
    return out


def write_ogg(name, x):
    tmp = os.path.join(SND, name + ".tmp.wav")
    write_wav(tmp, x)
    subprocess.run(["oggenc", "-Q", "-q", "2", "-o", os.path.join(SND, name + ".ogg"), tmp], check=True)
    os.remove(tmp)


if __name__ == "__main__":
    earth()
    moon_far()
    trolls()
    write_wav(os.path.join(SND, "pop.wav"), sfx_pop())
    write_wav(os.path.join(SND, "break-metal.wav"), sfx_metal())
    write_ogg("ambience-moon", ambience_moon())
    print("klart")
