#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Grafik till Isfiskesjön (1.10.0): troll med öronlappsmössa och pälshuva,
# isfiskaren, sprickor i isen och den frusna sjön med stranden långt bort.
# Kör: python3 tools/make_icelake.py   (skriver till assets/)
import os, random

OUT = os.path.join(os.path.dirname(__file__), "..", "assets")


def write(name, body, view="0 0 100 100", extra=""):
    with open(os.path.join(OUT, name), "w") as f:
        f.write('<svg xmlns="http://www.w3.org/2000/svg" viewBox="%s"%s>\n%s</svg>\n' % (view, extra, body))


def face(line, nose, brow="#3A3020", cheeks=True):
    out = ''
    if cheeks:   # röda kinder av kylan
        out += '''  <ellipse cx="25" cy="64" rx="8" ry="5" fill="#E86A6A" opacity="0.45"/>
  <ellipse cx="75" cy="64" rx="8" ry="5" fill="#E86A6A" opacity="0.45"/>
'''
    return out + f'''  <path d="M26 40 q10 -8 20 0" stroke="{brow}" stroke-width="6" fill="none" stroke-linecap="round"/>
  <path d="M54 40 q10 -8 20 0" stroke="{brow}" stroke-width="6" fill="none" stroke-linecap="round"/>
  <circle cx="37" cy="47" r="6" fill="#FFFFFF"/><circle cx="63" cy="47" r="6" fill="#FFFFFF"/>
  <circle cx="35" cy="48" r="3" fill="#1A1A1A"/><circle cx="61" cy="48" r="3" fill="#1A1A1A"/>
  <path d="M48 48 q-6 22 -2 30 q8 6 14 0 q2 -10 -6 -30z" fill="{nose}" stroke="{line}" stroke-width="2"/>
  <ellipse cx="54" cy="74" rx="4" ry="3" fill="#E86A6A" opacity="0.6"/>
  <path d="M34 82 q6 -4 12 0 M58 82 q6 -4 10 0" stroke="{line}" stroke-width="3" fill="none" stroke-linecap="round"/>
'''


def body(skin, line, ears=True):
    out = ''
    if ears:
        out += f'''  <path d="M10 46 q-10 -14 -2 -24 q10 4 14 16z" fill="{skin}" stroke="{line}" stroke-width="2"/>
  <path d="M90 46 q10 -14 2 -24 q-10 4 -14 16z" fill="{skin}" stroke="{line}" stroke-width="2"/>
'''
    return out + f'''  <circle cx="50" cy="54" r="44" fill="{skin}" stroke="{line}" stroke-width="3"/>
  <ellipse cx="38" cy="38" rx="14" ry="9" fill="#FFFFFF" opacity="0.18"/>
'''


# Litet troll med röd öronlappsmössa
SKIN, LINE, NOSE = "#7F8F62", "#4A5634", "#98A672"
small = body(SKIN, LINE, ears=False) + '''  <!-- öronlappsmössa -->
  <path d="M10 40 q0 -38 40 -38 q40 0 40 38z" fill="#C8382E" stroke="#7A1E18" stroke-width="2"/>
  <path d="M8 36 q-2 26 8 34 q8 -4 8 -14 q0 -10 -2 -20z" fill="#C8382E" stroke="#7A1E18" stroke-width="2"/>
  <path d="M92 36 q2 26 -8 34 q-8 -4 -8 -14 q0 -10 2 -20z" fill="#C8382E" stroke="#7A1E18" stroke-width="2"/>
  <path d="M12 36 q38 -10 76 0 v6 q-38 -10 -76 0z" fill="#F2E8DA" stroke="#B8A890" stroke-width="1.5"/>
  <path d="M16 68 q-4 10 -2 18 M84 68 q4 10 2 18" stroke="#7A1E18" stroke-width="2" fill="none"/>
  <circle cx="14" cy="88" r="4" fill="#F2E8DA"/><circle cx="86" cy="88" r="4" fill="#F2E8DA"/>
  <path d="M30 18 h40 M26 26 h48" stroke="#E8685E" stroke-width="3" opacity="0.6"/>
''' + face(LINE, NOSE)
write("troll-small-icelake.svg", small)

# Mellanstort troll med pälshuva
SKIN, LINE, NOSE = "#7F8F62", "#4A5634", "#98A672"
medium = body(SKIN, LINE, ears=False) + '''  <!-- pälshuva -->
  <path d="M6 52 q-4 -50 44 -50 q48 0 44 50 q-8 -2 -10 -10 q-4 -26 -34 -26 q-30 0 -34 26 q-2 8 -10 10z" fill="#6E4A2A" stroke="#3E2814" stroke-width="2"/>
  <path d="M10 46 q2 -32 40 -34 q38 2 40 34" stroke="#E8DCC8" stroke-width="9" fill="none" stroke-linecap="round"/>
  <path d="M10 46 q2 -32 40 -34 q38 2 40 34" stroke="#C8B8A0" stroke-width="2" fill="none" stroke-dasharray="3 4"/>
''' + face(LINE, NOSE)
write("troll-medium-icelake.svg", medium)

# Isfiskaren: stor pälsmössa, frostvitt skägg, randig halsduk och ett pimpelspö
SKIN, LINE, NOSE = "#76866A", "#44503A", "#92A07A"
angler = '''  <!-- pimpelspöt över axeln -->
  <path d="M88 70 L99 6" stroke="#5A3A1E" stroke-width="4" stroke-linecap="round"/>
  <path d="M99 6 q-6 30 -2 52" stroke="#DDE8F0" stroke-width="1.2" fill="none"/>
  <circle cx="97" cy="58" r="3" fill="#E8382E"/>
''' + body(SKIN, LINE) + '''  <!-- skägg med frost -->
  <path d="M18 62 q4 30 32 34 q28 -4 32 -34 q-10 8 -20 6 q-12 8 -24 0 q-10 2 -20 -6z" fill="#E8EEF2" stroke="#9AAAB6" stroke-width="2"/>
  <path d="M30 76 l4 8 M42 82 l2 9 M58 82 l-2 9 M70 76 l-4 8" stroke="#B8C8D4" stroke-width="2"/>
  <!-- halsduk -->
  <path d="M16 84 q34 18 68 0 l2 10 q-36 16 -72 0z" fill="#2E6AB8" stroke="#1A3E70" stroke-width="2"/>
  <path d="M30 90 v8 M44 93 v7 M58 93 v7 M72 89 v8" stroke="#F2E8DA" stroke-width="4"/>
  <!-- stor pälsmössa -->
  <path d="M10 36 q-4 -36 40 -34 q44 -2 40 34z" fill="#5A3A22" stroke="#2E1C10" stroke-width="2"/>
  <path d="M6 36 q44 -16 88 0 q2 8 -4 10 q-40 -12 -80 0 q-6 -2 -4 -10z" fill="#8A6A48" stroke="#2E1C10" stroke-width="2"/>
  <g stroke="#3E2814" stroke-width="1.5" fill="none"><path d="M24 14 q4 6 0 12"/><path d="M40 8 q4 6 0 12"/><path d="M58 8 q4 6 0 12"/><path d="M74 14 q4 6 0 12"/></g>
  <!-- frost på ögonbrynen -->
  <path d="M26 40 q10 -8 20 0" stroke="#E8EEF2" stroke-width="7" fill="none" stroke-linecap="round"/>
  <path d="M54 40 q10 -8 20 0" stroke="#E8EEF2" stroke-width="7" fill="none" stroke-linecap="round"/>
  <circle cx="37" cy="48" r="6" fill="#FFFFFF"/><circle cx="63" cy="48" r="6" fill="#FFFFFF"/>
  <circle cx="35" cy="49" r="3" fill="#1A1A1A"/><circle cx="61" cy="49" r="3" fill="#1A1A1A"/>
  <path d="M48 50 q-6 18 -2 24 q8 6 14 0 q2 -8 -6 -24z" fill="#C88A7A" stroke="''' + LINE + '''" stroke-width="2"/>
  <ellipse cx="24" cy="62" rx="7" ry="4" fill="#E86A6A" opacity="0.5"/>
  <ellipse cx="76" cy="62" rx="7" ry="4" fill="#E86A6A" opacity="0.5"/>
'''
write("troll-angler.svg", angler)

# Sprickor i isen (läggs ovanpå ett isflak; sträcks ut till flakets storlek)
r = random.Random(101)
paths = []
for k in range(3):
    x = 30 + k * 70 + r.uniform(-10, 10)
    y = 0
    d = f"M{x:.0f} {y}"
    for _ in range(4):
        x += r.uniform(-18, 18); y += r.uniform(8, 14)
        d += f" L{x:.0f} {y:.0f}"
    paths.append(d)
    # en gren från mitten
    bx, by = x - r.uniform(5, 15), 20
    paths.append(f"M{bx:.0f} {by} l{r.uniform(-30, 30):.0f} {r.uniform(6, 14):.0f}")
lines = "".join(f'<path d="{p}" stroke="#2E6A9A" stroke-width="3.5" fill="none" stroke-linejoin="round"/>' for p in paths)
lines += "".join(f'<path d="{p}" stroke="#FFFFFF" stroke-width="1.5" fill="none" stroke-linejoin="round"/>' for p in paths)
write("ice-cracks.svg", "  " + lines + "\n", "0 0 240 50", ' preserveAspectRatio="none"')

# ---- Stranden långt bort och den frusna sjön (1600 × 400) -------------------------
def spruce(x, base, h, color):
    w = h * 0.36
    return (f'<path d="M{x:.0f} {base - h:.0f} L{x - w * 0.5:.0f} {base - h * 0.45:.0f} L{x - w * 0.25:.0f} {base - h * 0.45:.0f} '
            f'L{x - w:.0f} {base:.0f} L{x + w:.0f} {base:.0f} L{x + w * 0.25:.0f} {base - h * 0.45:.0f} L{x + w * 0.5:.0f} {base - h * 0.45:.0f}z" fill="{color}"/>')


rr = random.Random(7)
far = []
# låga berg längst bort
far.append('<path d="M0 250 q200 -60 420 -20 q160 -50 360 0 q220 -60 460 -10 q200 -30 360 10 V300 H0z" fill="#B8C8D8"/>')
# skogen på andra stranden
x = -10
while x < 1620:
    far.append(spruce(x, 282, rr.uniform(26, 52), "#4A6276"))
    x += rr.uniform(10, 22)
far.append('<rect x="0" y="278" width="1600" height="10" fill="#4A6276"/>')
# röda stugor med vita knutar och snö på taken
for cx in (300, 360, 1150):
    far.append(f'<rect x="{cx - 22}" y="262" width="44" height="22" fill="#A8322A"/>')
    far.append(f'<path d="M{cx - 26} 264 L{cx} 248 L{cx + 26} 264z" fill="#F4F8FB"/>')
    far.append(f'<rect x="{cx - 22}" y="262" width="3" height="22" fill="#FFFFFF"/><rect x="{cx + 19}" y="262" width="3" height="22" fill="#FFFFFF"/>')
    far.append(f'<rect x="{cx - 6}" y="270" width="8" height="7" fill="#FFE08A"/>')
    far.append(f'<rect x="{cx + 10}" y="246" width="5" height="12" fill="#5A4A44"/>')
# snöstrand och den frusna sjön
far.append('<path d="M0 286 H1600 V292 H0z" fill="#F4F8FB"/>')
far.append('<rect x="0" y="292" width="1600" height="108" fill="#DCE8F2"/>')
for k in range(9):
    y = 300 + k * 11
    far.append(f'<path d="M0 {y} H1600" stroke="#C8DAE8" stroke-width="{1 + k * 0.4:.1f}" opacity="0.7"/>')
# fisketält och små isfiskare långt ute på isen
for cx, col in ((620, "#E8A02A"), (820, "#3A7AC8"), (1400, "#C8382E")):
    far.append(f'<path d="M{cx - 14} 318 L{cx} 298 L{cx + 14} 318z" fill="{col}"/><path d="M{cx} 298 L{cx + 14} 318 h-8z" fill="#000000" opacity="0.15"/>')
for cx in (700, 960, 1250):
    far.append(f'<circle cx="{cx}" cy="306" r="3" fill="#3A3A44"/><rect x="{cx - 2}" y="308" width="4" height="7" fill="#3A3A44"/>')
write("icelake-far.svg", "  " + "".join(far) + "\n", "0 0 1600 400", ' preserveAspectRatio="none"')
print("ok")
