#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Skapar spelets alla ljud från grunden med numpy (inga inspelningar, inga
# lånade ljud). Kör: python3 tools/make_sounds.py  (kräver numpy, scipy, oggenc)
# Bakgrundsljuden blir .ogg och loopar sömlöst; effekterna blir korta .wav.
import os, subprocess, wave
import numpy as np
from scipy.signal import butter, sosfilt

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "sounds")
rng = np.random.default_rng(2026)


def t_of(sec):
    return np.arange(int(sec * SR)) / SR


def periodic_noise(n, lo, hi, tilt=0.0, gen=None):
    """Brus med frekvenser mellan lo och hi Hz. Skapas i frekvensplanet, så
    det är periodiskt och loopar utan skarv."""
    gen = gen or rng
    f = np.fft.rfftfreq(n, 1 / SR)
    # Mjuka kanter (logistiska) så att det inte låter som radiobrus
    w = 1 / (1 + np.exp(-(np.log2(np.maximum(f, 1)) - np.log2(lo)) * 6)) * 1 / (1 + np.exp((np.log2(np.maximum(f, 1)) - np.log2(hi)) * 6))
    spec = (gen.normal(size=len(f)) + 1j * gen.normal(size=len(f))) * w / np.maximum(f, 1) ** tilt
    spec[0] = 0
    x = np.fft.irfft(spec, n)
    return x / np.max(np.abs(x))


def slow_lfo(n, cycles, phase=0.0):
    # Ett helt antal svängningar per loop, så att loopen går ihop
    return 0.5 + 0.5 * np.sin(2 * np.pi * cycles * np.arange(n) / n + phase)


def env(n, attack, release):
    a = max(1, int(attack * SR)); r = max(1, int(release * SR))
    e = np.ones(n)
    e[:a] = np.linspace(0, 1, a)
    e[-r:] *= np.linspace(1, 0, r) ** 2
    return e


def chirp(f0, f1, sec, harm=(1.0, 0.25)):
    t = t_of(sec)
    f = np.geomspace(f0, f1, len(t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = sum(a * np.sin((i + 1) * ph) for i, a in enumerate(harm))
    return y * np.sin(np.pi * t / sec) ** 2


def place(buf, clip, at):
    """Lägger in ett ljud i en loop; det som går över slutet börjar om i början."""
    n = len(buf); i = int(at * SR) % n
    for k in range(0, len(clip)):
        buf[(i + k) % n] += clip[k]


def bird_song(kind):
    if kind == 0:   # tvåtonsvissling, som en talgoxe
        parts = []
        for _ in range(3):
            parts += [chirp(4200, 4000, 0.11), np.zeros(int(0.05 * SR)), chirp(3100, 3000, 0.13), np.zeros(int(0.07 * SR))]
        return np.concatenate(parts)
    if kind == 1:   # snabb drill
        return np.concatenate([np.concatenate([chirp(5200, 3800, 0.035), np.zeros(int(0.018 * SR))]) for _ in range(14)])
    # mjuk fallande ton
    return np.concatenate([chirp(2600, 1900, 0.35, (1, 0.4, 0.1)), np.zeros(int(0.12 * SR)), chirp(2500, 1800, 0.3, (1, 0.4, 0.1))])


def ambience_forest(sec=40):
    n = int(sec * SR)
    wind = periodic_noise(n, 80, 900, tilt=0.8) * (0.25 + 0.35 * slow_lfo(n, 3) * slow_lfo(n, 5, 1.0))
    leaves = periodic_noise(n, 1500, 4500, tilt=0.6) * 0.015 * slow_lfo(n, 4, 2.0)
    birds = np.zeros(n)
    t = 1.5
    while t < sec:
        kind = int(rng.integers(0, 3))
        song = bird_song(kind) * rng.uniform(0.12, 0.25)
        place(birds, song, t)
        t += rng.uniform(2.5, 6.0)
    return 0.55 * wind + leaves + birds


def ambience_winter(sec=40):
    n = int(sec * SR)
    # Vinden viner: två band som sakta glider upp och ned
    out = np.zeros(n)
    for lo, hi, cyc, amp in [(150, 500, 2, 0.5), (500, 1300, 3, 0.25)]:
        out += periodic_noise(n, lo, hi, tilt=0.5) * amp * (0.3 + 0.7 * slow_lfo(n, cyc, rng.uniform(0, 6)) ** 2)
    gust = periodic_noise(n, 700, 2200, tilt=0.6) * 0.06 * slow_lfo(n, 5, 0.5) ** 3
    # Glittrande iskristaller, mycket svaga
    sparkle = np.zeros(n)
    t = 2.0
    while t < sec:
        f = rng.choice([1568, 1760, 2093, 2349, 2637])
        tt = t_of(1.4)
        tone = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2.01 * f * tt)) * np.exp(-tt * 3.5)
        place(sparkle, tone * 0.06, t)
        t += rng.uniform(1.5, 4.5)
    return 0.6 * out + gust + sparkle


def gull_call():
    """Ett måsskrik: en hes ton som stiger och faller, \"kjau\"."""
    sec = rng.uniform(0.32, 0.5)
    t = t_of(sec)
    f0 = rng.uniform(1100, 1500)
    f = f0 * (1 + 0.35 * np.sin(np.pi * t / sec)) * (1 - 0.25 * t / sec)
    ph = 2 * np.pi * np.cumsum(f) / SR
    tone = np.sin(ph) + 0.6 * np.sin(2 * ph) + 0.35 * np.sin(3 * ph) + 0.2 * np.sin(4 * ph)
    rough = 1 + 0.35 * np.sin(2 * np.pi * 70 * t)           # hesheten
    return tone * rough * env(len(t), 0.03, sec * 0.5)


def ambience_sea(sec=40):
    n = int(sec * SR)
    # Vågor: brus som sväller och drar sig tillbaka, åtta gånger per loop
    swell = slow_lfo(n, 8, 0.0)
    swell2 = slow_lfo(n, 5, 1.3)
    surf = periodic_noise(n, 120, 2500, tilt=0.7) * (0.15 + 0.85 * swell ** 3)
    hiss = periodic_noise(n, 1800, 6000, tilt=0.4) * 0.18 * swell ** 4
    deep = periodic_noise(n, 40, 220, tilt=0.5) * 0.35 * (0.4 + 0.6 * swell2)
    # Skvalp mot stranden: små mjuka klunkar
    lap = np.zeros(n)
    t = 0.8
    while t < sec:
        tt = t_of(0.12)
        f = rng.uniform(260, 520)
        place(lap, np.sin(2 * np.pi * f * tt * (1 - 1.5 * tt)) * np.exp(-tt * 40) * 0.08, t)
        t += rng.uniform(0.25, 1.1)
    # Måsar på avstånd
    gulls = np.zeros(n)
    t = 2.0
    while t < sec:
        for k in range(int(rng.integers(1, 4))):
            place(gulls, gull_call() * rng.uniform(0.06, 0.14), t + k * rng.uniform(0.35, 0.55))
        t += rng.uniform(4.0, 8.0)
    return 0.7 * surf + hiss + deep + lap + gulls


def ambience_cave(sec=40):
    """Trolldiskot: discomusik i 120 bpm som hörs genom berget (20 takter = 40 s,
    så loopen går jämnt ut), med eko från grottväggarna och droppande vatten."""
    n = int(sec * SR)
    out = np.zeros(n)
    beat = 0.5                       # sekunder per taktslag
    # Kick på varje slag
    for k in range(int(sec / beat)):
        tt = t_of(0.25)
        f = 50 + 90 * np.exp(-tt * 30)
        ph = 2 * np.pi * np.cumsum(f) / SR
        place(out, np.sin(ph) * np.exp(-tt * 12) * 0.9, k * beat)
    # Klapp på 2 och 4, öppen hi-hat på efterslagen
    clap_f = butter(2, [900, 3000], "band", fs=SR, output="sos")
    hat_f = butter(2, 7000, "high", fs=SR, output="sos")
    for k in range(int(sec / beat)):
        if k % 2 == 1:
            tt = t_of(0.18)
            place(out, sosfilt(clap_f, rng.normal(size=len(tt))) * np.exp(-tt * 22) * 0.35, k * beat)
        tt = t_of(0.12)
        place(out, sosfilt(hat_f, rng.normal(size=len(tt))) * np.exp(-tt * 30) * 0.18, k * beat + beat / 2)
    # Oktavhoppande discobas och ackordstötar: Am7 – Dm7 – G – Cmaj7, två takter var
    roots = [110.0, 146.83, 98.0, 130.81]
    chords = [[220.0, 261.63, 329.63, 392.0], [293.66, 349.23, 440.0, 523.25],
              [196.0, 246.94, 293.66, 392.0], [261.63, 329.63, 392.0, 493.88]]
    for bar in range(20):
        ci = (bar // 2) % 4
        for e in range(8):           # åttondelar
            tt = t_of(0.2)
            f = roots[ci] * (2 if e % 2 else 1)
            note = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(4 * np.pi * f * tt)) * np.exp(-tt * 9) * 0.45
            place(out, note, bar * 2.0 + e * 0.25)
        for st in (0.75, 1.75):      # stötar på efterslagen
            tt = t_of(0.22)
            ch = sum(np.sin(2 * np.pi * f * tt) + 0.4 * np.sign(np.sin(2 * np.pi * f * tt)) * 0.3 for f in chords[ci])
            place(out, ch * np.exp(-tt * 14) * 0.12, bar * 2.0 + st)
    # Musiken hörs genom berget: dämpa diskanten och lägg på eko
    out = sosfilt(butter(2, 2200, "low", fs=SR, output="sos"), np.concatenate([out, out]))[n:]   # två varv: inget klick vid skarven
    echo = np.zeros(n)
    for d, g in [(0.23, 0.35), (0.47, 0.2), (0.71, 0.1)]:
        echo += np.roll(out, int(d * SR)) * g
    out = out + echo
    # Droppande vatten
    drips = np.zeros(n)
    t = 1.3
    while t < sec:
        tt = t_of(0.15)
        f = rng.uniform(900, 1600) * (1 + 2.5 * tt)
        ph = 2 * np.pi * np.cumsum(f) / SR
        place(drips, np.sin(ph) * np.exp(-tt * 35) * 0.25, t)
        t += rng.uniform(2.5, 6.0)
    return out * 0.8 + drips


def music_box(f, sec=0.9):
    """En speldosaton: ren grundton, lite fjärde överton och snabb avklingning."""
    tt = t_of(sec)
    return (np.sin(2 * np.pi * f * tt) + 0.35 * np.sin(2 * np.pi * 3.98 * f * tt) * np.exp(-tt * 12)
            + 0.15 * np.sin(2 * np.pi * 2 * f * tt)) * np.exp(-tt * 4.5) * (1 - np.exp(-tt * 600))


def ambience_candy(sec=40):
    """Godisfabriken: lekfull speldosemelodi i 120 bpm (20 takter = 40 s) över
    maskiner som tuggar och klonkar i takt."""
    n = int(sec * SR)
    out = np.zeros(n)
    beat = 0.5
    C, D, E, F, G, A, B, C2, D2, E2, G2 = 523.25, 587.33, 659.25, 698.46, 783.99, 880.0, 987.77, 1046.5, 1174.7, 1318.5, 1568.0
    # Melodi i åttondelar, fyra takter som upprepas (None = paus)
    phrase = [E2, G2, E2, C2, D2, None, G, None,
              C2, E2, D2, C2, B, None, G, None,
              A, C2, B, A, G, E, G, C2,
              D2, None, B, G, C2, None, None, None]
    for bar in range(20):
        for e in range(8):
            f = phrase[(bar % 4) * 8 + e]
            if f is not None:
                place(out, music_box(f) * 0.22, bar * 2.0 + e * 0.25)
    # Bas: C – A – F – G, staccato på slagen
    roots = [130.81, 110.0, 87.31, 98.0]
    for bar in range(20):
        r = roots[bar % 4]
        for k in range(4):
            tt = t_of(0.22)
            f = r * (1.5 if k == 2 else 1)
            place(out, (np.sin(2 * np.pi * f * tt) + 0.4 * np.sin(4 * np.pi * f * tt)) * np.exp(-tt * 14) * 0.35, bar * 2.0 + k * beat)
    # Maskinerna: ett tuggande brus på varje slag och ett klonk på ettan
    chug_f = butter(2, [200, 900], "band", fs=SR, output="sos")
    for k in range(int(sec / beat)):
        tt = t_of(0.16)
        place(out, sosfilt(chug_f, rng.normal(size=len(tt))) * np.exp(-tt * 25) * 0.25, k * beat + beat / 2)
        if k % 4 == 0:
            tt = t_of(0.3)
            clank = sum(np.sin(2 * np.pi * f * tt) * a for f, a in [(420, 1), (1130, 0.6), (2210, 0.3)])
            place(out, clank * np.exp(-tt * 18) * 0.12, k * beat)
    # Ånga som pyser då och då
    hiss_f = butter(2, [3500, 7000], "band", fs=SR, output="sos")
    for bar in range(0, 20, 4):
        tt = t_of(0.6)
        place(out, sosfilt(hiss_f, rng.normal(size=len(tt))) * np.sin(np.pi * tt / 0.6) ** 2 * 0.015, bar * 2.0 + 1.25)
    return out


def calliope(f, sec):
    """En positivton (ångorgel): övertoner, vibrato och lite luft."""
    tt = t_of(sec)
    vib = 1 + 0.008 * np.sin(2 * np.pi * 6 * tt)
    ph = 2 * np.pi * np.cumsum(f * vib) / SR
    tone = np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.3 * np.sin(3 * ph) + 0.12 * np.sin(4 * ph)
    air = sosfilt(butter(2, [f * 0.9, f * 3], "band", fs=SR, output="sos"), rng.normal(size=len(tt))) * 0.08
    return (tone + air) * env(len(tt), 0.02, min(0.08, sec * 0.3))


def ambience_fair(sec=40):
    """Tivolit: en vals på positiv i 3/4, 144 bpm (32 takter = 40 s, fyra varv av melodin), med
    umpa-pa i basen och en svag publik i bakgrunden."""
    n = int(sec * SR)
    out = np.zeros(n)
    beat = 60 / 144
    bar = 3 * beat
    G, A, B, C2, D2, E2, Fs2, G2 = 392.0, 440.0, 493.88, 523.25, 587.33, 659.25, 739.99, 783.99
    # Melodi: (ton, längd i taktslag), åtta takter som upprepas
    tune = [(D2, 2), (B, 1), (G2, 3), (Fs2, 2), (E2, 1), (D2, 3),
            (C2, 2), (E2, 1), (A, 3), (B, 1), (C2, 1), (D2, 1), (B, 3),
            (D2, 2), (B, 1), (G2, 3), (A, 2), (Fs2, 1), (G2, 3)]
    total = sum(d for _, d in tune)            # 24 slag = 8 takter
    t = 0.0
    while t < sec - 0.01:
        for f, d in tune:
            if t >= sec - 0.01:
                break
            place(out, calliope(f, d * beat * 0.92) * 0.25, t)
            t += d * beat
    # Umpa-pa: bas på ettan, ackord på tvåan och trean (G – D – C – G per takt, två takter var)
    roots = [98.0, 146.83, 130.81, 98.0]
    chords = [[293.66, 392.0, 493.88], [293.66, 369.99, 440.0], [329.63, 392.0, 523.25], [293.66, 392.0, 493.88]]
    for k in range(int(round(sec / bar))):
        ci = (k // 2) % 4
        place(out, calliope(roots[ci], beat * 0.8) * 0.3, k * bar)
        for b in (1, 2):
            ch = sum(calliope(f, beat * 0.45) for f in chords[ci])
            place(out, ch * 0.07, k * bar + b * beat)
        tt = t_of(0.2)                         # mjuk puka på ettan
        place(out, np.sin(2 * np.pi * (70 + 60 * np.exp(-tt * 25)) * tt) * np.exp(-tt * 14) * 0.3, k * bar)
    # Publiken: svagt sorl
    crowd = periodic_noise(n, 300, 2500, tilt=0.6) * 0.05 * (0.6 + 0.4 * slow_lfo(n, 6, 0.3))
    return out + crowd


def harp(f, sec=1.6):
    """En harpton: knäppt sträng med snabb attack och lång avklingning."""
    tt = t_of(sec)
    tone = np.sin(2 * np.pi * f * tt) + 0.4 * np.sin(4 * np.pi * f * tt) * np.exp(-tt * 3) + 0.15 * np.sin(6 * np.pi * f * tt) * np.exp(-tt * 6)
    return tone * np.exp(-tt * 2.2) * (1 - np.exp(-tt * 500))


def pad(freqs, sec):
    """Mjuk matta: lätt ostämda sinustoner som sväller upp och klingar ut."""
    tt = t_of(sec)
    out = np.zeros(len(tt))
    for f in freqs:
        for d in (0.997, 1.003):
            out += np.sin(2 * np.pi * f * d * tt)
    return out * np.sin(np.pi * tt / sec) ** 1.5 / (2 * len(freqs))


def ambience_sky(sec=40):
    """Luftslottet: harpslingor och mjuka mattor i 96 bpm (16 takter = 40 s)
    över ett svagt sus av vind."""
    n = int(sec * SR)
    out = np.zeros(n)
    bar = 4 * 60 / 96
    # Fmaj7 – Am7 – Dm9 – B♭maj7, en takt var, fyra varv
    chords = [[174.61, 220.0, 261.63, 329.63], [220.0, 261.63, 329.63, 392.0],
              [146.83, 220.0, 261.63, 329.63], [116.54, 174.61, 220.0, 293.66]]
    for b in range(16):
        ch = chords[b % 4]
        place(out, pad([f * 2 for f in ch], bar * 1.15) * 0.35, b * bar - bar * 0.05)
        # Harpan går uppför ackordet i åttondelar, två oktaver
        notes = [f * 2 for f in ch] + [f * 4 for f in ch]
        for k in range(8):
            place(out, harp(notes[k]) * 0.14, b * bar + k * bar / 8)
    # Vinden: mjukt brus som sakta sväller
    gust = periodic_noise(n, 200, 1500, tilt=0.8) * 0.12 * (0.3 + 0.7 * slow_lfo(n, 4, 0.7) ** 2)
    return out + gust


def log_drum(f, sec=0.5):
    """Trumma av ihålig stock: kort ton som faller lite, med en knäpp i början."""
    tt = t_of(sec)
    ph = 2 * np.pi * np.cumsum(f * (1 + 0.15 * np.exp(-tt * 30))) / SR
    return (np.sin(ph) + 0.3 * np.sin(2.7 * ph)) * np.exp(-tt * 11)


def ambience_volcano(sec=40):
    """Vulkanön: trummor i 96 bpm (16 takter = 40 s), en stocktrumma som spelar en
    pentatonisk slinga i d-moll, ett lågt muller från berget och lava som bubblar."""
    n = int(sec * SR)
    out = np.zeros(n)
    beat = 60 / 96
    bar = 4 * beat
    # Djup trumma på 1 och 3, mindre trummor på åttondelarna emellan
    for k in range(16 * 4):
        tt = t_of(0.5)
        f = 55 + 60 * np.exp(-tt * 25)
        ph = 2 * np.pi * np.cumsum(f) / SR
        if k % 2 == 0:
            place(out, np.sin(ph) * np.exp(-tt * 7) * 0.8, k * beat)
        else:
            place(out, log_drum(147.0, 0.3) * 0.22, k * beat)
        if k % 4 == 3:
            place(out, log_drum(196.0, 0.3) * 0.18, k * beat + beat / 2)
    # Stocktrummans slinga: åtta noter per två takter, D F G A C
    scale = [293.66, 349.23, 392.0, 440.0, 523.25, 587.33]
    phrase = [0, 2, 3, 2, 4, 3, 1, 0, 0, 2, 3, 5, 4, 3, 2, 3]
    for b in range(16):
        for k in range(4):
            note = phrase[(b % 4) * 4 + k]
            place(out, log_drum(scale[note]) * 0.3, b * bar + k * beat + (beat / 2 if k == 3 else 0))
    # Mattan: låg kvint (D och A) som sakta sväller
    tt = np.arange(n) / SR
    drone = (np.sin(2 * np.pi * 73.42 * tt) + 0.6 * np.sin(2 * np.pi * 110.0 * tt) + 0.3 * np.sin(2 * np.pi * 146.83 * tt))
    out += drone * 0.12 * (0.5 + 0.5 * slow_lfo(n, 2))
    # Mullret från berget: lågt brus som väller upp några gånger per loop
    rumble = periodic_noise(n, 25, 120, tilt=0.5) * 0.35 * slow_lfo(n, 3, 1.0) ** 3
    # Lavan bubblar: korta, låga "blopp"
    bubbles = np.zeros(n)
    t = 0.4
    while t < sec:
        tt = t_of(0.18)
        f = rng.uniform(140, 260) * (1 + 1.8 * tt / 0.18)
        ph = 2 * np.pi * np.cumsum(f) / SR
        place(bubbles, np.sin(ph) * np.sin(np.pi * tt / 0.18) ** 2 * 0.25, t)
        t += rng.uniform(0.3, 1.4)
    return out + rumble + bubbles


# ---- Djungeltemplet (1.9.0) ----------------------------------------------------
# Egen slumpgenerator, så att de gamla ljuden inte ändras.
rng9 = np.random.default_rng(1909)


def marimba_note(f, sec=0.8):
    """Marimba: ren grundton, en svag överton på fyra gånger frekvensen som
    klingar av snabbt, och en mjuk träaktig attack."""
    tt = t_of(sec)
    y = np.sin(2 * np.pi * f * tt) + 0.35 * np.sin(2 * np.pi * 3.9 * f * tt) * np.exp(-tt * 25)
    return y * np.exp(-tt * 5.5) * (1 - np.exp(-tt * 400))


def frog_croak(f=190, sec=0.32):
    """Groda: en låg ton med skrovlig amplitudmodulering (~32 Hz)."""
    tt = t_of(sec)
    y = np.sin(2 * np.pi * f * tt) + 0.5 * np.sin(2 * np.pi * 2 * f * tt) + 0.25 * np.sin(2 * np.pi * 3 * f * tt)
    am = 0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 32 * tt))
    y = sosfilt(butter(2, 900, "low", fs=SR, output="sos"), y * am)
    return y * np.sin(np.pi * tt / sec) ** 0.6


def tree_frog(sec=0.5):
    """Lövgroda: korta, höga pip i snabb följd."""
    out = np.zeros(int(sec * SR))
    for k in range(6):
        tt = t_of(0.025)
        place(out, np.sin(2 * np.pi * 2900 * tt) * np.sin(np.pi * tt / 0.025) ** 2, k * 0.06)
    return out


def jungle_bird(kind):
    if kind == 0:   # visslande rop som stiger två gånger
        return np.concatenate([chirp(1400, 2600, 0.22, (1, 0.3)), np.zeros(int(0.08 * SR)), chirp(1500, 2900, 0.26, (1, 0.3))])
    if kind == 1:   # skrovligt kraxande, som en tukan
        tt = t_of(0.18)
        y = np.sin(2 * np.pi * 620 * tt) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 55 * tt))) * np.sin(np.pi * tt / 0.18)
        y = sosfilt(butter(2, [400, 2500], "band", fs=SR, output="sos"), y)
        return np.concatenate([y, np.zeros(int(0.12 * SR)), y * 0.8, np.zeros(int(0.12 * SR)), y * 0.6])
    # fallande drill
    return np.concatenate([np.concatenate([chirp(3600 - 120 * k, 2800 - 120 * k, 0.05), np.zeros(int(0.025 * SR))]) for k in range(9)])


def ambience_jungle(sec=40):
    """Djungeltemplet: marimba och trummor i 96 bpm (16 takter = 40 s, fyra varv av en
    fras på fyra takter), grodor, fåglar och ett svagt regn i lövverket."""
    n = int(sec * SR)
    out = np.zeros(n)
    beat = 60 / 96
    bar = 4 * beat
    # Trummor: djup trumma på ettan och trean, stocktrumma på efterslagen
    for k in range(16 * 4):
        if k % 2 == 0:
            tt = t_of(0.45)
            f = 70 + 50 * np.exp(-tt * 25)
            place(out, np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 8) * 0.55, k * beat)
        else:
            place(out, log_drum(220.0, 0.25) * 0.16, k * beat)
            place(out, log_drum(330.0, 0.2) * 0.1, k * beat + beat / 2)
    # Marimba: pentatonisk fras i G (G A B D E) över fyra takter, åttondelar med pauser
    g = {"G": 392.0, "A": 440.0, "B": 493.88, "D": 587.33, "E": 659.25, "g": 783.99, "d": 293.66}
    phrase = ["G", "B", "D", None, "E", "D", "B", None,
              "A", "B", "D", "E", "D", None, "B", "A",
              "G", "B", "D", None, "g", "E", "D", None,
              "E", "D", "B", "A", "G", None, "d", None]
    for b in range(16):
        base = (b % 4) * 8
        for k in range(8):
            note = phrase[base + k]
            if note:
                place(out, marimba_note(g[note]) * 0.32, b * bar + k * beat / 2)
    # Basmarimba: grundtonen på varje takt (G, C, D, G)
    bass = [98.0, 130.81, 146.83, 98.0]
    for b in range(16):
        place(out, marimba_note(bass[b % 4], 1.4) * 0.35, b * bar)
    # Grodor och fåglar långt bort
    nature = np.zeros(n)
    t = 0.7
    while t < sec:
        place(nature, frog_croak(rng9.uniform(160, 230)) * rng9.uniform(0.08, 0.14), t)
        t += rng9.uniform(1.0, 3.0)
    t = 2.3
    while t < sec:
        place(nature, tree_frog() * rng9.uniform(0.03, 0.05), t)
        t += rng9.uniform(2.0, 5.0)
    t = 1.5
    while t < sec:
        place(nature, jungle_bird(int(rng9.integers(0, 3))) * rng9.uniform(0.1, 0.18), t)
        t += rng9.uniform(3.0, 7.0)
    nature = sosfilt(butter(2, 5000, "low", fs=SR, output="sos"), np.concatenate([nature, nature]))[n:]
    # Svagt regn i lövverket
    rain = periodic_noise(n, 1800, 7000, tilt=0.4, gen=rng9) * 0.02 * (0.6 + 0.4 * slow_lfo(n, 2))
    # Eko i djungeln
    out = out + 0.25 * np.roll(out, int(0.18 * SR))
    return out + nature + rain


def sfx_vine_snap():    # en lian går av: ett torrt knäpp och ett prassel av blad
    t = t_of(0.45)
    crack = sosfilt(butter(2, [1500, 6000], "band", fs=SR, output="sos"), rng9.normal(size=len(t))) * np.exp(-t * 90)
    f = 900 * np.exp(-t * 12) + 200
    tear = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 14) * 0.5
    rustle = sosfilt(butter(2, [2500, 7000], "band", fs=SR, output="sos"), rng9.normal(size=len(t)))
    rustle *= (1 - np.exp(-t * 30)) * np.exp(-t * 7) * 0.18
    return crack + tear + rustle


def sfx_rumble():       # en stenkula rullar: muller med ojämna dunsar och knastrande grus
    t = t_of(1.1)
    noise = sosfilt(butter(2, [35, 220], "band", fs=SR, output="sos"), rng9.normal(size=len(t)))
    bumps = (0.25 + 0.75 * np.abs(np.sin(2 * np.pi * 6 * t + 2 * np.sin(2 * np.pi * 1.3 * t)))) ** 3
    shape = (1 - np.exp(-t * 12)) * np.exp(-t * 2.8)
    # Grus som knastrar under kulan, så att det hörs även i en liten telefonhögtalare
    crunch = sosfilt(butter(2, [300, 1400], "band", fs=SR, output="sos"), rng9.normal(size=len(t))) * bumps * shape * 0.6
    return noise * bumps * shape * 1.6 + crunch + thud(60, 6, 0.0, 1.1) * 0.5


def sfx_bamboo():       # bambu knäcks: ett ihåligt klonk och ett torrt knak
    t = t_of(0.35)
    knock = (np.sin(2 * np.pi * 720 * t) + 0.5 * np.sin(2 * np.pi * 1930 * t)) * np.exp(-t * 28)
    crack = sosfilt(butter(2, [1200, 5000], "band", fs=SR, output="sos"), rng9.normal(size=len(t))) * np.exp(-t * 45) * 0.8
    return knock + crack



# ---- Isfiskesjön (1.10.0) ----------------------------------------------------------
# Egen slumpgenerator, så att de gamla ljuden inte ändras.
rng10 = np.random.default_rng(1910)


def ice_song(sec, f0, f1):
    """Is som "sjunger": de höga frekvenserna går fortare genom isen och kommer
    först, så ljudet blir ett fallande "pjuuu" (tonsvep med snabbt fall i början)."""
    tt = t_of(sec)
    f = f1 + (f0 - f1) * np.exp(-tt / (sec * 0.22))
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = np.sin(ph) + 0.3 * np.sin(2 * ph)
    return y * (1 - np.exp(-tt * 300)) * np.exp(-tt * 3.0 / sec)


def ice_boom(sec=2.0):
    """Ett djupt muller när isen sätter sig."""
    tt = t_of(sec)
    f = 45 + 40 * np.exp(-tt * 6)
    ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-tt * 2.2) * (1 - np.exp(-tt * 80))
    rumble = sosfilt(butter(2, [30, 160], "band", fs=SR, output="sos"), rng10.normal(size=len(tt))) * np.exp(-tt * 3) * 0.6
    return body + rumble


def ambience_icelake(sec=40):
    """Isfiskesjön: stilla vind över isen, isen som sjunger och mullrar ibland,
    och vind som sveper snö över isen."""
    n = int(sec * SR)
    out = np.zeros(n)
    for lo, hi, cyc, amp in [(80, 400, 2, 0.45), (400, 1100, 3, 0.15)]:
        out += periodic_noise(n, lo, hi, tilt=0.5, gen=rng10) * amp * (0.35 + 0.65 * slow_lfo(n, cyc, rng10.uniform(0, 6)) ** 2)
    drift = periodic_noise(n, 2500, 7000, tilt=0.3, gen=rng10) * 0.02 * slow_lfo(n, 5, 1.0) ** 3
    songs = np.zeros(n)
    t = 1.2
    while t < sec:
        k = int(rng10.integers(0, 3))
        if k < 2:
            sweep = ice_song(rng10.uniform(0.35, 0.9), rng10.uniform(2500, 4500), rng10.uniform(250, 500))
            place(songs, sweep * rng10.uniform(0.05, 0.1), t)
            if rng10.random() < 0.5:   # ett eko lite senare och svagare
                place(songs, sweep * 0.03, t + rng10.uniform(0.25, 0.5))
        else:
            place(songs, ice_boom() * rng10.uniform(0.18, 0.28), t)
        t += rng10.uniform(1.8, 4.5)
    songs = sosfilt(butter(2, 6000, "low", fs=SR, output="sos"), np.concatenate([songs, songs]))[n:]
    return out + drift + songs


def sfx_crack():        # isen spricker: ett skarpt knäpp och ett kort "pjuu"
    t = t_of(0.5)
    snap = sosfilt(butter(2, [1500, 7000], "band", fs=SR, output="sos"), rng10.normal(size=len(t))) * np.exp(-t * 120)
    out = snap * 1.2
    place(out, ice_song(0.35, 3800, 450) * 0.5, 0.01)
    return out + thud(110, 30, 0.2, 0.5) * 0.4


def sfx_icebreak():     # isen brister: flera knäppar, ett krasande och ett skvalp
    t = t_of(1.0)
    out = np.zeros(len(t))
    for k in range(6):
        at = k * 0.035 + rng10.uniform(0, 0.02)
        tt = t_of(0.08)
        click = sosfilt(butter(2, [1000, 6000], "band", fs=SR, output="sos"), rng10.normal(size=len(tt))) * np.exp(-tt * 70)
        place(out, click * (1 - k * 0.1), at)
    place(out, ice_song(0.5, 3000, 300) * 0.4, 0.02)
    out += thud(70, 9, 0.3, 1.0) * 0.6
    slosh = sosfilt(butter(2, [250, 1800], "band", fs=SR, output="sos"), rng10.normal(size=len(t)))
    slosh *= np.clip((t - 0.15) * 8, 0, 1) * np.exp(-np.maximum(t - 0.15, 0) * 5) * 0.35
    return out + slosh


# ---- Effekter ---------------------------------------------------------------

def sfx_launch():       # gummibandet smäller och kotten susar iväg
    t = t_of(0.35)
    twang = np.sin(2 * np.pi * (180 - 120 * t) * t) * np.exp(-t * 14)
    whoosh = sosfilt(butter(2, [700, 2600], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.sin(np.pi * t / 0.35) * 0.6
    return 0.8 * twang + whoosh


def thud(f, decay, noise_amt, sec=0.25):
    t = t_of(sec)
    body = np.sin(2 * np.pi * f * t * (1 - 0.3 * t)) * np.exp(-t * decay)
    click = sosfilt(butter(2, 3000, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 60) * noise_amt
    return body + click


def sfx_hit():
    return thud(140, 26, 0.6)


def sfx_break_wood():
    out = thud(220, 30, 0.8, 0.45)
    for k in range(4):
        place(out, thud(rng.uniform(300, 520), 45, 0.5, 0.12) * 0.5, 0.04 + k * 0.06)
    return out


def sfx_break_stone():
    t = t_of(0.55)
    rumble = sosfilt(butter(2, 900, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 7)
    return 0.9 * rumble + 0.6 * thud(90, 12, 0.3, 0.55)


def sfx_break_ice():
    t = t_of(0.6)
    out = np.zeros(len(t))
    for k in range(6):
        f = rng.uniform(2200, 4200)
        tt = t_of(0.35)
        place(out, np.sin(2 * np.pi * f * tt) * np.exp(-tt * 18) * 0.35, k * 0.045)
    crash = sosfilt(butter(2, 2500, "high", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 16) * 0.5
    return out + crash


def sfx_break_snow():   # mjuk puff
    t = t_of(0.35)
    return sosfilt(butter(2, [300, 1800], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.sin(np.pi * t / 0.35) ** 2 * 0.9


def sfx_troll():        # "oj!" – en grumlig ton som faller, och en puff
    t = t_of(0.5)
    f = 260 * np.exp(-t * 2.2)
    ph = 2 * np.pi * np.cumsum(f) / SR
    voice = (np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.25 * np.sin(3 * ph)) * env(len(t), 0.02, 0.25) * 0.5
    puff = sfx_break_snow()
    return voice + np.pad(puff, (0, len(t) - len(puff)))


def sfx_splash():       # plask: ett \"blopp\" och skum
    t = t_of(0.7)
    f = 900 * np.exp(-t * 9) + 180
    ph = 2 * np.pi * np.cumsum(f) / SR
    blop = np.sin(ph) * np.exp(-t * 14) * 0.6
    spray = sosfilt(butter(2, [800, 6000], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 6) * (1 - np.exp(-t * 80))
    return blop + spray


def sfx_release():      # något lossnar från taket: knak och skrammel
    t = t_of(0.5)
    crack = sosfilt(butter(2, [400, 3000], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 25)
    out = crack.copy()
    for k in range(4):
        tt = t_of(0.15)
        f = rng.uniform(2500, 4000)
        place(out, np.sin(2 * np.pi * f * tt) * np.exp(-tt * 30) * 0.3, 0.05 + k * 0.07)
    return out


def sfx_crystal():      # kotten studsar mot en kristall: klar klang
    t = t_of(0.9)
    out = np.zeros(len(t))
    for f, a in [(1975.5, 1.0), (2637.0, 0.6), (3951.0, 0.35), (5274.0, 0.2)]:
        out += a * np.sin(2 * np.pi * f * t) * np.exp(-t * (4 + f / 1500))
    return out * (1 - np.exp(-t * 400))


def sfx_boing():        # gelé: en fjädrande ton som stiger och darrar
    t = t_of(0.45)
    f = 180 * (1 + 2.2 * (1 - np.exp(-t * 9))) * (1 + 0.06 * np.sin(2 * np.pi * 18 * t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) + 0.3 * np.sin(2 * ph)) * np.exp(-t * 6) * (1 - np.exp(-t * 300))


def sfx_squish():       # marshmallow: ett mjukt, kladdigt tryck
    t = t_of(0.3)
    noise = sosfilt(butter(2, [150, 1200], "band", fs=SR, output="sos"), rng.normal(size=len(t)))
    wob = 1 + 0.5 * np.sin(2 * np.pi * 22 * t)
    return noise * wob * np.sin(np.pi * t / 0.3) ** 1.5 * 1.2


def sfx_break_candy():  # polkagris: krispigt knäck och lite glas
    t = t_of(0.45)
    out = sosfilt(butter(2, 2500, "high", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 30) * 0.7
    for k in range(5):
        tt = t_of(0.2)
        place(out, np.sin(2 * np.pi * rng.uniform(1800, 3200) * tt) * np.exp(-tt * 25) * 0.3, 0.02 + k * 0.05)
    return out


def sfx_ability():
    return chirp(600, 1800, 0.18, (1, 0.3)) * 0.7


def sfx_burst():
    t = t_of(0.8)
    boom = sosfilt(butter(2, 500, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 5) * 1.2
    return boom + 0.7 * thud(60, 6, 0.0, 0.8)


def sfx_sizzle():       # något ramlar i lavan: ett lågt blopp och ett fräs
    t = t_of(0.9)
    f = 260 * np.exp(-t * 5) + 90
    ph = 2 * np.pi * np.cumsum(f) / SR
    blop = np.sin(ph) * np.exp(-t * 10) * 0.6
    hiss = sosfilt(butter(2, [2500, 6500], "band", fs=SR, output="sos"), rng.normal(size=len(t)))
    hiss *= (1 - np.exp(-t * 40)) * np.exp(-t * 4) * 0.35
    return blop + hiss


def sfx_ember():        # en glödande sten spricker: duns och sprakande gnistor
    t = t_of(0.9)
    boom = sosfilt(butter(2, 300, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 7) * 0.9
    crackle = np.zeros(len(t))
    for _ in range(40):
        at = rng.uniform(0.02, 0.7)
        tt = t_of(0.012)
        click = sosfilt(butter(2, [1500, 5000], "band", fs=SR, output="sos"), rng.normal(size=len(tt))) * np.exp(-tt * 300)
        place(crackle, click * rng.uniform(0.3, 1.0) * (1 - at), at)
    return boom + 0.6 * thud(70, 8, 0.0, 0.9) + crackle * 0.8


def marimba(freqs, step, sec):
    out = np.zeros(int(sec * SR))
    for i, f in enumerate(freqs):
        tt = t_of(0.6)
        note = (np.sin(2 * np.pi * f * tt) + 0.25 * np.sin(2 * np.pi * 4 * f * tt) * np.exp(-tt * 20)) * np.exp(-tt * 6)
        place(out, note * 0.6, i * step)
    return out


def sfx_win():
    return marimba([523.25, 659.25, 783.99, 1046.5], 0.12, 1.1)


def sfx_lose():
    return marimba([392.0, 329.63, 261.63], 0.2, 1.1)


# ---- Skriv filer ------------------------------------------------------------

def normalize(y, peak):
    return y / np.max(np.abs(y)) * peak


def write_wav(path, y):
    y = np.clip(y, -1, 1)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((y * 32767).astype("<i2").tobytes())


def main(only=None):
    """Skapar alla ljud, eller bara de som räknas upp:
    python3 tools/make_sounds.py candy boing squish   (bakgrundsljud anges med världens namn)"""
    os.makedirs(OUT, exist_ok=True)
    ambiences = [("forest", ambience_forest), ("winter", ambience_winter), ("sea", ambience_sea),
                 ("cave", ambience_cave), ("candy", ambience_candy), ("fair", ambience_fair), ("sky", ambience_sky),
                 ("volcano", ambience_volcano), ("jungle", ambience_jungle),
                 ("icelake", ambience_icelake)]
    for name, fn in ambiences:
        if only and name not in only:
            continue
        tmp = os.path.join(OUT, name + ".tmp.wav")
        write_wav(tmp, normalize(fn(), 0.5))
        subprocess.run(["oggenc", "-Q", "-q", "2", "-o", os.path.join(OUT, "ambience-" + name + ".ogg"), tmp], check=True)
        os.remove(tmp)
    effects = {"launch": sfx_launch, "hit": sfx_hit, "break-wood": sfx_break_wood, "break-stone": sfx_break_stone,
               "break-ice": sfx_break_ice, "break-snow": sfx_break_snow, "troll": sfx_troll, "ability": sfx_ability,
               "burst": sfx_burst, "win": sfx_win, "lose": sfx_lose, "splash": sfx_splash,
               "release": sfx_release, "crystal": sfx_crystal,
               "boing": sfx_boing, "squish": sfx_squish, "break-candy": sfx_break_candy,
               "sizzle": sfx_sizzle, "ember": sfx_ember,
               "vine-snap": sfx_vine_snap, "rumble": sfx_rumble, "bamboo": sfx_bamboo,
               "crack": sfx_crack, "icebreak": sfx_icebreak}
    for name, fn in effects.items():
        if only and name not in only:
            continue
        write_wav(os.path.join(OUT, name + ".wav"), normalize(fn(), 0.8))
    for f in sorted(os.listdir(OUT)):
        print(f, os.path.getsize(os.path.join(OUT, f)) // 1024, "kB")


if __name__ == "__main__":
    import sys
    main(sys.argv[1:] or None)
