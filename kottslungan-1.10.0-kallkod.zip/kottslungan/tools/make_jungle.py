#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Grafik till Djungeltemplet (1.9.0): troll, tempelväktaren, guldidolen,
# stenkulan, templet långt bort och lövtaket med lianer.
# Kör: python3 tools/make_jungle.py   (skriver till assets/)
import os, random

OUT = os.path.join(os.path.dirname(__file__), "..", "assets")
rng = random.Random(91)


def write(name, body, view="0 0 100 100", extra=""):
    with open(os.path.join(OUT, name), "w") as f:
        f.write('<svg xmlns="http://www.w3.org/2000/svg" viewBox="%s"%s>\n%s</svg>\n' % (view, extra, body))


# ---- Trollens ansikte (samma som i de andra världarna) ----------------------
def face(skin, line, nose, brow="#3A3020"):
    return f'''  <!-- buskiga ögonbryn -->
  <path d="M26 40 q10 -8 20 0" stroke="{brow}" stroke-width="6" fill="none" stroke-linecap="round"/>
  <path d="M54 40 q10 -8 20 0" stroke="{brow}" stroke-width="6" fill="none" stroke-linecap="round"/>
  <!-- ögon -->
  <circle cx="37" cy="47" r="6" fill="#FFFFFF"/><circle cx="63" cy="47" r="6" fill="#FFFFFF"/>
  <circle cx="35" cy="48" r="3" fill="#1A1A1A"/><circle cx="61" cy="48" r="3" fill="#1A1A1A"/>
  <!-- lång näsa -->
  <path d="M48 48 q-6 22 -2 30 q8 6 14 0 q2 -10 -6 -30z" fill="{nose}" stroke="{line}" stroke-width="2"/>
  <!-- grinig mun -->
  <path d="M34 82 q6 -4 12 0 M58 82 q6 -4 10 0" stroke="{line}" stroke-width="3" fill="none" stroke-linecap="round"/>
'''


def body(skin, line):
    return f'''  <!-- öron -->
  <path d="M10 46 q-10 -14 -2 -24 q10 4 14 16z" fill="{skin}" stroke="{line}" stroke-width="2"/>
  <path d="M90 46 q10 -14 2 -24 q-10 4 -14 16z" fill="{skin}" stroke="{line}" stroke-width="2"/>
  <!-- kropp -->
  <circle cx="50" cy="54" r="44" fill="{skin}" stroke="{line}" stroke-width="3"/>
  <ellipse cx="38" cy="38" rx="14" ry="9" fill="#FFFFFF" opacity="0.18"/>
'''


# Litet troll med ett stort bananblad som hatt
SKIN, LINE, NOSE = "#7E9A5A", "#465A2E", "#98B46E"
small = body(SKIN, LINE) + f'''  <!-- bananblad som hatt -->
  <path d="M8 30 q20 -34 50 -28 q30 6 38 26 q-40 -6 -88 2z" fill="#4CB040" stroke="#2A6A22" stroke-width="2"/>
  <path d="M12 29 q36 -20 82 -1" stroke="#2A6A22" stroke-width="2" fill="none"/>
  <g stroke="#2A6A22" stroke-width="1.5" fill="none">
    <path d="M24 24 l-4 -10"/><path d="M36 20 l-2 -12"/><path d="M50 18 l1 -13"/><path d="M64 19 l4 -12"/><path d="M78 23 l6 -9"/>
  </g>
  <path d="M8 30 q-6 -2 -8 -8" stroke="#2A6A22" stroke-width="3" fill="none" stroke-linecap="round"/>
''' + face(SKIN, LINE, NOSE)
write("troll-small-jungle.svg", small)

# Mellanstort troll med tropikhjälm
SKIN, LINE, NOSE = "#7F8F62", "#4A5634", "#98A672"
medium = body(SKIN, LINE) + f'''  <!-- tropikhjälm -->
  <path d="M4 34 q4 -6 12 -6 h68 q8 0 12 6 q-2 6 -12 6 h-68 q-10 0 -12 -6z" fill="#D8C08A" stroke="#7A6232" stroke-width="2"/>
  <path d="M18 30 q2 -28 32 -28 q30 0 32 28z" fill="#E8D4A0" stroke="#7A6232" stroke-width="2"/>
  <path d="M18 26 h64 v5 h-64z" fill="#7A5A2A"/>
  <path d="M50 4 q-14 8 -16 22 M50 4 q14 8 16 22" stroke="#C8B07A" stroke-width="2" fill="none"/>
  <circle cx="50" cy="4" r="3" fill="#C8B07A" stroke="#7A6232" stroke-width="1.5"/>
''' + face(SKIN, LINE, NOSE)
write("troll-medium-jungle.svg", medium)

# Tempelväktaren: mask av huggen sten, mantel av mossa och ett pannband med en grön sten
SKIN, LINE = "#6E7E58", "#3E4A2A"
guardian = f'''  <!-- mantel av mossa -->
  <path d="M6 70 q-6 -30 10 -40 q-4 34 4 60z" fill="#3E7A2E"/>
  <path d="M94 70 q6 -30 -10 -40 q4 34 -4 60z" fill="#3E7A2E"/>
  <!-- öron -->
  <path d="M10 46 q-10 -14 -2 -24 q10 4 14 16z" fill="{SKIN}" stroke="{LINE}" stroke-width="2"/>
  <path d="M90 46 q10 -14 2 -24 q-10 4 -14 16z" fill="{SKIN}" stroke="{LINE}" stroke-width="2"/>
  <circle cx="50" cy="54" r="44" fill="{SKIN}" stroke="{LINE}" stroke-width="3"/>
  <!-- mossa som hänger över axlarna -->
  <path d="M10 70 q10 8 20 4 q10 10 20 6 q10 10 20 2 q10 8 20 -6 q2 14 -10 22 q-30 14 -60 0 q-12 -10 -10 -28z" fill="#4C8A36" stroke="#2E5A20" stroke-width="2"/>
  <g fill="#6AB04A"><circle cx="24" cy="80" r="3"/><circle cx="44" cy="86" r="3"/><circle cx="62" cy="84" r="3"/><circle cx="78" cy="78" r="3"/></g>
  <!-- mask av huggen sten -->
  <path d="M16 22 h68 l-4 44 q-30 12 -60 0z" fill="#A7A08E" stroke="#5E5848" stroke-width="3"/>
  <path d="M16 22 l34 -14 l34 14z" fill="#8E8776" stroke="#5E5848" stroke-width="3" stroke-linejoin="round"/>
  <path d="M26 36 h18 v10 h-18z M56 36 h18 v10 h-18z" fill="#2A2620"/>
  <circle cx="35" cy="41" r="3" fill="#FFE68A"/><circle cx="65" cy="41" r="3" fill="#FFE68A"/>
  <path d="M44 50 l6 10 l6 -10" fill="none" stroke="#5E5848" stroke-width="3" stroke-linejoin="round"/>
  <path d="M30 58 h40" stroke="#5E5848" stroke-width="3"/>
  <path d="M34 58 v5 M42 58 v5 M50 58 v5 M58 58 v5 M66 58 v5" stroke="#5E5848" stroke-width="2"/>
  <path d="M20 30 h60" stroke="#C9C2AE" stroke-width="2" opacity="0.6"/>
  <!-- pannsten -->
  <path d="M50 12 l6 6 l-6 6 l-6 -6z" fill="#3CC88A" stroke="#1E6A44" stroke-width="2"/>
  <!-- mossa på masken -->
  <path d="M16 22 q6 -4 10 2 q4 -6 10 -2 q-6 4 -20 0z" fill="#4C8A36"/>
  <path d="M84 22 q-6 -4 -10 2 q-4 -6 -10 -2 q6 4 20 0z" fill="#4C8A36"/>
  <!-- grinig mun under masken -->
  <path d="M38 76 q12 -6 24 0" stroke="{LINE}" stroke-width="3" fill="none" stroke-linecap="round"/>
'''
write("troll-guardian.svg", guardian)

# Guldidolen: en liten statyett av guld (bredd 0,55, höjd 0,75)
idol = '''  <path d="M14 140 h72 v-16 h-72z" fill="#B8862A" stroke="#6A4A10" stroke-width="3"/>
  <path d="M22 124 q-4 -40 8 -58 h40 q12 18 8 58z" fill="#F2C230" stroke="#8A6214" stroke-width="3"/>
  <circle cx="50" cy="44" r="26" fill="#F7D04A" stroke="#8A6214" stroke-width="3"/>
  <path d="M26 30 l24 -24 l24 24z" fill="#F2C230" stroke="#8A6214" stroke-width="3" stroke-linejoin="round"/>
  <circle cx="40" cy="44" r="5" fill="#3CC88A" stroke="#1E6A44" stroke-width="2"/>
  <circle cx="60" cy="44" r="5" fill="#3CC88A" stroke="#1E6A44" stroke-width="2"/>
  <path d="M40 58 q10 6 20 0" stroke="#8A6214" stroke-width="3" fill="none"/>
  <path d="M34 82 h32 M34 96 h32 M34 110 h32" stroke="#C8962A" stroke-width="3"/>
  <ellipse cx="40" cy="34" rx="8" ry="4" fill="#FFFFFF" opacity="0.5"/>
  <path d="M28 70 q-2 20 0 40" stroke="#FFF2B0" stroke-width="3" opacity="0.6" fill="none"/>
'''
write("idol.svg", idol, "0 0 100 140", ' preserveAspectRatio="none"')

# Stenkulan: grå sten med huggna ränder (syns när den rullar)
ball = '''  <circle cx="50" cy="50" r="48" fill="#8E8A7C" stroke="#4E4A40" stroke-width="3"/>
  <circle cx="50" cy="50" r="34" fill="none" stroke="#6E6A5C" stroke-width="4"/>
  <path d="M50 2 v96 M2 50 h96" stroke="#6E6A5C" stroke-width="4"/>
  <circle cx="50" cy="50" r="10" fill="#7A7668" stroke="#4E4A40" stroke-width="3"/>
  <path d="M18 24 q8 -10 20 -14" stroke="#B8B4A4" stroke-width="5" fill="none" stroke-linecap="round" opacity="0.7"/>
  <path d="M70 84 q12 -6 18 -18" stroke="#4CA03A" stroke-width="6" fill="none" stroke-linecap="round" opacity="0.8"/>
  <path d="M12 64 q2 10 8 16" stroke="#4CA03A" stroke-width="5" fill="none" stroke-linecap="round" opacity="0.7"/>
'''
write("stoneball.svg", ball)

# ---- Templet långt bort (1600 × 400) -----------------------------------------
def tree_line(y0, color, n, hmin, hmax, seed):
    r = random.Random(seed)
    out = []
    x = -40
    while x < 1640:
        w = r.uniform(70, 150)
        h = r.uniform(hmin, hmax)
        out.append(f'<ellipse cx="{x:.0f}" cy="{y0 - h * 0.5:.0f}" rx="{w * 0.6:.0f}" ry="{h * 0.55:.0f}"/>')
        x += w * r.uniform(0.55, 0.8)
    return f'  <g fill="{color}">' + "".join(out) + f'<rect x="0" y="{y0 - 10}" width="1600" height="{410 - y0}"/></g>\n'


far = tree_line(330, "#3E6A4A", 30, 80, 150, 1)
# trappstegspyramiden
steps = []
base, top = 400, 120
cx, w0 = 1020, 560
n = 6
for i in range(n):
    w = w0 - i * 80
    y = base - (i + 1) * 42
    steps.append(f'<rect x="{cx - w / 2:.0f}" y="{y}" width="{w}" height="42" fill="#9DAAA6" stroke="#74827E" stroke-width="3"/>')
    steps.append(f'<rect x="{cx - w / 2:.0f}" y="{y}" width="{w}" height="7" fill="#7EA48A"/>')
# templet på toppen med en mörk dörr
ty = base - n * 42
steps.append(f'<rect x="{cx - 70}" y="{ty - 70}" width="140" height="70" fill="#A4B0AC" stroke="#74827E" stroke-width="3"/>')
steps.append(f'<path d="M{cx - 84} {ty - 70} h168 l-20 -22 h-128z" fill="#8E9A96" stroke="#74827E" stroke-width="3"/>')
steps.append(f'<path d="M{cx - 18} {ty} v-40 q18 -16 36 0 v40z" fill="#3A4642"/>')
# trappan i mitten
steps.append(f'<path d="M{cx - 40} 400 L{cx - 22} {ty} h44 L{cx + 40} 400z" fill="#8A9692" opacity="0.8"/>')
for k in range(1, 22):
    yy = ty + k * (400 - ty) / 22
    half = 22 + (40 - 22) * k / 22
    steps.append(f'<path d="M{cx - half:.0f} {yy:.0f} h{2 * half:.0f}" stroke="#74827E" stroke-width="2"/>')
# gröna rankor över templet
vines = []
for k in range(14):
    x = cx - w0 / 2 + 20 + rng.uniform(0, w0 - 40)
    y = base - rng.randint(1, n) * 42
    L = rng.uniform(30, 90)
    vines.append(f'<path d="M{x:.0f} {y} q{rng.uniform(-10, 10):.0f} {L / 2:.0f} {rng.uniform(-6, 6):.0f} {L:.0f}" stroke="#5E8E66" stroke-width="5" fill="none" stroke-linecap="round"/>')
pyramid = "  <g>" + "".join(steps) + "".join(vines) + "</g>\n"
# palmer och träd framför
front = tree_line(400, "#2E5A36", 30, 30, 70, 2)
palms = []
for x in (180, 420, 1420, 1540):
    palms.append(f'<path d="M{x} 400 q8 -90 -4 -170 h10 q14 80 4 170z" fill="#4A3A26"/>')
    for a, b in ((-110, 40), (110, 30), (-90, -10), (90, -16), (-30, -60), (40, -56)):
        palms.append(f'<path d="M{x + 2} 232 q{a * 0.5} {b * 0.5 - 40} {a} {b} q{-a * 0.55} {-b * 0.5 - 6} {-a} {-b}z" fill="#2E7A3A"/>')
write("jungle-far.svg", far + pyramid + front + "  <g>" + "".join(palms) + "</g>\n", "0 0 1600 400",
      ' preserveAspectRatio="none"')

# ---- Lövtaket med lianer (1600 × 300), ritas överst ------------------------------
leaves = []
r = random.Random(7)
x = -30
while x < 1640:
    w = r.uniform(60, 120)
    leaves.append(f'<ellipse cx="{x:.0f}" cy="{r.uniform(-10, 40):.0f}" rx="{w * 0.7:.0f}" ry="{r.uniform(40, 70):.0f}" fill="{r.choice(["#2E6A30", "#3A7A36", "#285E2A"])}"/>')
    x += w * 0.6
hang = []
for k in range(16):
    x = r.uniform(20, 1580)
    L = r.uniform(80, 260)
    sway = r.uniform(-25, 25)
    hang.append(f'<path d="M{x:.0f} 20 q{sway:.0f} {L / 2:.0f} {sway / 3:.0f} {L:.0f}" stroke="#3E7A2E" stroke-width="5" fill="none" stroke-linecap="round"/>')
    for j in range(3):
        t = 0.3 + j * 0.25
        ly = 20 + L * t
        lx = x + sway * 0.6 * t * 2 * (1 - t)
        hang.append(f'<ellipse cx="{lx + (8 if j % 2 else -8):.0f}" cy="{ly:.0f}" rx="9" ry="4" fill="#4CA040" transform="rotate({35 if j % 2 else -35} {lx:.0f} {ly:.0f})"/>')
write("jungle-canopy.svg", "  <g>" + "".join(hang) + "".join(leaves) + "</g>\n", "0 0 1600 300",
      ' preserveAspectRatio="none"')

# Fjäril (vingarna ritas för sig så att de kan fladdra i QML)
write("butterfly.svg", '''  <path d="M50 50 q-30 -40 -44 -16 q-6 22 44 22z" fill="#2EA8E0" stroke="#1A3A5A" stroke-width="3"/>
  <path d="M50 54 q-26 26 -36 10 q-2 -14 36 -14z" fill="#E8C82A" stroke="#1A3A5A" stroke-width="3"/>
  <path d="M50 50 q30 -40 44 -16 q6 22 -44 22z" fill="#2EA8E0" stroke="#1A3A5A" stroke-width="3"/>
  <path d="M50 54 q26 26 36 10 q2 -14 -36 -14z" fill="#E8C82A" stroke="#1A3A5A" stroke-width="3"/>
  <ellipse cx="50" cy="52" rx="4" ry="16" fill="#1A1A1A"/>
''')
print("ok")
