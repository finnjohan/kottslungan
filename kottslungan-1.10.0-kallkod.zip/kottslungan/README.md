# Kottslungan – fysikspel för Ubuntu Touch

Hjälp ekorren att slunga kottar på trollen som har tagit över skogen. Kottslungan är
ett eget spel i den klassiska slangbellegenren. Figurer, banor, grafik och fysikmotor
är gjorda för det här spelet.

## Spelet
- Dra kotten bakåt och släpp. Prickarna visar banan.
- **Kottarna:**
  - **Grankotte:** vanlig kotte.
  - **Tallkotte:** tryck i luften så delar den sig i tre.
  - **Ekollon:** tryck i luften för extra fart. Det slår extra hårt.
  - **Kastanj:** tryck i luften så spricker den och knuffar undan allt runt omkring.
- **Trollen** finns i fyra storlekar: små, mellan, stora (med näverhatt) och gamla (med skägg).
  I vinterskogen finns också **frosttroll** (hala, glider lätt av bjälkar) och **snötroll**
  (stora, med tjock päls som tar emot en del av stöten). I Sjörövarviken har trollen blivit
  sjörövare, och **kaptenen** med trekantig hatt tål mycket. I Trollgrottan är de discotroll
  med solglasögon, och **diskjockeyn** med hörlurar är bossen. På månen har trollen antenner och
  **bubbelhjälm**, och **befälhavaren** i rymddräkt är bossen. I Godisfabriken är trollen bagare,
  och **sockerbagaren** med kockmössa och mustasch är bossen. På tivolit är trollen clowner och
  cirkusdirektörer, och **den starke mannen** är bossen. I Luftslottet har trollen propellermössor
  och flygarmössor, och **stormtrollet** med blixthår är bossen. På Vulkanön har trollen
  skyddshjälmar och värmehuvor, och **lavakungen** med krona av obsidian är bossen. I Djungeltemplet
  har trollen bananblad och tropikhjälmar, och **tempelväktaren** med mask av huggen sten är bossen. På
  Isfiskesjön har trollen öronlappsmössor och pälshuvor, och **isfiskaren** med frost i skägget är bossen.
- **Material:** trä, sten, is, snö, plåt, månsten, gelé, marshmallow, choklad, polkagris, obsidian, glödande sten, bambu, tempelsten och guldidoler, plus klippor, skär, skeppsskrov, basaltpelare, tempelsten och ramper som inte går att rubba.
- **Krutfat** smäller när de går sönder och knuffar och skadar allt runt omkring.
- **Vatten:** i Sjörövarviken sjunker allt som ramlar i havet, även trollen.
- **Tak och hängande saker:** i Trollgrottan studsar kottarna mot taket. Droppsten, ljuskronor och
  discokulor hänger i taket och faller när man träffar dem. Kristallerna är studsiga.
- **Månen:** låg gravitation, så kottarna flyger långsamt i höga bågar och tornen rasar i slow motion.
  Bubbelhjälmen tar den första hårda smällen. Månsten kan sväva fritt och faller när man träffar den.
- **Godis:** gelé studsar, och marshmallows är mjuka: ett troll som landar på en marshmallow klarar sig,
  och marshmallows går nästan inte sönder, så de måste knuffas bort.
- **Tivolit:** studsmattor som kottarna studsar på, vagnar och hissar som åker fram och tillbaka,
  och ett pariserhjul med troll i gondolerna. Det gäller att skjuta i rätt ögonblick.
- **Luftslottet:** trollen bor på moln, och det som ramlar av faller ned och försvinner. Vindbyar
  (med pilar) knuffar kotten åt sidan, uppåt eller nedåt, och ballonger håller uppe plattformar
  som faller när ballongen spricker.
- **Vulkanön:** allt som ramlar i lavan brinner upp. Glödande stenar spricker i ett regn av gnistor
  som skadar allt runt omkring och kan tända nästa sten. Den heta luften över lavan lyfter kotten.
- **Djungeltemplet:** stenar och bambuplattformar hänger i lianer. En kotte som flyger genom en lian
  kapar den, och det som hängde faller. Stenkulor rullar nedför ramper och trappor när man knuffar dem,
  och en stenkula som pendlar i en lian flyger iväg åt det håll den svänger när lianen kapas.
- **Isfiskesjön:** trollen står på isflak över sjön. En hård smäll spräcker isen och nästa får den att
  brista, och det som stod på flaket sjunker. Tunn is brister direkt. Isen är hal, så troll som knuffas
  glider iväg, gärna ned i en vak. Skruvis är vallar av is som inte går att rubba.
- **Poäng:** troll ger 5 000–10 000 poäng och block 200–1 000. Varje kotte som blir över ger 3 000 i bonus.
- **110 banor i elva världar**, med 1–3 stjärnor vardera. Nästa bana låses upp när den förra är klarad.
  - **Sommarskogen** (bana 1–10)
  - **Vinterskogen** (bana 11–20): snöfall, halare mark och norrsken på kvällen.
  - **Sjörövarviken** (bana 21–30): strand och hav med vågor och måsar, skär och skepp, månsken på kvällen.
  - **Trollgrottan** (bana 31–40): trollens hemliga disco inne i berget, med discoljus och dansgolv.
  - **Trollen på månen** (bana 41–50): en månbas under stjärnhimlen, med jorden på himlen och stjärnfall.
  - **Godisfabriken** (bana 51–60): en fabrik i pastell med kugghjul, rör, löpband med godis och neonskyltar på kvällen.
  - **Tivolit** (bana 61–70): cirkustält, berg-och-dalbana, ballonger som stiger och ljusslingor som blinkar på kvällen.
  - **Luftslottet** (bana 71–80): moln som glider förbi och ett slott på molnen, med stjärnor och måne på kvällen.
  - **Vulkanön** (bana 81–90): en vulkan som ryker, lavaströmmar, en bubblande lavasjö och gnistor som stiger.
  - **Djungeltemplet** (bana 91–100): ett igenvuxet tempel, lövtak med lianer, solstrålar och fjärilar, och eldflugor och facklor på kvällen.
  - **Isfiskesjön** (bana 101–110): en frusen sjö med fisketält, röda stugor som ryker på andra stranden, lätt snöfall och norrsken på kvällen.
- **Ljud:** bakgrundsljud för varje värld (fågelsång, vinande vind, vågskvalp och måsar, discomusik genom berget, lugn rymdmusik, speldosemusik och maskiner i godisfabriken, en vals på positiv på tivolit, harpa och vindsus i luftslottet, trummor på vulkanön, marimba, grodor och fåglar i djungeln, eller vind och is som sjunger på sjön) och ljudeffekter.
  Båda kan stängas av under Inställningar. Alla ljud är skapade för spelet med `tools/make_sounds.py`.
- Ljust tema ger dagsljus och mörkt tema kvällshimmel. Svenska och engelska.

## Teknik
- Ren QML och JavaScript. Enda behörigheten är `audio` (*common*, godkänns automatiskt).
- `qml/Physics.js` är en egen fysikmotor för lådor och cirklar. Den bygger på idéerna i
  [Box2D-Lite](https://github.com/erincatto/box2d-lite) av Erin Catto (zlib): klippta kontaktpunkter,
  ackumulerade impulser och warm starting, vilket gör att torn står stabilt.
- `qml/Game.js` innehåller reglerna: skada utifrån stötens impuls, förmågor, vinst och förlust, poäng och stjärnor.
- `qml/Levels.js` innehåller banorna som data, byggda med små hjälpfunktioner (`floor`, `col`, `beam`, `block`, `troll`, `rock`).
- Grafiken ritas med QML-objekt och SVG-bilder i `assets/`.
- `qml/Sounds.qml` spelar bakgrundsljud (`Audio`, .ogg som loopar) och effekter (`SoundEffect`, .wav).
  Ljuden skapas med `python3 tools/make_sounds.py` (numpy, scipy, oggenc). Ange namn för att bara skapa
  vissa ljud, t.ex. `python3 tools/make_sounds.py candy boing`. Månens ljud och bilder skapas med `tools/make_moon.py`, djungelns bilder med `tools/make_jungle.py` och isfiskesjöns med `tools/make_icelake.py`.

## Testa
```bash
node tests/levels.test.js     # varje bana står stilla och går att klara (en enkel datorspelare provar sikten)
node tests/i18n.test.js       # alla texter finns på svenska
GRID_UNIT_PX=16 UITK_ICON_THEME=suru qmlscene -I . qml/Main.qml --demo --lang=sv
```
Flaggor: `--demo` (egen databas med några klarade banor), `--lang`, `--theme`,
`--page=levels|settings|game`, `--level=<n>`, `--width=<gu>`, `--height=<gu>` och `--mute`.

## Bygga och installera
```bash
clickable build            # eller: click build <katalog>
adb push kottslunga_1.10.0_all.click /home/phablet/Downloads/
adb shell gdbus call --system --dest com.lomiri.click --object-path /com/lomiri/click \
    --method com.lomiri.click.Install /home/phablet/Downloads/kottslunga_1.10.0_all.click
```

## Licens
Copyright © 2026 Johan Finn. GNU General Public License v3.0 eller senare, se [LICENSE](LICENSE).
