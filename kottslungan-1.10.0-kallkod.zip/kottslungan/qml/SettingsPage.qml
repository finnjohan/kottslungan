// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import Lomiri.Components.Popups 1.3
import "I18n.js" as I18n

Page {
    id: page
    readonly property var themeValues: ["auto", "light", "dark"]
    readonly property var langValues: ["auto"].concat(I18n.languages.map(function (l) { return l.code }))

    header: PageHeader { id: header; title: root.tr("Settings") }

    Flickable {
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: content.height + units.gu(4)
        clip: true

        Column {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(1.5)

            Label { text: root.tr("Theme"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Automatic"), root.tr("Light (day)"), root.tr("Dark (evening)")]
                selectedIndex: Math.max(0, page.themeValues.indexOf(root.themeSetting))
                onDelegateClicked: root.setTheme(page.themeValues[index])
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Language"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Automatic (system language)")].concat(I18n.languages.map(function (l) { return l.name }))
                selectedIndex: Math.max(0, page.langValues.indexOf(root.langSetting))
                onDelegateClicked: root.setLanguage(page.langValues[index])
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Sound"); font.weight: Font.Medium }
            Item {
                width: parent.width; height: units.gu(5)
                Label { anchors { left: parent.left; right: ambSwitch.left; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                        text: root.tr("Background sounds"); wrapMode: Text.WordWrap }
                Switch { id: ambSwitch; anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                         checked: root.ambienceOn; onClicked: root.setAmbience(checked) }
            }
            Item {
                width: parent.width; height: units.gu(5)
                Label { anchors { left: parent.left; right: fxSwitch.left; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                        text: root.tr("Sound effects"); wrapMode: Text.WordWrap }
                Switch { id: fxSwitch; anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                         checked: root.effectsOn; onClicked: root.setEffects(checked) }
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Progress"); font.weight: Font.Medium }
            Button {
                text: root.tr("Reset progress")
                onClicked: PopupUtils.open(resetDialog, page)
            }

            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("About"); font.weight: Font.Medium }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Help the squirrel fling cones at the trolls who have taken over the forest. An original game in the classic slingshot genre – all characters and levels are made for this game.")
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("The physics engine is written for this game and follows the ideas in Box2D-Lite by Erin Catto.")
            }
            Label {
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("All sounds are made for this game.")
            }
            Label {
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Version %1").arg(root.version) + " · © 2026 Johan Finn · GPLv3"
            }
        }
    }

    Component {
        id: resetDialog
        Dialog {
            id: dlg
            title: root.tr("Reset progress?")
            text: root.tr("All stars and best scores will be deleted.")
            Button {
                text: root.tr("Reset")
                color: theme.palette.normal.negative
                onClicked: { root.resetProgress(); PopupUtils.close(dlg) }
            }
            Button { text: root.tr("Cancel"); onClicked: PopupUtils.close(dlg) }
        }
    }
}
