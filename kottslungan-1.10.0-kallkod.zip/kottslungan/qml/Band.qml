// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// Slangbellans gummiband: en tjock linje mellan två punkter (i meter).
Rectangle {
    property point from
    property point to
    property real ppm: 30
    property real originY: 0
    readonly property real dx: (to.x - from.x) * ppm
    readonly property real dy: -(to.y - from.y) * ppm
    x: from.x * ppm
    y: originY - from.y * ppm - height / 2
    width: Math.sqrt(dx * dx + dy * dy)
    height: Math.max(3, ppm * 0.12)
    radius: height / 2
    color: "#5A2E14"
    transformOrigin: Item.Left
    rotation: Math.atan2(dy, dx) * 180 / Math.PI
}
