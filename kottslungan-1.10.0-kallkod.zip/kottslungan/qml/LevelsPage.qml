// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Levels.js" as Levels

Page {
    id: page
    header: PageHeader {
        id: header
        title: root.tr("Levels")
        trailingActionBar.actions: [
            Action { iconName: "settings"; text: root.tr("Settings"); onTriggered: stack.push(Qt.resolvedUrl("SettingsPage.qml")) }
        ]
    }

    // Visa den värld där spelaren är just nu
    Timer { interval: 60; running: true; onTriggered: page.scrollToCurrent() }
    function scrollToCurrent() {
        var w = Levels.worldOf(root.nextLevel())
        if (w.first === 1) return
        for (var i = 0; i < worldColumn.children.length; i++) {
            var c = worldColumn.children[i]
            if (c.worldId === w.id)
                flick.contentY = Math.max(0, Math.min(c.y, flick.contentHeight - flick.height))
        }
    }

    Flickable {
        id: flick
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: worldColumn.height + units.gu(4)
        clip: true

        Column {
            id: worldColumn
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(2)

            Repeater {
                model: Levels.worlds
                WorldSection {
                    width: worldColumn.width
                    world: modelData
                }
            }
        }
    }
}
