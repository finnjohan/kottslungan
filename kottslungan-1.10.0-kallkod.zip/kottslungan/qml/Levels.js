.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Banorna som data. y är underkanten (marken ligger på y = 0).
// Hjälpfunktionerna bygger stolpar, bjälkar, block och troll.

var T = 0.25        // tjocklek på plankor

function col(x, y, h, mat) { return { mat: mat || "wood", x: x, y: y, w: mat === "stone" ? 0.35 : T, h: h } }
function beam(x, y, w, mat) { return { mat: mat || "wood", x: x, y: y, w: w, h: mat === "stone" ? 0.35 : T } }
function block(x, y, w, h, mat) { return { mat: mat || "wood", x: x, y: y, w: w, h: h } }
function troll(x, y, size) { return { troll: size || "small", x: x, y: y } }
function rock(x, y, w, h) { return { rock: true, x: x, y: y, w: w, h: h } }

// En våning: två stolpar och en bjälke. Returnerar delarna och höjden ovanpå.
function floor(out, x, y, width, height, mat, beamMat) {
    var half = width / 2 - T / 2
    var c = col(x - half, y, height, mat), d = col(x + half, y, height, mat)
    out.push(c, d)
    var b = beam(x, y + height, width + 0.2, beamMat || mat)
    out.push(b)
    return y + height + b.h
}

function level(name, cones, stars, build, world) {
    var items = []
    build(items)
    return { name: name, cones: cones, stars: stars, items: items, world: world || "forest", decor: items.decor || [] }
}
function winter(name, cones, stars, build) { return level(name, cones, stars, build, "winter") }
function sea(name, cones, stars, build) { return level(name, cones, stars, build, "sea") }

// Havet: skär och skeppsskrov står fast i vattnet (y = 0 är vattenytan).
// top är höjden ovanför vattnet.
function isle(x, w, top) { return { rock: true, style: "isle", x: x, y: -3, w: w, h: top + 3 } }
function ship(x, w, top) { return { rock: true, style: "ship", x: x, y: -2, w: w, h: top + 2 } }
function keg(x, y) { return { mat: "powder", x: x, y: y, w: 0.7, h: 0.8 } }
function cave(name, cones, stars, build) { return level(name, cones, stars, build, "cave") }

// Grottan: taket ligger på CEIL meter. Hängande föremål lossnar när de träffas.
var CEIL = 9.6
// Droppsten som hänger rakt ned från taket
function stalactite(x, len) { return { mat: "stalactite", x: x, y: CEIL - len, w: 0.6, h: len, hang: 0 } }
// Discokula i en kedja; low är hur långt under taket kulan hänger (ovansidan)
function discoball(x, low, r) { var rr = r || 0.6; return { ball: true, mat: "discoball", x: x, y: CEIL - low - 2 * rr, r: rr, hang: low } }
// Ljuskrona: en bjälke i kedja
function chandelier(x, low, w) { return { mat: "chandelier", x: x, y: CEIL - low - 0.4, w: w || 2.2, h: 0.4, hang: low } }
// Kristall: fast och studsig
function crystal(x, y, w, h) { return { rock: true, style: "crystal", x: x, y: y, w: w, h: h } }

// Månen: låg gravitation. Månsten kan sväva fritt tills den träffas.
function moon(name, cones, stars, build) { return level(name, cones, stars, build, "moon") }
function floater(x, y, w, h, mat) { return { mat: mat || "moonrock", x: x, y: y, w: w, h: h, hang: 0, float: true } }
// En rymdkapsel: plåtväggar, plåttak och ett runt fönster (en tom ruta i mitten)
function capsule(out, x, y, width, height) { return floor(out, x, y, width, height, "metal") }
// Kraterkant: en fast vall av månsten
function crater(x, w, h) { return { rock: true, style: "crater", x: x, y: 0, w: w, h: h } }

// Godisfabriken
function candy(name, cones, stars, build) { return level(name, cones, stars, build, "candy") }
function jelly(x, y, w, h) { return { mat: "jelly", x: x, y: y, w: w, h: h } }
function mallow(x, y, w, h) { return { mat: "marshmallow", x: x, y: y, w: w || 0.9, h: h || 0.7 } }
function choc(x, y, w, h) { return { mat: "chocolate", x: x, y: y, w: w, h: h } }
// En våning med polkagrisstänger och en chokladkaka ovanpå
function candyFloor(out, x, y, width, height) { return floor(out, x, y, width, height, "candycane", "chocolate") }

// Tivolit. Alla perioder delar 8 s, så att allt är tillbaka på samma ställe när
// testet kontrollerar att banan står still (efter 8 s).
function fair(name, cones, stars, build) { return level(name, cones, stars, build, "fair") }

// Luftslottet: moln, vindbyar och ballonger.
function sky(name, cones, stars, build) { return level(name, cones, stars, build, "sky") }
// Ett moln att stå på (top = höjden på ovansidan)
function cloud(x, top, w) { return { rock: true, style: "cloud", x: x, y: top - 0.8, w: w, h: 0.8 } }
// Vindby: rektangel (x0..x1, y0..y1) med accelerationen (ax, ay) i m/s²
function wind(o, x0, x1, y0, y1, ax, ay) {
    if (!o.decor) o.decor = []
    o.decor.push({ type: "wind", x0: x0, x1: x1, y0: y0, y1: y1, ax: ax, ay: ay || 0 })
}
// Plattform som hålls uppe av ballonger. Ballongerna hänger i snören ovanför
// plattformen; spricker en av dem faller plattformen.
var _group = 0
function balloonPlatform(o, x, y, w, mat, balloons) {
    var gid = ++_group
    o.push({ mat: mat || "wood", x: x, y: y, w: w, h: 0.3, hang: 0, heldBy: gid })
    var n = balloons || 2
    for (var i = 0; i < n; i++) {
        var bx = n === 1 ? x : x - w / 2 + 0.3 + i * (w - 0.6) / (n - 1)
        o.push({ ball: true, mat: "balloon", x: bx, y: y + 0.3 + 1.4, r: 0.45, hang: 0, balloon: true, group: gid,
                 string: 1.4 })
    }
    return y + 0.3
}
// Studsmatta på marken (eller lutande, angle i radianer)
function trampoline(x, y, w, angle) { return { rock: true, style: "trampoline", x: x, y: y, w: w || 1.8, h: 0.35, angle: angle || 0 } }
// Plattform som åker fram och tillbaka: (ax, ay) är största utslaget i meter
function ride(x, y, w, ax, ay, period, phase) {
    return { rock: true, style: "ride", x: x, y: y, w: w, h: 0.3,
             move: { type: "line", ax: ax, ay: ay, period: period || 8, phase: phase || 0 } }
}
// Vagn: en plattform med kanter, så att det som står på den inte rullar av
function cart(o, x, y, w, ax, ay, period, phase) {
    o.push(ride(x, y, w, ax, ay, period, phase))
    var r1 = ride(x - w / 2 + 0.07, y + 0.3, 0.14, ax, ay, period, phase); r1.h = 0.4
    var r2 = ride(x + w / 2 - 0.07, y + 0.3, 0.14, ax, ay, period, phase); r2.h = 0.4
    o.push(r1, r2)
    return y + 0.3
}
// Pariserhjul med n gondoler. fill(o, i, x, y) får gondolens golv (mitt, ovansida) vid start.
function ferrisWheel(o, cx, cy, r, n, period, fill) {
    if (!o.decor) o.decor = []
    o.decor.push({ type: "wheel", x: cx, y: cy, r: r, period: period, n: n })
    for (var i = 0; i < n; i++) {
        var ph = 2 * Math.PI * i / n + Math.PI / 2 + Math.PI / n
        var gx = cx + r * Math.cos(ph), gy = cy + r * Math.sin(ph)
        var mv = function (ox, oy) { return { type: "circle", cx: cx, cy: cy, r: r, period: period, phase: ph, ox: ox, oy: oy } }
        // Golv och två sidor; gondolen hänger 1,1 m under ekern
        o.push({ rock: true, style: "gondola", x: gx, y: gy - 1.2, w: 1.5, h: 0.2, move: mv(0, -1.1) })
        o.push({ rock: true, style: "gondola", x: gx - 0.68, y: gy - 1.0, w: 0.14, h: 0.5, move: mv(-0.68, -0.75) })
        o.push({ rock: true, style: "gondola", x: gx + 0.68, y: gy - 1.0, w: 0.14, h: 0.5, move: mv(0.68, -0.75) })
        if (fill) fill(o, i, gx, gy - 1.0)
    }
}


// Vulkanön: en lavasjö börjar vid stranden (y = 0 är lavaytan). Basaltpelare
// står fast i lavan, glödande sten spricker i gnistor och värmen lyfter kottarna.
function volcano(name, cones, stars, build) { return level(name, cones, stars, build, "volcano") }
// Basaltpelare som sticker upp ur lavan; top är höjden över lavan
function basalt(x, w, top) { return { rock: true, style: "basalt", x: x, y: -3, w: w, h: top + 3 } }
function magma(x, y, s) { return { mat: "magma", x: x, y: y, w: s || 0.8, h: s || 0.8 } }
function obsidian(x, y, w, h) { return { mat: "obsidian", x: x, y: y, w: w, h: h } }
// Het luft över lavan: kottarna lyfts uppåt (ay i m/s²)
function heat(o, x0, x1, y0, y1, ay) {
    if (!o.decor) o.decor = []
    o.decor.push({ type: "wind", style: "heat", x0: x0, x1: x1, y0: y0, y1: y1, ax: 0, ay: ay })
}


// Djungeltemplet: lianer, stenkulor och tempelsten.
function jungle(name, cones, stars, build) { return level(name, cones, stars, build, "jungle") }
// Fast tempelsten: trappsteg, pelare, avsatser och valv
function temple(x, y, w, h) { return { rock: true, style: "temple", x: x, y: y, w: w, h: h } }
// Fast ramp av tempelsten från (x0, y0) ned till (x1, y1); ovansidan följer linjen
function ramp(x0, y0, x1, y1) {
    var a = Math.atan2(y1 - y0, x1 - x0), len = Math.sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0)), h = 0.4
    var cx = (x0 + x1) / 2 + Math.sin(a) * h / 2, cy = (y0 + y1) / 2 - Math.cos(a) * h / 2
    return { rock: true, style: "ramp", x: cx, y: cy - h / 2, w: len, h: h, angle: a }
}
// En gren som lianerna hänger i; y är grenens underkant
function branch(x, y, w) { return { rock: true, style: "branch", x: x, y: y, w: w, h: 0.4 } }
// Något som hänger i en lian från höjden anchor (grenens eller valvets underkant).
// Breda saker hänger i två lianer, en i var ände.
function vined(item, anchor) {
    var h = item.ball ? 2 * item.r : item.h
    item.hang = anchor - item.y - h
    item.vine = true
    if (!item.ball && item.w > 1.2) item.vines = 2
    return item
}
function bamboo(x, y, w, h) { return { mat: "bamboo", x: x, y: y, w: w, h: h } }
function tstone(x, y, w, h) { return { mat: "templestone", x: x, y: y, w: w, h: h } }
function idol(x, y) { return { mat: "idol", x: x, y: y, w: 0.55, h: 0.75 } }
// Stenkula som ligger still tills något knuffar den
function stoneBall(x, y, r) { return { ball: true, mat: "stoneball", x: x, y: y, r: r || 0.6 } }
// Stenkula som pendlar i en lian från (px, py). len = avståndet till kulans mitt,
// amp = största vinkeln (radianer). Perioden ska dela 8 s (som tivolit).
function swingBall(o, px, py, len, r, amp, period, phase) {
    var a = amp * Math.sin(phase || 0)
    o.push({ ball: true, mat: "stoneball", x: px + len * Math.sin(a), y: py - len * Math.cos(a) - r, r: r, hang: 0,
             swing: { px: px, py: py, len: len, amp: amp, period: period || 4, phase: phase || 0 } })
    o.push(branch(px, py, 1.8))
}

// Isfiskesjön: isflak över vattnet från stranden (x = 10). holes är vakar [mitt, bredd].
// knocks = hur många knack isen tål (1 = tunn is), cracked = redan sprucken.
function icelake(name, cones, stars, build) { return level(name, cones, stars, build, "icelake") }
var SHORE_ICE = 10
function iceSheet(o, holes, knocks, cracked, x1) {
    var end = x1 || 31, edges = [SHORE_ICE]
    holes = holes || []
    for (var i = 0; i < holes.length; i++) edges.push(holes[i][0] - holes[i][1] / 2, holes[i][0] + holes[i][1] / 2)
    edges.push(end)
    for (var k = 0; k < edges.length; k += 2) {
        var a = edges[k], b = edges[k + 1], n = Math.max(1, Math.round((b - a) / 2.2)), w = (b - a) / n
        for (var j = 0; j < n; j++)
            o.push({ rock: true, style: "lakeice", x: a + w * (j + 0.5), y: -0.4, w: w, h: 0.4, knocks: knocks || 2, cracked: !!cracked })
    }
}
// Skruvis: en vall av is som har tryckts upp och står fast (top = höjden över isen)
function ridge(x, w, top) { return { rock: true, style: "ridge", x: x, y: -3, w: w, h: top + 3 } }
// Ett metspö vid en vak (bara bild)
function rod(o, x) {
    if (!o.decor) o.decor = []
    o.decor.push({ type: "rod", x: x })
}

// Världarna i den ordning de spelas. first är numret på första banan.
var worlds = [
    { id: "forest", name: "Summer forest", first: 1, count: 10 },
    { id: "winter", name: "Winter forest", first: 11, count: 10 },
    { id: "sea", name: "Pirate cove", first: 21, count: 10 },
    { id: "cave", name: "Troll cave", first: 31, count: 10 },
    { id: "moon", name: "Trolls on the moon", first: 41, count: 10 },
    { id: "candy", name: "Candy factory", first: 51, count: 10 },
    { id: "fair", name: "Fun fair", first: 61, count: 10 },
    { id: "sky", name: "Castle in the clouds", first: 71, count: 10 },
    { id: "volcano", name: "Volcano island", first: 81, count: 10 },
    { id: "jungle", name: "Jungle temple", first: 91, count: 10 },
    { id: "icelake", name: "Ice fishing lake", first: 101, count: 10 }
]

function worldOf(n) {
    for (var i = worlds.length - 1; i >= 0; i--) if (n >= worlds[i].first) return worlds[i]
    return worlds[0]
}

var list = [
    // 1. En liten koja
    level("First cone", ["spruce", "spruce", "spruce"], [0, 10000, 15000], function (o) {
        var top = floor(o, 22, 0, 2.4, 2.0, "wood")
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "small"))
    }),

    // 2. Två kojor
    level("Two huts", ["spruce", "spruce", "spruce"], [0, 13000, 18000], function (o) {
        floor(o, 19, 0, 2.2, 1.8, "wood")
        o.push(troll(19, 0, "small"))
        var top = floor(o, 25, 0, 2.6, 2.4, "wood")
        o.push(troll(25, 0, "medium"))
        o.push(troll(25, top, "small"))
    }),

    // 3. Ett högt torn
    level("Watchtower", ["spruce", "pine", "spruce"], [0, 15000, 22000], function (o) {
        var y = floor(o, 23, 0, 2.4, 2.0, "wood")
        o.push(troll(23, 0, "small"))
        y = floor(o, 23, y, 2.4, 2.0, "wood")
        o.push(troll(23, y - 2.0 - T, "medium"))
        y = floor(o, 23, y, 2.0, 1.6, "wood")
        o.push(troll(23, y, "small"))
    }),

    // 4. Ispalatset
    level("Ice palace", ["pine", "pine", "spruce"], [0, 14000, 20000], function (o) {
        o.push(block(20, 0, 0.6, 2.4, "ice"), block(22.4, 0, 0.6, 2.4, "ice"))
        o.push(beam(21.2, 2.4, 3.2, "ice"))
        o.push(troll(21.2, 0, "medium"))
        o.push(block(24.8, 0, 0.6, 2.4 + T, "ice"))
        o.push(beam(23.6, 2.4 + T, 3.2, "ice"))
        o.push(troll(23.6, 0, "small"))
        o.push(block(21.2, 2.4 + T, 0.6, 1.4, "ice"), block(23.6, 2.65 + T, 0.6, 1.2, "ice"))
        o.push(troll(22.4, 2.65 + T, "small"))
    }),

    // 5. Stenbunkern
    level("Stone bunker", ["acorn", "spruce", "acorn"], [0, 13000, 18000], function (o) {
        o.push(block(21, 0, 0.6, 1.6, "stone"), block(24, 0, 0.6, 1.6, "stone"))
        o.push(beam(22.5, 1.6, 3.8, "wood"))
        o.push(troll(22.5, 0, "large"))
        o.push(block(22.5, 1.6 + T, 1.0, 1.0, "wood"))
        o.push(troll(22.5, 2.6 + T, "small"))
    }),

    // 6. På klippan
    level("On the cliff", ["chestnut", "spruce", "pine"], [0, 14000, 20000], function (o) {
        o.push(rock(24, 0, 6, 3))
        var y = floor(o, 23, 3, 2.2, 2.0, "wood")
        o.push(troll(23, 3, "medium"))
        y = floor(o, 25.2, 3, 2.0, 1.6, "ice")
        o.push(troll(25.2, 3, "small"))
        o.push(troll(23, 5.0 + T, "small"))
    }),

    // 7. Två torn och en bro
    level("The bridge", ["spruce", "pine", "acorn", "spruce"], [0, 23000, 32000], function (o) {
        var y1 = floor(o, 19.5, 0, 2.0, 2.4, "wood")
        var top1 = floor(o, 19.5, y1, 1.6, 1.4, "wood")
        o.push(troll(19.5, 0, "small"))
        var y2 = floor(o, 26.5, 0, 2.0, 2.4, "stone", "wood")
        floor(o, 26.5, y2, 1.6, 1.4, "wood")
        o.push(troll(26.5, 0, "medium"))
        o.push(beam(23, top1, 7.6, "wood"))
        o.push(troll(23, top1 + T, "small"))
        o.push(troll(23, 0, "large"))
    }),

    // 8. Pyramiden
    level("Pyramid", ["pine", "chestnut", "spruce"], [0, 13000, 18000], function (o) {
        var s = 1.0, x0 = 20.5
        for (var row = 0; row < 4; row++)
            for (var i = 0; i < 6 - row; i++) {
                var mat = row === 0 ? "stone" : (row === 3 ? "ice" : "wood")
                o.push(block(x0 + row * s / 2 + i * s, row * (s - 0.02), s - 0.02, s - 0.02, mat))
            }
        o.push(troll(x0 + 1.5 * s + 1.0, 4 * (s - 0.02), "medium"))
        o.push(troll(x0 - 1.2, 0, "small"))
        o.push(troll(x0 + 6.4, 0, "small"))
    }),

    // 9. Fästningen
    level("Fortress", ["acorn", "chestnut", "pine", "spruce"], [0, 23000, 32000], function (o) {
        o.push(block(19.5, 0, 0.6, 3.0, "stone"))
        var y = floor(o, 22, 0, 3.0, 2.2, "wood")
        o.push(troll(22, 0, "elder"))
        y = floor(o, 22, y, 2.4, 1.8, "ice", "wood")
        o.push(troll(22, y - 1.8 - T, "small"))
        o.push(block(24.6, 0, 0.6, 3.0, "stone"))
        o.push(beam(25.8, 3.0, 2.8, "wood"))
        o.push(block(27, 0, 0.6, 3.0, "stone"))
        o.push(troll(25.8, 0, "medium"))
        o.push(troll(25.8, 3.0 + T, "small"))
    }),

    // 10. Trollens by
    level("Troll village", ["spruce", "pine", "acorn", "chestnut", "spruce"], [0, 32000, 46000], function (o) {
        floor(o, 17.5, 0, 2.0, 1.8, "wood")
        o.push(troll(17.5, 0, "small"))
        o.push(rock(22.5, 0, 3, 1.5))
        var y = floor(o, 22.5, 1.5, 2.4, 2.0, "stone", "wood")
        o.push(troll(22.5, 1.5, "large"))
        y = floor(o, 22.5, y, 2.0, 1.6, "wood")
        o.push(troll(22.5, y - 1.6 - T, "small"))
        o.push(troll(22.5, y, "medium"))
        var y3 = floor(o, 27.5, 0, 2.4, 2.6, "ice", "wood")
        floor(o, 27.5, y3, 2.0, 1.6, "ice", "wood")
        o.push(troll(27.5, 0, "elder"))
        o.push(troll(27.5, y3, "small"))
    }),
    // ---- Vinterskogen ------------------------------------------------------

    // 11. Första snön
    winter("First snow", ["spruce", "spruce", "spruce"], [0, 14000, 20000], function (o) {
        var top = floor(o, 22, 0, 2.4, 2.0, "wood", "snow")
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "frost"))
        o.push(block(25.5, 0, 1.0, 1.0, "snow"), block(25.5, 1.0, 0.8, 0.8, "snow"))
        o.push(troll(25.5, 1.8, "small"))
    }),

    // 12. Igloon
    winter("The igloo", ["spruce", "pine", "spruce"], [0, 14000, 20000], function (o) {
        var x0 = 20.2, s = 0.8
        for (var r = 0; r < 2; r++) {
            o.push(block(x0 - r * 0.05, r * s, s, s, "snow"))
            o.push(block(x0 + 3.0 + r * 0.05, r * s, s, s, "snow"))
        }
        o.push(beam(x0 + 1.5, 2 * s, 4.0, "ice"))
        o.push(block(x0 + 0.8, 2 * s + T, 0.9, 0.7, "snow"), block(x0 + 2.2, 2 * s + T, 0.9, 0.7, "snow"))
        o.push(block(x0 + 1.5, 2 * s + T + 0.7, 1.6, 0.6, "snow"))
        o.push(troll(x0 + 1.5, 0, "medium"))
        o.push(troll(x0 + 1.5, 2 * s + T + 1.3, "frost"))
        o.push(troll(26.5, 0, "small"))
    }),

    // 13. Isen på sjön: hal mark och istorn
    winter("Frozen lake", ["pine", "spruce", "pine"], [0, 18000, 26000], function (o) {
        var y = floor(o, 20.5, 0, 2.2, 2.2, "ice")
        o.push(troll(20.5, 0, "frost"))
        o.push(troll(20.5, y, "small"))
        y = floor(o, 24.5, 0, 2.2, 1.6, "ice")
        y = floor(o, 24.5, y, 1.8, 1.6, "ice")
        o.push(troll(24.5, 0, "medium"))
        o.push(troll(24.5, y, "frost"))
    }),

    // 14. Snötrollets lya
    winter("Snow troll's den", ["acorn", "chestnut", "spruce"], [0, 12000, 17000], function (o) {
        o.push(rock(26.5, 0, 4, 1.2))
        o.push(block(20.8, 0, 0.6, 2.4, "stone"), block(24.2, 0, 0.6, 2.4, "stone"))
        o.push(beam(22.5, 2.4, 4.2, "wood"))
        o.push(block(22.5, 2.4 + T, 2.0, 0.7, "snow"))
        o.push(troll(22.5, 0, "snow"))
        o.push(troll(26.5, 1.2, "small"))
    }),

    // 15. Istappstornet
    winter("Icicle tower", ["pine", "acorn", "spruce", "pine"], [0, 20000, 29000], function (o) {
        var y = floor(o, 23.5, 0, 2.6, 2.0, "ice", "wood")
        o.push(troll(23.5, 0, "medium"))
        y = floor(o, 23.5, y, 2.2, 1.8, "ice", "wood")
        o.push(troll(23.5, y - 1.8 - T, "frost"))
        y = floor(o, 23.5, y, 1.8, 1.4, "ice")
        o.push(troll(23.5, y - 1.4 - T, "small"))
        o.push(troll(23.5, y, "frost"))
    }),

    // 16. Hoppbacken: trappsteg av klippa
    winter("Ski jump", ["spruce", "pine", "acorn"], [0, 13000, 18000], function (o) {
        o.push(rock(20.5, 0, 2.0, 1.0), rock(23.0, 0, 3.0, 2.0), rock(26.5, 0, 4.0, 3.2))
        o.push(block(20.5, 1.0, 0.9, 0.9, "snow"))
        o.push(troll(20.5, 1.9, "small"))
        floor(o, 23.0, 2.0, 1.8, 1.4, "wood", "snow")
        o.push(troll(23.0, 2.0, "frost"))
        floor(o, 26.5, 3.2, 2.0, 1.6, "ice", "wood")
        o.push(troll(26.5, 3.2, "medium"))
    }),

    // 17. Vedboden
    winter("Woodshed", ["acorn", "spruce", "chestnut", "spruce"], [0, 24000, 34000], function (o) {
        // Vedtravar av liggande klabbar
        for (var r = 0; r < 3; r++) {
            o.push(block(19.6, r * 0.48, 1.6, 0.48, "wood"))
            o.push(block(27.4, r * 0.48, 1.6, 0.48, "wood"))
        }
        o.push(troll(19.6, 1.44, "small"))
        o.push(troll(27.4, 1.44, "small"))
        var y = floor(o, 23.5, 0, 3.4, 2.2, "wood")
        o.push(troll(23.5, 0, "snow"))
        o.push(block(22.55, y, 0.5, 1.2, "snow"), block(24.45, y, 0.5, 1.2, "snow"))
        o.push(beam(23.5, y + 1.2, 2.6, "wood"))
        o.push(troll(23.5, y, "frost"))
    }),

    // 18. Frusna fästningen
    winter("Frozen fortress", ["acorn", "pine", "chestnut", "spruce"], [0, 28000, 40000], function (o) {
        o.push(block(19.8, 0, 0.6, 2.8, "stone"))
        var y = floor(o, 22.3, 0, 3.0, 2.0, "ice", "stone")
        o.push(troll(22.3, 0, "elder"))
        y = floor(o, 22.3, y, 2.4, 1.6, "ice", "wood")
        o.push(troll(22.3, y - 1.6 - T, "frost"))
        o.push(troll(22.3, y, "small"))
        o.push(block(25.0, 0, 0.6, 2.8, "stone"))
        o.push(beam(26.3, 2.8, 3.0, "ice"))
        o.push(block(27.6, 0, 0.6, 2.8, "stone"))
        o.push(troll(26.3, 0, "medium"))
        o.push(troll(26.3, 2.8 + T, "frost"))
    }),

    // 19. Norrskenstornet
    winter("Aurora tower", ["pine", "acorn", "chestnut", "pine", "spruce"], [0, 28000, 40000], function (o) {
        var y = floor(o, 24, 0, 2.8, 2.0, "stone", "wood")
        o.push(troll(24, 0, "large"))
        y = floor(o, 24, y, 2.4, 1.8, "wood")
        o.push(troll(24, y - 1.8 - T, "medium"))
        y = floor(o, 24, y, 2.0, 1.6, "ice", "wood")
        o.push(troll(24, y - 1.6 - T, "frost"))
        o.push(block(24, y, 1.4, 1.0, "snow"))
        o.push(troll(24, y + 1.0, "small"))
        o.push(block(19.5, 0, 1.0, 1.0, "snow"))
        o.push(troll(19.5, 1.0, "frost"))
    }),

    // 20. Vinterborgen
    winter("Winter castle", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 36000, 51000], function (o) {
        floor(o, 17.5, 0, 2.0, 1.6, "ice", "snow")
        o.push(troll(17.5, 0, "frost"))
        o.push(rock(22.5, 0, 3.4, 1.4))
        var y = floor(o, 22.5, 1.4, 2.6, 2.0, "stone", "wood")
        o.push(troll(22.5, 1.4, "snow"))
        y = floor(o, 22.5, y, 2.0, 1.6, "ice", "wood")
        o.push(troll(22.5, y - 1.6 - T, "small"))
        o.push(troll(22.5, y, "frost"))
        var y3 = floor(o, 27.5, 0, 2.4, 2.4, "stone", "wood")
        floor(o, 27.5, y3, 2.0, 1.6, "snow", "wood")
        o.push(troll(27.5, 0, "elder"))
        o.push(troll(27.5, y3, "medium"))
    }),
    // ---- Sjörövarviken --------------------------------------------------------

    // 21. Första skäret
    sea("Ahoy!", ["spruce", "spruce", "spruce"], [0, 14000, 19000], function (o) {
        o.push(isle(22, 5, 0.6))
        var top = floor(o, 21.5, 0.6, 2.2, 1.8, "wood")
        o.push(troll(21.5, 0.6, "small"))
        o.push(troll(21.5, top, "small"))
        o.push(troll(23.7, 0.6, "medium"))
    }),

    // 22. Vraket
    sea("Shipwreck", ["spruce", "pine", "spruce"], [0, 14000, 20000], function (o) {
        o.push(ship(22.5, 7, 1.2))
        o.push(block(20.0, 1.2, 0.9, 0.9, "wood"), keg(21.2, 1.2))
        o.push(troll(20.0, 2.1, "small"))
        var top = floor(o, 23.6, 1.2, 2.4, 2.0, "wood")
        o.push(troll(23.6, 1.2, "medium"))
        o.push(troll(23.6, top, "small"))
    }),

    // 23. Krutfatet
    sea("Powder keg", ["acorn", "spruce", "spruce"], [0, 15000, 21000], function (o) {
        o.push(isle(22.5, 7, 0.5))
        o.push(block(20.0, 0.5, 0.6, 2.2, "stone"), block(25.0, 0.5, 0.6, 2.2, "stone"))
        o.push(beam(22.5, 2.7, 5.6, "wood"))
        o.push(keg(22.5, 0.5))
        o.push(troll(21.3, 0.5, "small"), troll(23.7, 0.5, "small"))
        o.push(troll(22.5, 2.7 + T, "medium"))
    }),

    // 24. Fyren
    sea("Lighthouse", ["pine", "acorn", "spruce", "spruce"], [0, 24000, 35000], function (o) {
        o.push(isle(23.5, 4.6, 0.8))
        var y = floor(o, 23.5, 0.8, 2.4, 2.0, "stone", "wood")
        o.push(troll(23.5, 0.8, "medium"))
        y = floor(o, 23.5, y, 2.0, 1.8, "stone", "wood")
        o.push(troll(23.5, y - 1.8 - T, "small"))
        y = floor(o, 23.5, y, 1.6, 1.4, "wood")
        o.push(troll(23.5, y - 1.4 - T, "small"))
        o.push(troll(23.5, y, "captain"))
    }),

    // 25. Två skär och en bro
    sea("Two skerries", ["spruce", "pine", "acorn", "spruce"], [0, 18000, 26000], function (o) {
        o.push(isle(18.5, 3, 0.8), isle(26.5, 3.4, 0.8))
        var y1 = floor(o, 18.5, 0.8, 2.0, 2.2, "wood")
        var y2 = floor(o, 26.5, 0.8, 2.0, 2.2, "stone", "wood")
        o.push(troll(18.5, 0.8, "small"), troll(26.5, 0.8, "medium"))
        o.push(beam(22.5, y1, 8.4, "wood"))
        o.push(troll(22.5, y1 + T, "medium"))
        o.push(troll(19.5, y1 + T, "small"))
    }),

    // 26. Kaptenens skepp
    sea("Captain's ship", ["acorn", "chestnut", "spruce", "pine"], [0, 20000, 28000], function (o) {
        o.push(ship(23, 8, 1.4))
        o.push(block(19.6, 1.4, 0.4, 1.6, "wood"))
        o.push(keg(20.5, 1.4))
        var y = floor(o, 23.2, 1.4, 3.0, 2.0, "wood")
        o.push(troll(23.2, 1.4, "captain"))
        o.push(block(23.2, y, 1.2, 0.8, "wood"))
        o.push(troll(23.2, y + 0.8, "small"))
        o.push(block(26.4, 1.4, 0.4, 1.6, "wood"))
        o.push(troll(25.6, 1.4, "small"))
    }),

    // 27. Skattön
    sea("Treasure island", ["pine", "spruce", "chestnut", "spruce"], [0, 18000, 26000], function (o) {
        o.push(isle(23, 9, 0.6))
        var s = 1.0, x0 = 21
        for (var row = 0; row < 3; row++)
            for (var i = 0; i < 4 - row; i++)
                o.push(block(x0 + row * s / 2 + i * s, 0.6 + row * (s - 0.02), s - 0.02, s - 0.02, row === 1 ? "stone" : "wood"))
        o.push(troll(x0 + 1.5 * s, 0.6 + 3 * (s - 0.02), "medium"))
        o.push(troll(19.3, 0.6, "small"))
        o.push(keg(25.3, 0.6))
        o.push(troll(26.6, 0.6, "medium"))
    }),

    // 28. Flottan: två skepp
    sea("The fleet", ["spruce", "acorn", "pine", "chestnut"], [0, 23000, 34000], function (o) {
        o.push(ship(18.8, 5, 1.0), ship(26.2, 5.2, 1.4))
        var y = floor(o, 18.8, 1.0, 2.2, 1.8, "wood")
        o.push(troll(18.8, 1.0, "medium"), troll(18.8, y, "small"))
        o.push(keg(17.2, 1.0))
        y = floor(o, 26.2, 1.4, 2.4, 2.0, "wood", "stone")
        o.push(troll(26.2, 1.4, "captain"))
        o.push(keg(24.6, 1.4))
        o.push(troll(26.2, y, "small"))
    }),

    // 29. Hamnfästet
    sea("Harbour fort", ["acorn", "chestnut", "pine", "spruce", "spruce"], [0, 26000, 37000], function (o) {
        o.push(isle(23.5, 8.5, 1.0))
        o.push(block(19.8, 1.0, 0.6, 2.6, "stone"))
        var y = floor(o, 22.4, 1.0, 3.0, 2.2, "wood", "stone")
        o.push(troll(22.4, 1.0, "large"))
        y = floor(o, 22.4, y, 2.2, 1.6, "wood")
        o.push(troll(22.4, y - 1.6 - T, "small"))
        o.push(block(25.0, 1.0, 0.6, 2.6, "stone"), block(27.2, 1.0, 0.6, 2.6, "stone"))
        o.push(keg(25.7, 1.0), keg(26.5, 1.0))
        o.push(beam(26.1, 3.6, 2.8, "wood"))
        o.push(troll(26.1, 3.6 + T, "medium"))
        o.push(troll(22.4, y, "small"))
    }),

    // 30. Sjörövarborgen
    sea("Pirate fortress", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 39000, 56000], function (o) {
        o.push(ship(17.5, 4, 1.0))
        floor(o, 17.5, 1.0, 2.0, 1.6, "wood")
        o.push(troll(17.5, 1.0, "small"))
        o.push(isle(24.5, 9, 0.8))
        var y = floor(o, 22.3, 0.8, 2.6, 2.0, "stone", "wood")
        o.push(troll(22.3, 0.8, "captain"))
        y = floor(o, 22.3, y, 2.0, 1.6, "wood")
        o.push(troll(22.3, y - 1.6 - T, "medium"))
        o.push(troll(22.3, y, "small"))
        o.push(keg(24.6, 0.8))
        var y3 = floor(o, 27, 0.8, 2.4, 2.4, "stone", "wood")
        floor(o, 27, y3, 2.0, 1.4, "wood")
        o.push(troll(27, 0.8, "elder"))
        o.push(troll(27, y3, "medium"))
    }),
    // ---- Trollgrottan ---------------------------------------------------------

    // 31. In i berget: en droppsten hänger över trollen
    cave("Into the mountain", ["spruce", "spruce", "spruce"], [0, 14000, 19000], function (o) {
        var top = floor(o, 22, 0, 2.4, 2.0, "wood")
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "small"))
        o.push(stalactite(22, 2.2))
        o.push(troll(25.5, 0, "medium"))
        o.push(stalactite(25.5, 2.6))
    }),

    // 32. Droppstenssalen
    cave("Dripstone hall", ["spruce", "pine", "spruce"], [0, 14000, 20000], function (o) {
        floor(o, 19.5, 0, 2.2, 1.8, "wood")
        o.push(troll(19.5, 0, "small"))
        var y = floor(o, 24.5, 0, 2.6, 2.2, "stone", "wood")
        o.push(troll(24.5, 0, "medium"))
        o.push(troll(24.5, y, "small"))
        o.push(stalactite(19.5, 2.4), stalactite(22.0, 3.2), stalactite(24.5, 2.2), stalactite(27.0, 2.8))
    }),

    // 33. Kristallgruvan: en studsig kristallvägg står i vägen
    cave("Crystal mine", ["pine", "spruce", "acorn"], [0, 14000, 19000], function (o) {
        o.push(crystal(16.5, 0, 0.9, 2.6))
        var y = floor(o, 22, 0, 2.4, 2.0, "wood")
        o.push(troll(22, 0, "medium"))
        o.push(troll(22, y, "small"))
        o.push(crystal(26.5, 0, 1.4, 1.2))
        o.push(troll(26.5, 1.2, "small"))
        o.push(stalactite(24.3, 3.0))
    }),

    // 34. Dansgolvet under discokulan
    cave("Dance floor", ["spruce", "pine", "spruce"], [0, 15000, 21000], function (o) {
        o.push(rock(23.5, 0, 9, 0.5))
        o.push(troll(20.5, 0.5, "small"), troll(22.5, 0.5, "medium"), troll(24.5, 0.5, "small"), troll(26.5, 0.5, "medium"))
        o.push(discoball(23.5, 2.6, 0.75))
    }),

    // 35. Discokulan över tornet
    cave("Disco ball", ["acorn", "spruce", "pine"], [0, 16000, 23000], function (o) {
        var y = floor(o, 23.5, 0, 2.6, 2.2, "stone", "wood")
        o.push(troll(23.5, 0, "large"))
        y = floor(o, 23.5, y, 2.2, 1.8, "wood")
        o.push(troll(23.5, y - 1.8 - T, "small"))
        o.push(discoball(23.5, 0.6, 0.7))
        o.push(block(19.5, 0, 0.9, 0.9, "wood"))
        o.push(troll(19.5, 0.9, "small"))
    }),

    // 36. Ekosalen: höga torn nästan upp till taket
    cave("Echo hall", ["pine", "acorn", "spruce", "chestnut"], [0, 24000, 35000], function (o) {
        var y = floor(o, 21, 0, 2.2, 2.4, "stone", "wood")
        y = floor(o, 21, y, 2.0, 2.2, "wood")
        o.push(troll(21, 0, "medium"), troll(21, y - 2.2 - T, "small"))
        var y2 = floor(o, 26, 0, 2.2, 2.6, "wood")
        y2 = floor(o, 26, y2, 2.0, 2.2, "ice", "wood")
        o.push(troll(26, 0, "medium"), troll(26, y2 - 2.2 - T, "small"), troll(26, y2, "small"))
        o.push(stalactite(23.5, 3.6))
    }),

    // 37. Glittergrottan
    cave("Glitter cave", ["spruce", "pine", "acorn", "spruce"], [0, 19000, 27000], function (o) {
        o.push(crystal(18.5, 0, 1.2, 1.6))
        o.push(troll(18.5, 1.6, "small"))
        var y = floor(o, 22.5, 0, 2.6, 2.0, "stone", "wood")
        o.push(troll(22.5, 0, "large"))
        o.push(block(22.5, y, 1.0, 1.0, "ice"))
        o.push(troll(22.5, y + 1.0, "small"))
        o.push(crystal(26.8, 0, 1.0, 2.8))
        o.push(troll(28.0, 0, "medium"))
        o.push(stalactite(28.0, 3.4), stalactite(20.6, 2.4))
    }),

    // 38. Ljuskronan
    cave("Chandelier", ["spruce", "acorn", "pine", "spruce"], [0, 21000, 30000], function (o) {
        o.push(block(20.5, 0, 0.6, 1.6, "stone"), block(26.5, 0, 0.6, 1.6, "stone"))
        o.push(beam(23.5, 1.6, 6.8, "wood"))
        o.push(troll(22.0, 0, "medium"), troll(25.0, 0, "small"))
        o.push(troll(21.8, 1.6 + T, "small"), troll(25.2, 1.6 + T, "small"))
        o.push(chandelier(23.5, 1.6, 3.0))
        o.push(troll(23.5, 1.6 + T, "medium"))
    }),

    // 39. Bakom scenen: krutfat och droppsten
    cave("Backstage", ["acorn", "chestnut", "pine", "spruce"], [0, 19000, 27000], function (o) {
        o.push(block(19.8, 0, 0.6, 2.4, "stone"))
        var y = floor(o, 22.5, 0, 3.0, 2.2, "wood", "stone")
        o.push(keg(21.75, 0), troll(23.0, 0, "medium"))
        o.push(troll(22.5, y, "small"))
        o.push(block(25.3, 0, 0.6, 2.4, "stone"))
        o.push(keg(26.4, 0))
        o.push(troll(27.5, 0, "large"))
        o.push(stalactite(27.5, 3.0), stalactite(24.4, 2.6))
    }),

    // 40. Trolldiskot: diskjockeyn står på scenen
    cave("Troll disco", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 37000, 53000], function (o) {
        floor(o, 17.5, 0, 2.0, 1.6, "wood")
        o.push(troll(17.5, 0, "small"))
        o.push(rock(23.8, 0, 6.4, 1.0))
        var y = floor(o, 22.2, 1.0, 2.6, 2.0, "stone", "wood")
        o.push(troll(22.2, 1.0, "dj"))
        o.push(troll(22.2, y, "medium"))
        o.push(block(25.0, 1.0, 1.2, 0.9, "wood"), keg(26.6, 1.0))
        o.push(troll(25.0, 1.9, "small"))
        var y3 = floor(o, 28.3, 0, 2.2, 2.2, "stone", "wood")
        o.push(troll(28.3, 0, "elder"), troll(28.3, y3, "medium"))
        o.push(discoball(24.6, 1.2, 0.75))
        o.push(stalactite(19.8, 2.6), stalactite(28.3, 2.0))
    }),

    // ---- Trollen på månen (41–50) ------------------------------------------

    // 41. Ett litet steg: en rymdkapsel och låg gravitation
    moon("One small step", ["spruce", "spruce", "spruce"], [0, 11000, 15000], function (o) {
        var top = capsule(o, 22, 0, 2.4, 2.0)
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "small"))
    }),

    // 42. Månbasen: två kapslar, och trollen har bubbelhjälm
    moon("Moon base", ["spruce", "pine", "spruce", "spruce"], [0, 15000, 22000], function (o) {
        capsule(o, 19.5, 0, 2.2, 1.8)
        o.push(troll(19.5, 0, "small"))
        var top = capsule(o, 25, 0, 2.6, 2.2)
        o.push(troll(25, 0, "medium"))
        o.push(troll(25, top, "small"))
    }),

    // 43. Svävande stenar: troll på stenar som svävar fritt
    moon("Floating rocks", ["spruce", "pine", "spruce"], [0, 12000, 17000], function (o) {
        o.push(floater(19.5, 3.2, 1.8, 0.6))
        o.push(troll(19.5, 3.8, "small"))
        o.push(floater(23.5, 5.0, 2.0, 0.6))
        o.push(troll(23.5, 5.6, "medium"))
        o.push(block(26.5, 0, 1.0, 1.0, "moonrock"))
        o.push(troll(26.5, 1.0, "small"))
    }),

    // 44. Kratern: trollen gömmer sig mellan kraterkanterna
    moon("Crater", ["pine", "acorn", "spruce", "spruce"], [0, 18000, 26000], function (o) {
        o.push(crater(19.6, 1.4, 1.6), crater(27.4, 1.4, 1.6))
        o.push(troll(21.8, 0, "medium"), troll(25.2, 0, "small"))
        var y = capsule(o, 23.5, 0, 2.0, 1.6)
        o.push(troll(23.5, 0, "small"))
        o.push(troll(23.5, y, "small"))
        o.push(troll(27.4, 1.6, "small"))
    }),

    // 45. Startplattan: ett högt raketttorn av plåt
    moon("Launch pad", ["spruce", "pine", "acorn", "spruce"], [0, 21000, 30000], function (o) {
        var y = floor(o, 23.5, 0, 2.6, 2.2, "moonrock", "metal")
        o.push(troll(23.5, 0, "medium"))
        y = capsule(o, 23.5, y, 2.2, 2.0)
        o.push(troll(23.5, y - 2.0 - T, "small"))
        y = capsule(o, 23.5, y, 1.8, 1.6)
        o.push(troll(23.5, y - 1.6 - T, "small"))
        o.push(troll(23.5, y, "small"))
    }),

    // 46. Satelliten: en lång plåtbalk svävar över basen
    moon("Satellite", ["pine", "spruce", "acorn", "spruce"], [0, 18000, 25000], function (o) {
        o.push(floater(23.5, 5.6, 5.0, 0.4, "metal"))
        o.push(troll(22.0, 6.0, "small"), troll(25.0, 6.0, "small"))
        var y = floor(o, 23.5, 0, 2.6, 2.0, "moonrock", "metal")
        o.push(troll(23.5, 0, "large"))
        o.push(block(23.5, y, 1.0, 1.0, "moonrock"))
        o.push(crater(18.8, 1.2, 1.4))
    }),

    // 47. Asteroidbältet: många svävande stenar på olika höjd
    moon("Asteroid belt", ["pine", "spruce", "chestnut", "pine"], [0, 21000, 29000], function (o) {
        o.push(floater(18.5, 2.6, 1.4, 0.6)); o.push(troll(18.5, 3.2, "small"))
        o.push(floater(21.5, 4.6, 1.6, 0.6)); o.push(troll(21.5, 5.2, "medium"))
        o.push(floater(24.5, 3.2, 1.4, 0.6)); o.push(troll(24.5, 3.8, "small"))
        o.push(floater(27.3, 5.4, 1.6, 0.6)); o.push(troll(27.3, 6.0, "small"))
        o.push(block(26.0, 0, 1.2, 1.2, "moonrock"))
        o.push(troll(26.0, 1.2, "small"))
    }),

    // 48. Månens baksida: sten och plåt, och en sten som svävar över tornet
    moon("Dark side", ["acorn", "chestnut", "spruce", "pine"], [0, 23000, 33000], function (o) {
        o.push(crater(18.2, 1.2, 1.2))
        o.push(troll(18.2, 1.2, "small"))
        var y = floor(o, 22.5, 0, 2.6, 2.2, "moonrock", "metal")
        o.push(troll(22.5, 0, "large"))
        y = capsule(o, 22.5, y, 2.2, 1.8)
        o.push(troll(22.5, y - 1.8 - T, "small"))
        o.push(floater(22.5, y + 1.6, 1.4, 0.7))
        var y2 = floor(o, 27, 0, 2.2, 2.0, "moonrock", "metal")
        o.push(troll(27, 0, "medium"), troll(27, y2, "small"))
    }),

    // 49. Rymdstationen: en kapsel ute i rymden, på en svävande plattform
    moon("Space station", ["spruce", "pine", "acorn", "chestnut"], [0, 22000, 32000], function (o) {
        o.push(floater(24.5, 3.4, 4.2, 0.4, "metal"))
        var y = capsule(o, 24.5, 3.8, 2.4, 1.8)
        o.push(troll(24.5, 3.8, "medium"))
        o.push(troll(24.5, y, "small"))
        o.push(floater(19.5, 5.2, 1.4, 0.6)); o.push(troll(19.5, 5.8, "small"))
        capsule(o, 20.5, 0, 2.0, 1.6)
        o.push(troll(20.5, 0, "small"))
        o.push(block(28.2, 0, 1.0, 1.4, "metal"))
        o.push(troll(28.2, 1.4, "small"))
    }),

    // 50. Månborgen: befälhavaren i rymddräkt
    moon("Moon fortress", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 36000, 52000], function (o) {
        capsule(o, 17.5, 0, 2.0, 1.6)
        o.push(troll(17.5, 0, "small"))
        o.push(rock(23.8, 0, 6.4, 1.0))
        var y = floor(o, 22.2, 1.0, 2.6, 2.0, "moonrock", "metal")
        o.push(troll(22.2, 1.0, "astronaut"))
        o.push(troll(22.2, y, "medium"))
        o.push(block(25.2, 1.0, 1.2, 1.0, "metal"))
        o.push(troll(25.2, 2.0, "small"))
        var y3 = capsule(o, 28.3, 0, 2.2, 2.2)
        o.push(troll(28.3, 0, "elder"), troll(28.3, y3, "medium"))
        o.push(floater(25.2, 5.4, 1.6, 0.6)); o.push(troll(25.2, 6.0, "small"))
    }),
    // ---- Godisfabriken -------------------------------------------------------

    // 51. Söt start
    candy("Sweet start", ["spruce", "spruce", "spruce"], [0, 14000, 20000], function (o) {
        var top = candyFloor(o, 21.5, 0, 2.4, 2.0)
        o.push(troll(21.5, 0, "small"), troll(21.5, top, "small"))
        o.push(jelly(25.5, 0, 1.2, 1.2))
        o.push(troll(25.5, 1.2, "medium"))
    }),

    // 52. Geléstapeln
    candy("Jelly stack", ["spruce", "pine", "spruce"], [0, 12000, 17000], function (o) {
        o.push(jelly(21.4, 0, 1.0, 1.0), jelly(22.6, 0, 1.0, 1.0), jelly(23.8, 0, 1.0, 1.0))
        o.push(jelly(22.0, 1.0, 1.0, 1.0), jelly(23.2, 1.0, 1.0, 1.0))
        o.push(jelly(22.6, 2.0, 1.0, 1.0))
        o.push(troll(22.6, 3.0, "medium"))
        o.push(troll(20.2, 0, "small"), troll(25.0, 0, "small"))
    }),

    // 53. Marshmallowkuddar: trollen landar mjukt
    candy("Soft landing", ["pine", "spruce", "acorn"], [0, 17000, 24000], function (o) {
        var y = candyFloor(o, 22.5, 0, 3.6, 2.4)
        o.push(mallow(21.6, y), mallow(23.4, y))
        o.push(troll(21.6, y + 0.7, "small"), troll(23.4, y + 0.7, "small"))
        o.push(mallow(22.5, 0, 1.6, 0.8))
        o.push(troll(22.5, 0.8, "medium"))
        o.push(mallow(26.5, 0, 1.2, 1.0))
        o.push(troll(26.5, 1.0, "small"))
    }),

    // 54. Chokladkakorna
    candy("Chocolate bars", ["acorn", "spruce", "acorn"], [0, 16000, 23000], function (o) {
        o.push(choc(20.5, 0, 0.6, 2.2), choc(24.5, 0, 0.6, 2.2))
        o.push(choc(22.5, 2.2, 4.6, 0.4))
        o.push(troll(22.5, 0, "large"))
        o.push(choc(22.5, 2.6, 1.2, 0.8))
        o.push(troll(22.5, 3.4, "small"))
        o.push(troll(26.5, 0, "medium"))
    }),

    // 55. Gelébron
    candy("Jelly bridge", ["spruce", "pine", "acorn", "spruce"], [0, 20000, 28000], function (o) {
        var y1 = candyFloor(o, 19.5, 0, 2.0, 2.4)
        var y2 = candyFloor(o, 26.5, 0, 2.0, 2.4)
        o.push(troll(19.5, 0, "small"), troll(26.5, 0, "medium"))
        o.push(jelly(23, y1, 7.6, 0.4))
        o.push(troll(23, y1 + 0.4, "medium"))
        o.push(troll(20.3, y1 + 0.4, "small"))
    }),

    // 56. Klubbskogen: höga polkagrisstänger med små plattor
    candy("Lollipop forest", ["pine", "spruce", "pine", "spruce"], [0, 21000, 29000], function (o) {
        var xs = [19.5, 22.0, 24.5, 27.0], hs = [2.4, 3.4, 2.8, 3.8]
        for (var i = 0; i < xs.length; i++) {
            o.push({ mat: "candycane", x: xs[i], y: 0, w: 0.3, h: hs[i] })
            o.push(choc(xs[i], hs[i], 1.3, 0.3))
            o.push(troll(xs[i], hs[i] + 0.3, i % 2 ? "small" : "medium"))
        }
    }),

    // 57. Packrummet: lådor och marshmallows
    candy("Packing room", ["acorn", "pine", "chestnut", "spruce"], [0, 19000, 27000], function (o) {
        o.push(block(20.0, 0, 1.2, 1.2, "wood"), block(21.3, 0, 1.2, 1.2, "wood"), block(20.6, 1.2, 1.2, 1.2, "wood"))
        o.push(troll(20.6, 2.4, "small"))
        var y = candyFloor(o, 24.2, 0, 2.6, 2.2)
        o.push(mallow(24.2, 0, 1.4, 0.8), troll(24.2, 0.8, "small"))
        o.push(mallow(24.2, y, 1.6, 0.8), troll(24.2, y + 0.8, "medium"))
        o.push(jelly(27.4, 0, 1.0, 1.6), troll(27.4, 1.6, "small"))
    }),

    // 58. Tårtan: lager av choklad, marshmallow och gelé
    candy("The cake", ["spruce", "acorn", "pine", "chestnut"], [0, 22000, 32000], function (o) {
        o.push(choc(23, 0, 7.0, 0.8))
        o.push(mallow(23, 0.8, 5.0, 0.6))
        o.push(jelly(23, 1.4, 3.0, 0.7))
        o.push(choc(23, 2.1, 1.6, 0.6))
        o.push(troll(19.95, 0.8, "small"), troll(26.1, 0.8, "medium"))
        o.push(troll(21.0, 1.4, "small"), troll(25.0, 1.4, "small"))
        o.push(troll(23, 2.7, "large"))
    }),

    // 59. Godisvalvet
    candy("Candy vault", ["acorn", "chestnut", "pine", "acorn", "spruce"], [0, 18000, 26000], function (o) {
        o.push(choc(19.8, 0, 0.7, 2.6))
        var y = floor(o, 22.6, 0, 3.0, 2.2, "candycane", "chocolate")
        o.push(troll(22.6, 0, "large"))
        o.push(jelly(22.6, y, 1.6, 0.8), troll(22.6, y + 0.8, "small"))
        o.push(choc(25.4, 0, 0.7, 2.6))
        o.push(mallow(26.7, 0, 1.2, 0.8), troll(26.7, 0.8, "medium"))
        o.push(choc(28.0, 0, 0.6, 1.8))
    }),

    // 60. Sockerbagarens slott
    candy("Sugar castle", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 36000, 51000], function (o) {
        o.push(jelly(17.6, 0, 1.2, 1.2), troll(17.6, 1.2, "small"))
        o.push(choc(23.4, 0, 6.6, 0.8))
        var y = candyFloor(o, 22.0, 0.8, 2.6, 2.0)
        o.push(troll(22.0, 0.8, "baker"))
        o.push(mallow(22.0, y, 1.4, 0.7), troll(22.0, y + 0.7, "medium"))
        o.push(jelly(25.2, 0.8, 1.2, 1.0), troll(25.2, 1.8, "small"))
        var y3 = candyFloor(o, 28.2, 0, 2.0, 2.4)
        o.push(troll(28.2, 0, "elder"), troll(28.2, y3, "medium"))
    }),
    // ---- Tivolit ---------------------------------------------------------------

    // 61. Välkommen till tivolit
    fair("Roll up!", ["spruce", "spruce", "spruce"], [0, 14000, 19000], function (o) {
        o.push(trampoline(15.5, 0, 2.2))
        var top = floor(o, 22, 0, 2.4, 2.0, "wood")
        o.push(troll(22, 0, "small"), troll(22, top, "small"))
        o.push(troll(25.5, 0, "medium"))
    }),

    // 62. Studsmattorna: en mur i vägen
    fair("Trampoline park", ["spruce", "pine", "spruce"], [0, 14000, 20000], function (o) {
        o.push(trampoline(13.5, 0, 2.2), trampoline(16.5, 0, 1.8, -0.25))
        o.push(block(19.0, 0, 0.6, 3.4, "stone"))
        o.push(troll(20.4, 0, "small"))
        var y = floor(o, 23.5, 0, 2.4, 2.0, "wood")
        o.push(troll(23.5, 0, "medium"), troll(23.5, y, "small"))
    }),

    // 63. Karusellvagnen åker fram och tillbaka
    fair("Merry ride", ["spruce", "pine", "acorn"], [0, 13000, 19000], function (o) {
        var y = cart(o, 23, 2.2, 2.25, 2.5, 0, 8)
        o.push(troll(22.48, y, "small"), troll(23.48, y, "medium"))
        o.push(block(20, 0, 0.5, 2.2, "metal"), block(26, 0, 0.5, 2.2, "metal"))
        o.push(troll(27.5, 0, "small"))
    }),

    // 64. Hissen
    fair("Elevator", ["pine", "spruce", "acorn", "spruce"], [0, 20000, 28000], function (o) {
        var y = cart(o, 21.5, 1.0, 2.6, 0, 2.6, 8)
        o.push(troll(21.5, y, "medium"))
        var y2 = floor(o, 26, 0, 2.4, 2.2, "metal", "wood")
        y2 = floor(o, 26, y2, 2.0, 1.8, "wood")
        o.push(troll(26, 0, "small"), troll(26, y2 - 1.8 - T, "small"), troll(26, y2, "small"))
    }),

    // 65. Pariserhjulet
    fair("Ferris wheel", ["spruce", "pine", "acorn", "spruce"], [0, 14000, 20000], function (o) {
        ferrisWheel(o, 23.5, 5.4, 2.7, 4, 8, function (o, i, x, y) { o.push(troll(x, y, i % 2 ? "small" : "medium")) })
    }),

    // 66. Skjutbanan: två vagnar åt varsitt håll
    fair("Shooting gallery", ["spruce", "pine", "acorn", "pine"], [0, 16000, 23000], function (o) {
        var y1 = cart(o, 23, 1.6, 1.95, 2.2, 0, 8)
        o.push(troll(22.6, y1, "small"), troll(23.4, y1, "small"))
        var y2 = cart(o, 23, 4.4, 1.95, 2.2, 0, 8, Math.PI)
        o.push(troll(22.6, y2, "small"), troll(23.4, y2, "small"))
        o.push(block(28.4, 0, 0.6, 6.0, "wood"))
    }),

    // 67. Slå på klubban: ett högt, smalt torn med en klocka överst
    fair("High striker", ["acorn", "spruce", "pine", "spruce"], [0, 20000, 29000], function (o) {
        o.push(trampoline(15.0, 0, 2.0))
        var y = floor(o, 24, 0, 1.8, 2.4, "metal", "wood")
        y = floor(o, 24, y, 1.6, 2.2, "wood")
        y = floor(o, 24, y, 1.4, 2.0, "wood")
        o.push(troll(24, 0, "medium"), troll(24, y - 2.0 - T, "small"), troll(24, y, "small"))
        o.push(troll(20.5, 0, "small"))
    }),

    // 68. Cirkustältet
    fair("Big top", ["spruce", "acorn", "pine", "chestnut"], [0, 21000, 30000], function (o) {
        var y = floor(o, 20.5, 0, 2.4, 2.2, "wood")
        var y2 = floor(o, 26.5, 0, 2.4, 2.2, "wood")
        o.push(troll(20.5, 0, "small"), troll(26.5, 0, "small"))
        o.push(beam(23.5, y, 8.6, "wood"))
        o.push(block(23.5, y + 0.25, 1.2, 0.9, "wood"), troll(23.5, y + 1.15, "large"))
        o.push(troll(23.5, 0, "medium"))
        o.push(trampoline(15.5, 0, 2.0))
    }),

    // 69. Berg-och-dalbanan: vagnen åker snett upp och ned
    fair("Roller coaster", ["pine", "acorn", "spruce", "chestnut"], [0, 14000, 20000], function (o) {
        var y = cart(o, 22.5, 2.2, 2.25, 2.4, 1.6, 8)
        o.push(troll(21.98, y, "small"), troll(22.98, y, "medium"))
        o.push(block(27.3, 0, 0.5, 2.6, "metal"), block(28.7, 0, 0.5, 2.6, "metal"))
        o.push(beam(28.0, 2.6, 1.9, "wood"), troll(28.0, 2.6 + T, "small"))
    }),

    // 70. Stora finalen: pariserhjul, studsmatta och den starke mannen
    fair("Grand finale", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 28000, 39000], function (o) {
        o.push(trampoline(14.5, 0, 2.0))
        var y = floor(o, 19.5, 0, 2.6, 2.2, "metal", "wood")
        o.push(troll(19.5, 0, "strongman"), troll(19.5, y, "small"))
        ferrisWheel(o, 25.5, 5.6, 2.4, 4, 8, function (o, i, x, y) { if (i !== 3) o.push(troll(x, y, i === 1 ? "medium" : "small")) })
        o.push(trampoline(25.5, 0, 2.0))
    }),
    // ---- Luftslottet ------------------------------------------------------------

    // 71. Ovanför molnen
    sky("Above the clouds", ["spruce", "spruce", "spruce"], [0, 14000, 19000], function (o) {
        o.push(cloud(22.5, 1.0, 6.0))
        var top = floor(o, 21.5, 1.0, 2.4, 2.0, "wood")
        o.push(troll(21.5, 1.0, "small"), troll(21.5, top, "small"))
        o.push(troll(24.4, 1.0, "medium"))
    }),

    // 72. Ballongen: spräck den så faller plattformen
    sky("Balloon lift", ["spruce", "pine", "spruce"], [0, 13000, 19000], function (o) {
        var y = balloonPlatform(o, 21.5, 3.6, 3.2, "wood", 2)
        o.push(troll(21.0, y, "small"), troll(22.1, y, "medium"))
        o.push(cloud(26.5, 1.0, 3.2))
        o.push(troll(26.5, 1.0, "small"))
    }),

    // 73. Byigt: motvind mellan molnen
    sky("Gusty", ["spruce", "acorn", "spruce", "pine"], [0, 14000, 19000], function (o) {
        wind(o, 13, 18, -2, 12, -7, 0)
        o.push(cloud(23, 1.2, 6.4))
        var y = floor(o, 22, 1.2, 2.4, 2.0, "wood")
        o.push(troll(22, 1.2, "medium"), troll(22, y, "small"))
        o.push(troll(25, 1.2, "small"))
    }),

    // 74. Uppvind: kottarna lyfts uppåt
    sky("Updraft", ["spruce", "pine", "acorn"], [0, 14000, 19000], function (o) {
        wind(o, 14, 19, -2, 12, 0, 9)
        o.push(cloud(20.5, 4.5, 2.8), cloud(26, 2.0, 3.4))
        o.push(troll(20.5, 4.5, "medium"))
        var y = floor(o, 26, 2.0, 2.2, 1.8, "wood")
        o.push(troll(26, 2.0, "small"), troll(26, y, "small"))
    }),

    // 75. Svävande öar
    sky("Floating isles", ["pine", "spruce", "acorn", "spruce"], [0, 18000, 26000], function (o) {
        o.push(cloud(17.5, 2.0, 2.4), cloud(21.5, 4.2, 2.4), cloud(25.5, 1.4, 2.8))
        o.push(troll(17.5, 2.0, "small"), troll(21.5, 4.2, "small"))
        var y = floor(o, 25.5, 1.4, 2.0, 1.8, "ice", "wood")
        o.push(troll(25.5, 1.4, "medium"), troll(25.5, y, "small"))
    }),

    // 76. Ballongbron: två plattformar med ballonger
    sky("Balloon bridge", ["spruce", "pine", "acorn", "spruce"], [0, 19000, 26000], function (o) {
        var y1 = balloonPlatform(o, 19.5, 2.8, 2.6, "wood", 2)
        o.push(troll(19.5, y1, "medium"))
        var y2 = balloonPlatform(o, 25.5, 4.4, 2.6, "metal", 2)
        o.push(troll(25.0, y2, "small"), troll(26.0, y2, "small"))
        o.push(cloud(22.5, 0.6, 2.4), troll(22.5, 0.6, "small"))
    }),

    // 77. Stormfronten: fallvind över molnet
    sky("Storm front", ["acorn", "spruce", "pine", "chestnut"], [0, 17000, 24000], function (o) {
        wind(o, 16, 21, -2, 12, 3, -9)
        o.push(cloud(24.5, 1.6, 6.2))
        var y = floor(o, 23.5, 1.6, 2.6, 2.2, "stone", "wood")
        o.push(troll(23.5, 1.6, "large"), troll(23.5, y, "small"))
        o.push(troll(26.6, 1.6, "small"))
    }),

    // 78. Luftskeppet: en stor plattform med tre ballonger
    sky("Airship", ["spruce", "pine", "acorn", "chestnut"], [0, 16000, 23000], function (o) {
        var y = balloonPlatform(o, 23.5, 3.2, 5.0, "metal", 3)
        o.push(block(21.6, y, 0.25, 1.4, "wood"), block(25.4, y, 0.25, 1.4, "wood"))
        o.push(troll(22.4, y, "small"), troll(23.5, y, "medium"), troll(24.6, y, "small"))
        o.push(cloud(23.5, 0.0, 3.0))
    }),

    // 79. Molnslottet
    sky("Cloud castle", ["acorn", "chestnut", "pine", "spruce", "spruce"], [0, 24000, 34000], function (o) {
        wind(o, 12, 16, -2, 12, -5, 0)
        o.push(cloud(24, 0.8, 8.6))
        o.push(block(20.4, 0.8, 0.6, 2.6, "stone"))
        var y = floor(o, 23, 0.8, 3.0, 2.2, "wood", "stone")
        o.push(troll(23, 0.8, "large"))
        y = floor(o, 23, y, 2.2, 1.6, "wood")
        o.push(troll(23, y - 1.6 - T, "small"), troll(23, y, "small"))
        o.push(block(26.2, 0.8, 0.6, 2.6, "stone"))
        o.push(troll(27.4, 0.8, "medium"))
    }),

    // 80. Stormtrollet
    sky("Storm troll", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 26000, 37000], function (o) {
        wind(o, 13, 17, -2, 12, 0, -7)
        var y1 = balloonPlatform(o, 18.5, 3.6, 2.6, "wood", 2)
        o.push(troll(18.5, y1, "medium"))
        o.push(cloud(25, 1.0, 7.0))
        var y = floor(o, 24, 1.0, 2.8, 2.2, "stone", "wood")
        o.push(troll(24, 1.0, "storm"), troll(24, y, "small"))
        var y3 = balloonPlatform(o, 27.4, 4.6, 2.2, "metal", 2)
        o.push(troll(27.4, y3, "small"))
    }),
    // ---- Vulkanön ---------------------------------------------------------------

    // 81. Lavasjön: knuffa trollen i lavan
    volcano("Lava lake", ["spruce", "spruce", "spruce"], [0, 14000, 19000], function (o) {
        o.push(basalt(22.5, 5.6, 0.8))
        var top = floor(o, 21.6, 0.8, 2.4, 2.0, "wood")
        o.push(troll(21.6, 0.8, "small"), troll(21.6, top, "small"))
        o.push(troll(24.4, 0.8, "medium"))
    }),

    // 82. Glödande stenar: de spricker i gnistor
    volcano("Glowing rocks", ["spruce", "pine", "spruce"], [0, 14000, 20000], function (o) {
        o.push(basalt(22.5, 6.4, 0.6))
        var y = floor(o, 21.0, 0.6, 2.4, 2.0, "wood")
        o.push(troll(21.0, 0.6, "medium"), troll(21.0, y, "small"))
        o.push(magma(23.0, 0.6))
        o.push(troll(24.6, 0.6, "small"))
    }),

    // 83. Obsidianmuren: hårt, halt vulkanglas
    volcano("Obsidian wall", ["acorn", "spruce", "pine"], [0, 15000, 21000], function (o) {
        o.push(basalt(23, 6.0, 0.8))
        o.push(obsidian(20.6, 0.8, 0.5, 2.4))
        var y = floor(o, 23, 0.8, 2.6, 2.0, "obsidian", "wood")
        o.push(troll(23, 0.8, "medium"), troll(23, y, "small"))
        o.push(troll(25.4, 0.8, "small"))
    }),

    // 84. Het luft: värmen från lavan lyfter kottarna
    volcano("Hot air", ["spruce", "pine", "acorn"], [0, 14000, 19000], function (o) {
        heat(o, 12, 17, -2, 12, 9)
        o.push(basalt(20.5, 2.2, 4.2), basalt(26, 3.6, 1.4))
        o.push(troll(20.5, 4.2, "medium"))
        var y = floor(o, 26, 1.4, 2.2, 1.8, "wood")
        o.push(troll(26, 1.4, "small"), troll(26, y, "small"))
    }),

    // 85. Basaltpelarna
    volcano("Basalt columns", ["pine", "spruce", "acorn", "spruce"], [0, 18000, 26000], function (o) {
        o.push(basalt(17.5, 1.6, 1.6), basalt(20.5, 1.6, 3.2), basalt(23.5, 1.6, 2.2), basalt(26.5, 2.6, 1.0))
        o.push(troll(17.5, 1.6, "small"), troll(20.5, 3.2, "small"), troll(23.5, 2.2, "medium"))
        o.push(magma(25.9, 1.0, 0.7))
        o.push(troll(27.1, 1.0, "small"))
    }),

    // 86. Lavabron: en bro mellan två pelare
    volcano("Lava bridge", ["spruce", "pine", "acorn", "spruce"], [0, 15000, 22000], function (o) {
        o.push(basalt(19.5, 1.8, 1.0), basalt(26.5, 1.8, 1.0))
        o.push(col(19.5, 1.0, 1.8, "wood"), col(26.5, 1.0, 1.8, "wood"))
        o.push(beam(23, 2.8, 8.0, "wood"))
        o.push(troll(21.0, 2.8 + T, "small"), troll(23.0, 2.8 + T, "medium"), troll(25.0, 2.8 + T, "small"))
    }),

    // 87. Gnistkedjan: en glödande sten tänder nästa
    volcano("Ember chain", ["acorn", "spruce", "pine", "chestnut"], [0, 22000, 31000], function (o) {
        o.push(basalt(23.5, 9.0, 0.6))
        o.push(magma(19.8, 0.6))
        var y = floor(o, 21.6, 0.6, 2.2, 1.8, "wood")
        o.push(troll(21.6, 0.6, "small"), troll(21.6, y, "small"))
        o.push(magma(23.4, 0.6))
        var y2 = floor(o, 25.2, 0.6, 2.2, 1.8, "obsidian", "wood")
        o.push(troll(25.2, 0.6, "medium"), troll(25.2, y2, "small"))
        o.push(magma(27.2, 0.6))
    }),

    // 88. Kraterkanten: uppvind framför ett högt torn
    volcano("Crater rim", ["spruce", "pine", "acorn", "chestnut"], [0, 17000, 25000], function (o) {
        heat(o, 13, 18, -2, 12, 7)
        o.push(basalt(24, 5.4, 2.0))
        var y = floor(o, 23.2, 2.0, 2.4, 2.0, "obsidian", "wood")
        o.push(troll(23.2, 2.0, "medium"))
        y = floor(o, 23.2, y, 2.0, 1.6, "wood")
        o.push(troll(23.2, y - 1.6 - T, "small"), troll(23.2, y, "small"))
        o.push(magma(25.7, 2.0))
    }),

    // 89. Eldtemplet
    volcano("Fire temple", ["acorn", "chestnut", "pine", "spruce", "spruce"], [0, 22000, 31000], function (o) {
        o.push(basalt(23.5, 9.4, 0.8))
        o.push(obsidian(19.6, 0.8, 0.6, 2.6))
        var y = floor(o, 23, 0.8, 3.0, 2.2, "stone", "obsidian")
        o.push(troll(23, 0.8, "large"))
        o.push(magma(23, y, 0.7))
        y = floor(o, 23, y, 2.2, 1.6, "wood")
        o.push(troll(23, y, "small"))
        o.push(obsidian(26.2, 0.8, 0.6, 2.6))
        o.push(troll(27.4, 0.8, "medium"))
    }),

    // 90. Lavakungen
    volcano("Lava king", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 28000, 40000], function (o) {
        heat(o, 12, 16, -2, 12, 8)
        o.push(basalt(18.5, 2.2, 2.6), troll(18.5, 2.6, "medium"))
        o.push(basalt(25, 7.4, 1.0))
        var y = floor(o, 24, 1.0, 2.8, 2.2, "obsidian", "stone")
        o.push(troll(24, 1.0, "lavaking"), troll(24, y, "small"))
        o.push(magma(22.0, 1.0), magma(26.1, 1.0))
        o.push(troll(27.6, 1.0, "small"))
    }),

    // ---- Djungeltemplet -----------------------------------------------------------

    // 91. In i djungeln: kapa lianen så faller stenen
    jungle("Into the jungle", ["spruce", "spruce", "spruce"], [0, 14000, 20000], function (o) {
        o.push(branch(23, 7.6, 7.4))
        var top = floor(o, 21, 0, 2.2, 1.8, "bamboo")
        o.push(troll(21, 0, "small"), troll(21, top, "small"))
        o.push(vined(tstone(21, 4.2, 1.0, 1.0), 7.6))
        o.push(troll(25, 0, "medium"))
        o.push(vined(tstone(25, 3.4, 1.0, 1.0), 7.6))
    }),

    // 92. Lianerna: plattformar av bambu som hänger i lianer
    jungle("Hanging vines", ["spruce", "pine", "spruce"], [0, 17000, 23000], function (o) {
        o.push(branch(23.3, 8.4, 9.4))
        o.push(vined(bamboo(20, 4.0, 1.6, 0.3), 8.4), troll(20, 4.3, "small"))
        o.push(vined(bamboo(23.5, 5.2, 1.8, 0.3), 8.4), troll(23.5, 5.5, "medium"))
        o.push(vined(bamboo(26.8, 3.2, 1.6, 0.3), 8.4), troll(26.8, 3.5, "small"))
        floor(o, 23.5, 0, 2.2, 1.8, "bamboo")
        o.push(troll(23.5, 0, "small"))
    }),

    // 93. Stenkulan: knuffa ned den från avsatsen så rullar den in under taket
    jungle("Rolling stone", ["spruce", "spruce", "pine"], [0, 9000, 13000], function (o) {
        o.push(temple(17.5, 0, 2.4, 3.0))
        o.push(stoneBall(17.7, 3.0, 0.6))
        o.push(ramp(18.4, 3.0, 23.4, -0.15))
        o.push(temple(28.0, 0, 0.5, 2.6), temple(26.0, 2.6, 4.5, 0.6))
        o.push(troll(24.3, 0, "small"))
        floor(o, 26.4, 0, 2.2, 1.8, "bamboo")
        o.push(troll(26.4, 0, "medium"))
    }),

    // 94. Hängbron: plankor som hänger mellan två pelare
    jungle("Rope bridge", ["spruce", "pine", "acorn", "spruce"], [0, 20000, 28000], function (o) {
        o.push(branch(23, 8.6, 9.6))
        o.push(temple(19, 0, 1.2, 3.6), temple(27, 0, 1.2, 3.6))
        for (var i = 0; i < 5; i++) o.push(vined(bamboo(20.3 + i * 1.35, 3.3, 1.3, 0.3), 8.6))
        o.push(troll(21.0, 3.6, "small"), troll(23.0, 3.6, "medium"), troll(25.0, 3.6, "small"))
        o.push(troll(19, 3.6, "small"), troll(27, 3.6, "small"))
    }),

    // 95. Pendeln: kapa lianen när kulan svänger mot tornet
    jungle("Swinging boulder", ["spruce", "pine", "spruce", "acorn"], [0, 16000, 23000], function (o) {
        swingBall(o, 19.5, 9.0, 5.5, 0.7, 0.6, 4, 0)
        var y = floor(o, 25.4, 0, 2.4, 2.0, "bamboo")
        o.push(troll(25.4, 0, "medium"))
        y = floor(o, 25.4, y, 2.0, 1.6, "bamboo")
        o.push(troll(25.4, y - 1.6 - T, "small"), troll(25.4, y, "small"))
    }),

    // 96. Bambulunden: spröda torn av bambu
    jungle("Bamboo grove", ["pine", "spruce", "pine"], [0, 25000, 36000], function (o) {
        var y = floor(o, 19.5, 0, 2.0, 2.4, "bamboo")
        o.push(troll(19.5, 0, "small"), troll(19.5, y, "small"))
        y = floor(o, 23, 0, 2.4, 2.0, "bamboo")
        o.push(troll(23, 0, "medium"))
        y = floor(o, 23, y, 2.0, 1.8, "bamboo")
        o.push(troll(23, y - 1.8 - T, "small"), idol(23, y))
        y = floor(o, 26.5, 0, 2.0, 2.4, "bamboo")
        o.push(troll(26.5, 0, "small"), troll(26.5, y, "small"))
        o.push(branch(23, 8.6, 3), vined(tstone(23, 6.2, 0.9, 0.9), 8.6))
    }),

    // 97. Tempeltrappan: kulan överst rullar ned på andra sidan
    jungle("Temple steps", ["spruce", "acorn", "pine", "spruce"], [0, 16000, 23000], function (o) {
        o.push(temple(23, 0, 9, 1), temple(23, 1, 6.6, 1), temple(23, 2, 4.2, 1), temple(23, 3, 1.8, 1))
        o.push(stoneBall(22.6, 4, 0.5), idol(23.5, 4))
        o.push(troll(19.1, 1, "small"))
        o.push(troll(24.5, 3, "small"), troll(25.7, 2, "medium"), troll(26.9, 1, "small"))
    }),

    // 98. Fällgången: stenar hänger i taket över trollen
    jungle("Trap corridor", ["acorn", "spruce", "pine", "chestnut"], [0, 14000, 20000], function (o) {
        o.push(temple(20.2, 0, 0.8, 2.0), temple(20.2, 4.6, 0.8, 1.6), temple(27.2, 0, 0.8, 6.2))
        o.push(temple(23.7, 6.2, 8.2, 0.8))
        o.push(vined(tstone(22, 3.6, 0.9, 0.9), 6.2), vined(tstone(24, 3.8, 0.9, 0.9), 6.2), vined(tstone(26, 3.6, 0.9, 0.9), 6.2))
        o.push(troll(22, 0, "small"), troll(24, 0, "medium"), troll(26, 0, "small"))
        o.push(troll(23.7, 7.0, "medium"))
    }),

    // 99. Guldidolen: altaret med en pendlande kula framför
    jungle("Golden idol", ["spruce", "pine", "acorn", "chestnut", "spruce"], [0, 21000, 30000], function (o) {
        swingBall(o, 19.0, 9.2, 5.2, 0.65, 0.55, 4, 0)
        o.push(temple(24.5, 0, 5.4, 1.2))
        var y = floor(o, 24.5, 1.2, 2.6, 2.0, "templestone", "bamboo")
        o.push(troll(24.5, 1.2, "large"))
        o.push(troll(24.0, y, "small"), idol(25.1, y))
        o.push(troll(26.5, 1.2, "medium"))
    }),

    // 100. Tempelväktaren: han sitter i en helgedom av sten. Bara stenkulan
    // (eller ett skott in genom öppningen) når honom.
    jungle("Temple guardian", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 30000, 42000], function (o) {
        o.push(temple(16.8, 0, 2.0, 4.4), stoneBall(17.0, 4.4, 0.6))
        o.push(ramp(17.7, 4.4, 22.1, 1.2))
        o.push(temple(25.2, 0, 6.0, 1.2))
        o.push(temple(27.9, 1.2, 0.6, 4.0), temple(25.6, 5.2, 5.2, 0.7))
        o.push(bamboo(23.15, 1.2, 0.25, 2.6))
        o.push(troll(24.0, 1.2, "small"), troll(25.9, 1.2, "guardian"))
        var y = floor(o, 25.6, 5.9, 2.4, 1.8, "bamboo")
        o.push(troll(25.6, 5.9, "medium"), troll(25.0, y, "small"), idol(26.2, y))
        o.push(troll(23.6, 5.9, "small"))
        o.push(branch(25.6, 10.6, 3), vined(tstone(25.6, 9.3, 0.9, 0.9), 10.6))
    }),

    // ---- Isfiskesjön ----------------------------------------------------------------

    // 101. Tunn is: isen spricker vid första knacket och brister vid nästa
    icelake("Thin ice", ["spruce", "spruce", "spruce"], [0, 14000, 19000], function (o) {
        iceSheet(o)
        o.push(troll(19.5, 0, "small"))
        var top = floor(o, 24, 0, 2.4, 1.8, "wood")
        o.push(troll(24, 0, "medium"), troll(24, top, "small"))
    }),

    // 102. Isvakarna: knuffa trollen i vakarna
    icelake("Fishing holes", ["spruce", "spruce", "pine"], [0, 11000, 16000], function (o) {
        iceSheet(o, [[18.8, 1.2], [23.5, 1.4], [27.8, 1.2]])
        o.push(troll(17.6, 0, "small"), troll(22.0, 0, "medium"), troll(26.4, 0, "small"))
        rod(o, 18.8); rod(o, 23.5); rod(o, 27.8)
    }),

    // 103. Halkan: en rad troll på blanka isen framför en stor vak
    icelake("Slide!", ["spruce", "acorn", "spruce"], [0, 14000, 20000], function (o) {
        iceSheet(o, [[20.6, 1.6], [26.6, 1.4]])
        o.push(troll(15.6, 0, "medium"), troll(17.2, 0, "small"), troll(18.6, 0, "small"))
        o.push(block(23.4, 0, 0.6, 1.6, "snow"))
        o.push(troll(24.8, 0, "medium"))
        rod(o, 20.6)
    }),

    // 104. Fiskeboden
    icelake("Fishing hut", ["spruce", "pine", "acorn", "spruce"], [0, 19000, 26000], function (o) {
        iceSheet(o, [[19.0, 1.2], [25.6, 1.3]])
        o.push(troll(17.8, 0, "small"))
        var top = floor(o, 22.3, 0, 3.0, 2.2, "wood")
        o.push(troll(21.75, 0, "medium"), troll(22.9, 0, "small"))
        o.push(block(22.3, top, 1.0, 0.6, "snow"), troll(22.3, top + 0.6, "small"))
        rod(o, 19.0); rod(o, 25.6)
    }),

    // 105. Tunga stenar: det som faller tungt bryter den tunna isen
    icelake("Heavy stones", ["spruce", "pine", "spruce"], [0, 16000, 23000], function (o) {
        iceSheet(o, [], 1)
        var y = floor(o, 19.5, 0, 2.2, 2.4, "wood")
        o.push(troll(19.5, 0, "small"), block(19.5, y, 1.0, 1.0, "stone"))
        o.push(troll(22.2, 0, "small"))
        y = floor(o, 25.4, 0, 2.4, 2.0, "wood")
        o.push(troll(25.4, 0, "medium"), block(25.4, y, 1.0, 1.0, "stone"))
    }),

    // 106. Skruvisen: vallar av uppskjuten is med vakar bakom
    icelake("Pressure ridge", ["spruce", "pine", "acorn", "spruce"], [0, 19000, 27000], function (o) {
        iceSheet(o, [[19.6, 1.2], [25.4, 1.3]])
        o.push(ridge(17, 1.6, 1.4), troll(17, 1.4, "small"))
        o.push(troll(18.4, 0, "small"))
        o.push(ridge(22, 1.6, 2.2), troll(22, 2.2, "small"))
        o.push(troll(23.9, 0, "medium"), troll(27.2, 0, "small"))
        rod(o, 19.6); rod(o, 25.4)
    }),

    // 107. Fiskelägret: två bodar med vakar emellan
    icelake("Ice camp", ["pine", "spruce", "acorn", "chestnut"], [0, 20000, 28000], function (o) {
        iceSheet(o, [[17.2, 1.2], [22.7, 1.3], [28.0, 1.2]])
        var y = floor(o, 19.9, 0, 2.4, 1.8, "wood")
        o.push(troll(19.9, 0, "small"), troll(19.9, y, "small"))
        y = floor(o, 25.4, 0, 2.6, 2.0, "wood", "snow")
        o.push(troll(25.4, 0, "medium"), troll(25.4, y, "small"))
        rod(o, 17.2); rod(o, 22.7); rod(o, 28.0)
    }),

    // 108. Sprickorna: all is har redan spruckit
    icelake("Cracks everywhere", ["spruce", "pine", "spruce", "acorn"], [0, 23000, 33000], function (o) {
        iceSheet(o, [], 1, true)
        o.push(troll(15.6, 0, "small"), troll(18.6, 0, "medium"), troll(21.6, 0, "small"))
        var y = floor(o, 24.6, 0, 2.2, 2.2, "ice")
        o.push(troll(24.6, 0, "medium"), troll(24.6, y, "small"))
        o.push(troll(27.6, 0, "small"))
    }),

    // 109. Den stora fångsten: en bro av plankor över en stor vak
    icelake("The big catch", ["spruce", "pine", "acorn", "chestnut", "spruce"], [0, 27000, 38000], function (o) {
        iceSheet(o, [[22.5, 2.6]])
        o.push(beam(22.5, 0, 4.2, "wood"))
        o.push(troll(21.4, T, "small"), troll(22.5, T, "medium"), troll(23.6, T, "small"))
        var y = floor(o, 18.4, 0, 2.0, 1.8, "wood")
        o.push(troll(18.4, 0, "small"))
        y = floor(o, 26.6, 0, 2.2, 1.8, "wood")
        o.push(troll(26.6, 0, "small"), troll(26.6, y, "medium"))
        rod(o, 22.5)
    }),

    // 110. Isfiskaren
    icelake("Ice fisher", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 28000, 40000], function (o) {
        iceSheet(o, [[19.2, 1.3], [26.2, 1.4]])
        o.push(ridge(16.5, 1.4, 1.6), troll(16.5, 1.6, "small"))
        o.push(block(20.8, 0, 0.6, 1.6, "snow"))
        var y = floor(o, 23.2, 0, 3.0, 2.4, "ice", "wood")
        o.push(troll(23.2, 0, "angler"))
        y = floor(o, 23.2, y, 2.2, 1.6, "snow")
        o.push(troll(23.2, y - 1.6 - T, "small"), troll(23.2, y, "small"))
        o.push(troll(28.0, 0, "medium"))
        rod(o, 19.2); rod(o, 26.2)
    })
]
