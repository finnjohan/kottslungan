// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Game.js" as Game
import "Levels.js" as Levels

Page {
    id: page
    // Ingen rubrikrad: spelet ska fylla hela skärmen
    header: Item { height: 0; visible: false }
    property int levelNumber: 1
    readonly property var level: Levels.list[levelNumber - 1]
    readonly property string ambience: level.world

    // Resultat
    property bool showResult: false
    property bool won: false
    property int finalScore: 0
    property int finalStars: 0
    property bool newBest: false
    property bool paused: false

    function restart() {
        showResult = false
        paused = false
        game.start()
    }

    GameView {
        id: game
        anchors.fill: parent
        levelNumber: page.levelNumber
        running: !page.paused && page.visible
        Component.onCompleted: start()
        onFinished: {
            page.won = won
            page.finalScore = score
            page.finalStars = won ? Game.stars(page.level, score) : 0
            page.newBest = won && score > root.bestFor(page.levelNumber)
            if (won) root.saveResult(page.levelNumber, page.finalStars, score)
            page.showResult = true
        }
    }

    // ---- Överst: tillbaka, bana, poäng, börja om ------------------------
    Row {
        id: headerRow
        anchors { left: parent.left; top: parent.top; margins: units.gu(1.5) }
        spacing: units.gu(1.5)
        RoundButton { iconName: "back"; onClicked: stack.pop() }
        Column {
            anchors.verticalCenter: parent.verticalCenter
            Label {
                text: root.tr("Level %1").arg(page.levelNumber) + " · " + root.tr(page.level.name)
                font.weight: Font.Bold
                color: "#FFFFFF"
                style: Text.Outline; styleColor: "#3A2A10"
            }
            Label {
                text: root.tr("Trolls left: %1").arg(game.trollsLeft)
                textSize: Label.Small
                color: "#FFFFFF"
                style: Text.Outline; styleColor: "#3A2A10"
            }
        }
    }
    Row {
        id: scoreRow
        anchors { right: parent.right; top: parent.top; margins: units.gu(1.5) }
        spacing: units.gu(1.5)
        Label {
            anchors.verticalCenter: parent.verticalCenter
            text: game.score
            font.pixelSize: units.gu(3.2)
            font.weight: Font.Bold
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
        RoundButton { iconName: "reload"; onClicked: page.restart() }
    }

    // Tips om kottens förmåga
    // (mellan rubriken och poängen, så att ett långt banans namn inte hamnar under tipset)
    Label {
        anchors { left: headerRow.right; right: scoreRow.left; top: parent.top; topMargin: units.gu(2)
                  leftMargin: units.gu(2); rightMargin: units.gu(2) }
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.WordWrap
        maximumLineCount: 2
        visible: game.state === "aim" && !page.showResult
        readonly property string ability: game.currentType !== "" ? Game.CONES[game.currentType].ability : "none"
        text: ability === "split" ? root.tr("Pine cone: tap in flight to split into three")
              : ability === "dash" ? root.tr("Acorn: tap in flight for a burst of speed")
              : ability === "burst" ? root.tr("Chestnut: tap in flight to burst")
              : page.levelNumber === 1 ? root.tr("Pull back the cone and let go")
              : page.levelNumber === 21 ? root.tr("Knock the pirates into the sea!")
              : page.levelNumber === 23 ? root.tr("Powder kegs explode when they break")
              : page.levelNumber === 31 ? root.tr("Hit what hangs from the ceiling to make it fall")
              : page.levelNumber === 33 ? root.tr("Crystals are bouncy")
              : page.levelNumber === 41 ? root.tr("Low gravity: the cones fly slow and far")
              : page.levelNumber === 42 ? root.tr("Bubble helmets take the first hard knock")
              : page.levelNumber === 43 ? root.tr("Floating rocks fall when you hit them")
              : page.levelNumber === 51 ? root.tr("Jelly is bouncy")
              : page.levelNumber === 53 ? root.tr("Marshmallows are soft: knock them away first")
              : page.levelNumber === 61 ? root.tr("Bounce cones off the trampolines")
              : page.levelNumber === 63 ? root.tr("The rides move: time your shot")
              : page.levelNumber === 71 ? root.tr("Knock the trolls off the clouds")
              : page.levelNumber === 72 ? root.tr("Pop the balloon and the platform falls")
              : page.levelNumber === 73 ? root.tr("Gusts of wind push the cone – watch the arrows")
              : page.levelNumber === 81 ? root.tr("Knock the trolls into the lava!")
              : page.levelNumber === 82 ? root.tr("Glowing rocks burst into sparks when they break")
              : page.levelNumber === 84 ? root.tr("Hot air over the lava lifts the cone")
              : page.levelNumber === 91 ? root.tr("Fly through a vine to cut it – whatever hangs from it falls")
              : page.levelNumber === 93 ? root.tr("Knock the stone ball off the ledge and let it roll")
              : page.levelNumber === 95 ? root.tr("Cut the vine when the boulder swings towards the trolls")
              : page.levelNumber === 101 ? root.tr("A hard knock cracks the ice – the next one breaks it")
              : page.levelNumber === 102 ? root.tr("The ice is slippery: knock the trolls into the holes")
              : page.levelNumber === 105 ? root.tr("Thin ice breaks at once when something heavy falls on it")
              : ""
        textSize: Label.Small
        color: "#FFFFFF"
        style: Text.Outline; styleColor: "#3A2A10"
    }

    // ---- Resultat -------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: page.showResult
        color: "#80000000"
        MouseArea { anchors.fill: parent }       // fånga klick

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width - units.gu(4), units.gu(48))
            height: resultCol.height + units.gu(5)
            radius: units.gu(2)
            color: theme.palette.normal.background
            border.color: theme.palette.normal.base

            Column {
                id: resultCol
                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: units.gu(2.5) }
                spacing: units.gu(1.5)
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: page.won ? root.tr("Level cleared!") : root.tr("Out of cones!")
                    textSize: Label.Large
                    font.weight: Font.Bold
                }
                Stars {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: page.won
                    count: page.finalStars
                    size: units.gu(5)
                }
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: page.won ? root.tr("Score: %1").arg(page.finalScore)
                                     + (page.newBest ? "  · " + root.tr("New best!") : "")
                                   : root.tr("The trolls are still there. Try a different angle!")
                    wrapMode: Text.WordWrap
                    width: Math.min(implicitWidth, parent.width)
                    horizontalAlignment: Text.AlignHCenter
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: units.gu(1.5)
                    Button {
                        text: root.tr("Levels")
                        onClicked: stack.pop()
                    }
                    Button {
                        text: root.tr("Play again")
                        onClicked: page.restart()
                    }
                    Button {
                        visible: page.won && page.levelNumber < root.levelCount
                        text: root.tr("Next")
                        color: theme.palette.normal.positive
                        onClicked: { page.levelNumber++; page.restart() }
                    }
                }
            }
        }
    }
}
