// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

Page {
    id: page
    // Ingen rubrikrad: spelet ska fylla hela skärmen
    header: Item { height: 0; visible: false }

    Scenery {
        id: scene
        anchors.fill: parent
        groundY: height * 0.84
        night: root.isDark
    }
    Image {
        source: "../assets/squirrel.svg"
        height: parent.height * 0.42; width: height * 200 / 220
        x: parent.width * 0.08; y: scene.groundY - height + 2
        sourceSize: Qt.size(Math.ceil(width * 1.5), Math.ceil(height * 1.5))
    }
    Image {
        source: "../assets/troll-medium.svg"
        height: parent.height * 0.17; width: height
        x: parent.width * 0.8; y: scene.groundY - height + 2
        sourceSize: Qt.size(Math.ceil(width * 1.5), Math.ceil(width * 1.5))
    }
    Image {
        source: "../assets/troll-small.svg"
        height: parent.height * 0.12; width: height
        x: parent.width * 0.71; y: scene.groundY - height + 2
        sourceSize: Qt.size(Math.ceil(width * 1.5), Math.ceil(width * 1.5))
    }
    Image {
        source: "../assets/cone-spruce.svg"
        height: parent.height * 0.09; width: height
        x: parent.width * 0.27; y: parent.height * 0.5
        rotation: 50
        sourceSize: Qt.size(Math.ceil(width * 1.5), Math.ceil(width * 1.5))
    }

    Column {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: parent.height * 0.12 }
        spacing: units.gu(2)
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "Kottslungan"
            font.pixelSize: page.height * 0.14
            font.weight: Font.Bold
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#2E5A2A"
        }
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.tr("Fling cones at the forest trolls")
            textSize: Label.Large
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#2E5A2A"
        }
        Item { width: 1; height: units.gu(1) }
        Button {
            anchors.horizontalCenter: parent.horizontalCenter
            width: units.gu(22); height: units.gu(6)
            text: root.tr("Play")
            font.weight: Font.Bold
            color: "#E8862A"
            onClicked: stack.push(Qt.resolvedUrl("LevelsPage.qml"))
        }
        Row {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: units.gu(1)
            Icon { name: "starred"; color: "#F2B705"; width: units.gu(2.4); height: width
                   anchors.verticalCenter: parent.verticalCenter; visible: root.totalStars() > 0 }
            Label {
                visible: root.totalStars() > 0
                anchors.verticalCenter: parent.verticalCenter
                text: root.totalStars() + " / " + root.levelCount * 3
                color: "#FFFFFF"; style: Text.Outline; styleColor: "#2E5A2A"
                font.weight: Font.Bold
            }
        }
    }

    RoundButton {
        anchors { right: parent.right; top: parent.top; margins: units.gu(1.5) }
        iconName: "settings"
        onClicked: stack.push(Qt.resolvedUrl("SettingsPage.qml"))
    }
}
