// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

Row {
    id: stars
    property int count: 0
    property real size: units.gu(2)
    spacing: size * 0.15
    Repeater {
        model: 3
        Icon {
            width: stars.size; height: width
            name: index < stars.count ? "starred" : "non-starred"
            color: index < stars.count ? "#F2B705" : "#9A9A9A"
        }
    }
}
