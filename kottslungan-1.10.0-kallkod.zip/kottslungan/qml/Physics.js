.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// En liten fysikmotor för stela kroppar (lådor och cirklar) i 2D.
// Upplägget följer Erin Cattos Box2D-Lite (zlib-licens): kontaktpunkter med
// klippning mellan lådor, ackumulerade impulser och "warm starting", vilket
// gör att torn av stockar står stadigt. Koden är nyskriven i JavaScript.
// Enheter: meter, sekunder, kilogram. y pekar uppåt.

var GRAVITY = -10
var ITERATIONS = 12
var ALLOWED_PENETRATION = 0.01
var BIAS_FACTOR = 0.2
var LINEAR_DAMPING = 0.02
var ANGULAR_DAMPING = 0.08

// ---- Vektorhjälp (små objekt, inga klasser) -------------------------------

function dot(ax, ay, bx, by) { return ax * bx + ay * by }
function cross(ax, ay, bx, by) { return ax * by - ay * bx }

// ---- Kroppar ---------------------------------------------------------------

var _nextId = 1

// opts: { shape: "box"|"circle", x, y, w, h | r, angle, density, friction,
//         restitution, isStatic, kind, data }
function makeBody(opts) {
    var b = {
        id: _nextId++,
        shape: opts.shape || "box",
        x: opts.x, y: opts.y, angle: opts.angle || 0,
        vx: opts.vx || 0, vy: opts.vy || 0, w: 0, av: opts.av || 0,
        fx: 0, fy: 0, torque: 0,
        hw: (opts.w || 1) / 2, hh: (opts.h || 1) / 2, r: opts.r || 0.5,
        friction: opts.friction !== undefined ? opts.friction : 0.6,
        restitution: opts.restitution || 0,
        angularDamping: opts.angularDamping !== undefined ? opts.angularDamping : ANGULAR_DAMPING,
        mass: 0, invMass: 0, I: 0, invI: 0,
        kind: opts.kind || "", data: opts.data || {},
        alive: true
    }
    var density = opts.density || 1
    if (!opts.isStatic) {
        if (b.shape === "circle") {
            b.mass = density * Math.PI * b.r * b.r
            b.I = 0.5 * b.mass * b.r * b.r
        } else {
            var w = 2 * b.hw, h = 2 * b.hh
            b.mass = density * w * h
            b.I = b.mass * (w * w + h * h) / 12
        }
        b.invMass = 1 / b.mass
        b.invI = 1 / b.I
    }
    return b
}

function aabb(b) {
    if (b.shape === "circle") return [b.x - b.r, b.y - b.r, b.x + b.r, b.y + b.r]
    var c = Math.abs(Math.cos(b.angle)), s = Math.abs(Math.sin(b.angle))
    var ex = c * b.hw + s * b.hh, ey = s * b.hw + c * b.hh
    return [b.x - ex, b.y - ey, b.x + ex, b.y + ey]
}

// ---- Kollisioner -----------------------------------------------------------
// Varje funktion ger en lista med kontakter { x, y, nx, ny, sep, key },
// där normalen pekar från a till b.

function _incidentEdge(hx, hy, px, py, c, s, nx, ny) {
    // Normalen i den infallande lådans lokala koordinater, omvänd
    var lx = -(c * nx + s * ny), ly = -(-s * nx + c * ny)
    var v0, v1, k0, k1
    if (Math.abs(lx) > Math.abs(ly)) {
        if (lx > 0) { v0 = [hx, -hy]; k0 = 34; v1 = [hx, hy]; k1 = 41 }
        else { v0 = [-hx, hy]; k0 = 12; v1 = [-hx, -hy]; k1 = 23 }
    } else {
        if (ly > 0) { v0 = [hx, hy]; k0 = 41; v1 = [-hx, hy]; k1 = 12 }
        else { v0 = [-hx, -hy]; k0 = 23; v1 = [hx, -hy]; k1 = 34 }
    }
    return [
        { x: px + c * v0[0] - s * v0[1], y: py + s * v0[0] + c * v0[1], key: k0 },
        { x: px + c * v1[0] - s * v1[1], y: py + s * v1[0] + c * v1[1], key: k1 }
    ]
}

function _clip(pts, nx, ny, offset, edge) {
    var out = []
    var d0 = dot(nx, ny, pts[0].x, pts[0].y) - offset
    var d1 = dot(nx, ny, pts[1].x, pts[1].y) - offset
    if (d0 <= 0) out.push(pts[0])
    if (d1 <= 0) out.push(pts[1])
    if (d0 * d1 < 0) {
        var t = d0 / (d0 - d1)
        out.push({ x: pts[0].x + t * (pts[1].x - pts[0].x), y: pts[0].y + t * (pts[1].y - pts[0].y),
                   key: (d0 > 0 ? pts[0].key : pts[1].key) * 10 + edge })
    }
    return out
}

function collideBoxes(a, b) {
    var ca = Math.cos(a.angle), sa = Math.sin(a.angle)
    var cb = Math.cos(b.angle), sb = Math.sin(b.angle)
    var dx = b.x - a.x, dy = b.y - a.y
    // dp i a:s och b:s lokala system
    var dax = ca * dx + sa * dy, day = -sa * dx + ca * dy
    var dbx = cb * dx + sb * dy, dby = -sb * dx + cb * dy
    // C = RotA^T * RotB
    var c11 = ca * cb + sa * sb, c12 = -ca * sb + sa * cb
    var c21 = -sa * cb + ca * sb, c22 = sa * sb + ca * cb
    var a11 = Math.abs(c11), a12 = Math.abs(c12), a21 = Math.abs(c21), a22 = Math.abs(c22)

    var faceAx = Math.abs(dax) - a.hw - (a11 * b.hw + a12 * b.hh)
    var faceAy = Math.abs(day) - a.hh - (a21 * b.hw + a22 * b.hh)
    if (faceAx > 0 || faceAy > 0) return []
    var faceBx = Math.abs(dbx) - (a11 * a.hw + a21 * a.hh) - b.hw
    var faceBy = Math.abs(dby) - (a12 * a.hw + a22 * a.hh) - b.hh
    if (faceBx > 0 || faceBy > 0) return []

    var relTol = 0.95, absTol = 0.01
    var axis = 0, sep = faceAx
    var nx = dax > 0 ? ca : -ca, ny = dax > 0 ? sa : -sa
    if (faceAy > relTol * sep + absTol * a.hh) { axis = 1; sep = faceAy; nx = day > 0 ? -sa : sa; ny = day > 0 ? ca : -ca }
    if (faceBx > relTol * sep + absTol * b.hw) { axis = 2; sep = faceBx; nx = dbx > 0 ? cb : -cb; ny = dbx > 0 ? sb : -sb }
    if (faceBy > relTol * sep + absTol * b.hh) { axis = 3; sep = faceBy; nx = dby > 0 ? -sb : sb; ny = dby > 0 ? cb : -cb }

    var fnx, fny, front, snx, sny, side, negSide, posSide, inc
    if (axis === 0) {
        fnx = nx; fny = ny; front = dot(a.x, a.y, fnx, fny) + a.hw
        snx = -sa; sny = ca; side = dot(a.x, a.y, snx, sny)
        negSide = -side + a.hh; posSide = side + a.hh
        inc = _incidentEdge(b.hw, b.hh, b.x, b.y, cb, sb, fnx, fny)
    } else if (axis === 1) {
        fnx = nx; fny = ny; front = dot(a.x, a.y, fnx, fny) + a.hh
        snx = ca; sny = sa; side = dot(a.x, a.y, snx, sny)
        negSide = -side + a.hw; posSide = side + a.hw
        inc = _incidentEdge(b.hw, b.hh, b.x, b.y, cb, sb, fnx, fny)
    } else if (axis === 2) {
        fnx = -nx; fny = -ny; front = dot(b.x, b.y, fnx, fny) + b.hw
        snx = -sb; sny = cb; side = dot(b.x, b.y, snx, sny)
        negSide = -side + b.hh; posSide = side + b.hh
        inc = _incidentEdge(a.hw, a.hh, a.x, a.y, ca, sa, fnx, fny)
    } else {
        fnx = -nx; fny = -ny; front = dot(b.x, b.y, fnx, fny) + b.hh
        snx = cb; sny = sb; side = dot(b.x, b.y, snx, sny)
        negSide = -side + b.hw; posSide = side + b.hw
        inc = _incidentEdge(a.hw, a.hh, a.x, a.y, ca, sa, fnx, fny)
    }
    var p1 = _clip(inc, -snx, -sny, negSide, 1)
    if (p1.length < 2) return []
    var p2 = _clip(p1, snx, sny, posSide, 3)
    if (p2.length < 2) return []
    var out = []
    for (var i = 0; i < 2; i++) {
        var s = dot(fnx, fny, p2[i].x, p2[i].y) - front
        if (s <= 0) out.push({ x: p2[i].x - s * fnx, y: p2[i].y - s * fny, nx: nx, ny: ny, sep: s,
                               key: axis * 100000 + p2[i].key })
    }
    return out
}

function collideCircleBox(c, b, flip) {
    var cs = Math.cos(b.angle), sn = Math.sin(b.angle)
    var dx = c.x - b.x, dy = c.y - b.y
    var lx = cs * dx + sn * dy, ly = -sn * dx + cs * dy
    var qx = Math.max(-b.hw, Math.min(b.hw, lx)), qy = Math.max(-b.hh, Math.min(b.hh, ly))
    var nlx, nly, dist, inside = (qx === lx && qy === ly)
    if (inside) {
        // Mitten är inne i lådan: skjut ut genom närmaste sida
        var ex = b.hw - Math.abs(lx), ey = b.hh - Math.abs(ly)
        if (ex < ey) { nlx = lx > 0 ? 1 : -1; nly = 0; qx = nlx * b.hw; dist = -ex }
        else { nlx = 0; nly = ly > 0 ? 1 : -1; qy = nly * b.hh; dist = -ey }
    } else {
        var ddx = lx - qx, ddy = ly - qy
        dist = Math.sqrt(ddx * ddx + ddy * ddy)
        if (dist > c.r) return []
        nlx = ddx / dist; nly = ddy / dist
    }
    var sep = dist - c.r
    if (sep > 0) return []
    // Normal från lådan mot cirkeln, i världskoordinater
    var nx = cs * nlx - sn * nly, ny = sn * nlx + cs * nly
    var px = b.x + cs * qx - sn * qy, py = b.y + sn * qx + cs * qy
    if (flip) return [{ x: px, y: py, nx: -nx, ny: -ny, sep: sep, key: 7 }]   // a = cirkel
    return [{ x: px, y: py, nx: nx, ny: ny, sep: sep, key: 7 }]
}

function collideCircles(a, b) {
    var dx = b.x - a.x, dy = b.y - a.y
    var d = Math.sqrt(dx * dx + dy * dy)
    var sep = d - a.r - b.r
    if (sep > 0) return []
    var nx = d > 1e-9 ? dx / d : 0, ny = d > 1e-9 ? dy / d : 1
    return [{ x: a.x + nx * (a.r + sep / 2), y: a.y + ny * (a.r + sep / 2), nx: nx, ny: ny, sep: sep, key: 9 }]
}

function collide(a, b) {
    if (a.shape === "box" && b.shape === "box") return collideBoxes(a, b)
    if (a.shape === "circle" && b.shape === "circle") return collideCircles(a, b)
    if (a.shape === "circle") return collideCircleBox(a, b, true)
    return collideCircleBox(b, a, false)
}

// ---- Värld -----------------------------------------------------------------

function makeWorld() {
    return { bodies: [], arbiters: {}, time: 0 }
}

function addBody(world, b) { world.bodies.push(b); return b }

function removeBody(world, b) {
    b.alive = false
    var i = world.bodies.indexOf(b)
    if (i >= 0) world.bodies.splice(i, 1)
    for (var k in world.arbiters)
        if (world.arbiters[k].a === b || world.arbiters[k].b === b) delete world.arbiters[k]
}

function _broadPhase(world) {
    var bodies = world.bodies, n = bodies.length, boxes = []
    for (var i = 0; i < n; i++) boxes.push(aabb(bodies[i]))
    var seen = {}
    for (i = 0; i < n; i++) {
        var a = bodies[i], ba = boxes[i]
        for (var j = i + 1; j < n; j++) {
            var b = bodies[j]
            if (a.invMass === 0 && b.invMass === 0) continue
            var bb = boxes[j]
            if (ba[2] < bb[0] || bb[2] < ba[0] || ba[3] < bb[1] || bb[3] < ba[1]) continue
            var first = a.id < b.id ? a : b, second = a.id < b.id ? b : a
            var key = first.id + ":" + second.id
            var contacts = collide(first, second)
            if (contacts.length === 0) continue
            seen[key] = true
            var old = world.arbiters[key]
            if (old) {
                // Behåll gamla impulser för kontakter som finns kvar (warm starting)
                for (var c = 0; c < contacts.length; c++) {
                    var nc = contacts[c]
                    nc.pn = 0; nc.pt = 0
                    for (var o = 0; o < old.contacts.length; o++)
                        if (old.contacts[o].key === nc.key) { nc.pn = old.contacts[o].pn; nc.pt = old.contacts[o].pt; break }
                }
                old.contacts = contacts
            } else {
                for (c = 0; c < contacts.length; c++) { contacts[c].pn = 0; contacts[c].pt = 0 }
                world.arbiters[key] = { a: first, b: second, contacts: contacts,
                                        friction: Math.sqrt(first.friction * second.friction),
                                        restitution: Math.max(first.restitution, second.restitution) }
            }
        }
    }
    for (var k in world.arbiters) if (!seen[k]) delete world.arbiters[k]
}

function _preStep(arb, invDt) {
    var a = arb.a, b = arb.b
    for (var i = 0; i < arb.contacts.length; i++) {
        var c = arb.contacts[i]
        var r1x = c.x - a.x, r1y = c.y - a.y, r2x = c.x - b.x, r2y = c.y - b.y
        var rn1 = dot(r1x, r1y, c.nx, c.ny), rn2 = dot(r2x, r2y, c.nx, c.ny)
        var kn = a.invMass + b.invMass + a.invI * (dot(r1x, r1y, r1x, r1y) - rn1 * rn1)
                 + b.invI * (dot(r2x, r2y, r2x, r2y) - rn2 * rn2)
        c.massN = 1 / kn
        var tx = c.ny, ty = -c.nx
        var rt1 = dot(r1x, r1y, tx, ty), rt2 = dot(r2x, r2y, tx, ty)
        var kt = a.invMass + b.invMass + a.invI * (dot(r1x, r1y, r1x, r1y) - rt1 * rt1)
                 + b.invI * (dot(r2x, r2y, r2x, r2y) - rt2 * rt2)
        c.massT = 1 / kt
        c.bias = -BIAS_FACTOR * invDt * Math.min(0, c.sep + ALLOWED_PENETRATION)
        // Studs bara vid riktiga smällar
        if (arb.restitution > 0) {
            var vn0 = dot(b.vx - b.w * r2y - a.vx + a.w * r1y, b.vy + b.w * r2x - a.vy - a.w * r1x, c.nx, c.ny)
            if (vn0 < -2) c.bias = Math.max(c.bias, -arb.restitution * vn0)
        }
        c.r1x = r1x; c.r1y = r1y; c.r2x = r2x; c.r2y = r2y; c.tx = tx; c.ty = ty
        c.impact = 0
        // Warm starting
        var px = c.pn * c.nx + c.pt * tx, py = c.pn * c.ny + c.pt * ty
        a.vx -= a.invMass * px; a.vy -= a.invMass * py; a.w -= a.invI * cross(r1x, r1y, px, py)
        b.vx += b.invMass * px; b.vy += b.invMass * py; b.w += b.invI * cross(r2x, r2y, px, py)
    }
}

function _applyImpulse(arb) {
    var a = arb.a, b = arb.b
    for (var i = 0; i < arb.contacts.length; i++) {
        var c = arb.contacts[i]
        var dvx = b.vx - b.w * c.r2y - a.vx + a.w * c.r1y
        var dvy = b.vy + b.w * c.r2x - a.vy - a.w * c.r1x
        var vn = dot(dvx, dvy, c.nx, c.ny)
        var dPn = c.massN * (-vn + c.bias)
        var pn0 = c.pn
        c.pn = Math.max(pn0 + dPn, 0)
        dPn = c.pn - pn0
        c.impact += dPn
        var px = dPn * c.nx, py = dPn * c.ny
        a.vx -= a.invMass * px; a.vy -= a.invMass * py; a.w -= a.invI * cross(c.r1x, c.r1y, px, py)
        b.vx += b.invMass * px; b.vy += b.invMass * py; b.w += b.invI * cross(c.r2x, c.r2y, px, py)

        dvx = b.vx - b.w * c.r2y - a.vx + a.w * c.r1y
        dvy = b.vy + b.w * c.r2x - a.vy - a.w * c.r1x
        var vt = dot(dvx, dvy, c.tx, c.ty)
        var dPt = c.massT * (-vt)
        var maxPt = arb.friction * c.pn
        var pt0 = c.pt
        c.pt = Math.max(-maxPt, Math.min(maxPt, pt0 + dPt))
        dPt = c.pt - pt0
        px = dPt * c.tx; py = dPt * c.ty
        a.vx -= a.invMass * px; a.vy -= a.invMass * py; a.w -= a.invI * cross(c.r1x, c.r1y, px, py)
        b.vx += b.invMass * px; b.vy += b.invMass * py; b.w += b.invI * cross(c.r2x, c.r2y, px, py)
    }
}

// Ett tidssteg. Returnerar stötarna: [{ a, b, impulse, x, y }] där impulse
// är den nya impulsen i normalens riktning under steget (minus vilokraften).
function step(world, dt) {
    var invDt = dt > 0 ? 1 / dt : 0
    _broadPhase(world)
    var bodies = world.bodies, i
    for (i = 0; i < bodies.length; i++) {
        var b = bodies[i]
        if (b.invMass === 0) continue
        b.vx += dt * (b.invMass * b.fx)
        b.vy += dt * ((world.gravity !== undefined ? world.gravity : GRAVITY) + b.invMass * b.fy)
        b.w += dt * b.invI * b.torque
        var ld = 1 / (1 + dt * LINEAR_DAMPING), ad = 1 / (1 + dt * b.angularDamping)
        b.vx *= ld; b.vy *= ld; b.w *= ad
    }
    var arbs = []
    for (var k in world.arbiters) arbs.push(world.arbiters[k])
    for (i = 0; i < arbs.length; i++) _preStep(arbs[i], invDt)
    for (var it = 0; it < ITERATIONS; it++)
        for (i = 0; i < arbs.length; i++) _applyImpulse(arbs[i])
    for (i = 0; i < bodies.length; i++) {
        b = bodies[i]
        b.x += dt * b.vx; b.y += dt * b.vy; b.angle += dt * b.w
        b.fx = 0; b.fy = 0; b.torque = 0
    }
    world.time += dt
    // Stötar: hur mycket hårdare kontakten tog i än vad vila kräver
    var hits = []
    for (i = 0; i < arbs.length; i++) {
        var arb = arbs[i], total = 0, hx = 0, hy = 0
        for (var c = 0; c < arb.contacts.length; c++) {
            var cc = arb.contacts[c]
            total += cc.impact
            hx = cc.x; hy = cc.y
        }
        if (total > 0) hits.push({ a: arb.a, b: arb.b, impulse: total, x: hx, y: hy })
    }
    return hits
}

// Skjuter kroppar bort från en punkt (sprängkotten).
function explode(world, x, y, radius, strength) {
    var hit = []
    for (var i = 0; i < world.bodies.length; i++) {
        var b = world.bodies[i]
        if (b.invMass === 0) continue
        var dx = b.x - x, dy = b.y - y, d = Math.sqrt(dx * dx + dy * dy)
        if (d > radius) continue
        var f = strength * (1 - d / radius)
        var ux = d > 1e-6 ? dx / d : 0, uy = d > 1e-6 ? dy / d : 1
        b.vx += ux * f * b.invMass
        b.vy += uy * f * b.invMass
        b.w += (Math.random() - 0.5) * f * b.invI * 0.2
        hit.push({ body: b, power: f })
    }
    return hit
}

function speed(b) { return Math.sqrt(b.vx * b.vx + b.vy * b.vy) }

// Är allt i stort sett stilla?
function isSettled(world, limit) {
    for (var i = 0; i < world.bodies.length; i++) {
        var b = world.bodies[i]
        if (b.invMass === 0) continue
        if (speed(b) > limit || Math.abs(b.w) > limit * 2) return false
    }
    return true
}
