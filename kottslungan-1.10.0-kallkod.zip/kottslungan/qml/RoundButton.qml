// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

// Rund knapp med ikon, för spelvyn.
AbstractButton {
    id: btn
    property string iconName: ""
    width: units.gu(5); height: width
    Rectangle {
        anchors.fill: parent
        radius: width / 2
        color: btn.pressed ? "#C0FFFFFF" : "#90FFFFFF"
        border.color: "#605A3A1A"; border.width: units.dp(1)
    }
    Icon {
        anchors.centerIn: parent
        width: parent.width * 0.5; height: width
        name: btn.iconName
        color: "#3A2A10"
    }
}
