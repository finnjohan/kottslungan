.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
.import QtQuick.LocalStorage 2.0 as Sql

var _db = null
var _name = "kottslungan"

function useDatabase(name) { _name = name; _db = null }

function db() {
    if (_db) return _db
    _db = Sql.LocalStorage.openDatabaseSync(_name, "1.0", "Kottslungan", 1000000)
    _db.transaction(function (tx) {
        tx.executeSql("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        tx.executeSql("CREATE TABLE IF NOT EXISTS progress (level INTEGER PRIMARY KEY, stars INTEGER NOT NULL, best INTEGER NOT NULL)")
    })
    return _db
}

function setting(key, fallback) {
    var v = fallback
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT value FROM settings WHERE key = ?", [key])
        if (rs.rows.length > 0 && rs.rows.item(0).value !== null) v = rs.rows.item(0).value
    })
    return v
}

function setSetting(key, value) {
    db().transaction(function (tx) {
        tx.executeSql("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, String(value)])
    })
}

// { nivå: { stars, best } }
function progress() {
    var out = {}
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT * FROM progress")
        for (var i = 0; i < rs.rows.length; i++) {
            var r = rs.rows.item(i)
            out[r.level] = { stars: r.stars, best: r.best }
        }
    })
    return out
}

// Sparar bara om det blev bättre än tidigare.
function saveResult(level, stars, score) {
    db().transaction(function (tx) {
        var rs = tx.executeSql("SELECT stars, best FROM progress WHERE level = ?", [level])
        var s = stars, b = score
        if (rs.rows.length > 0) { s = Math.max(s, rs.rows.item(0).stars); b = Math.max(b, rs.rows.item(0).best) }
        tx.executeSql("INSERT OR REPLACE INTO progress (level, stars, best) VALUES (?, ?, ?)", [level, s, b])
    })
}

function resetProgress() {
    db().transaction(function (tx) { tx.executeSql("DELETE FROM progress") })
}
