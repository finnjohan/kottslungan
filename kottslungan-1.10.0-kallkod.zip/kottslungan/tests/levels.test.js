// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Kör: node tests/levels.test.js [banor...]
// 1) Varje bana ska stå still av sig själv (ingen skada, inga troll som dör).
// 2) Varje bana ska gå att klara: en enkel "spelare" provar många sikten
//    och väljer det bästa skottet för varje kotte.
const load = require("./load.js")
const ctx = load(["Physics.js", "Game.js", "Levels.js"])
// Game.js importerar Physics som P
ctx.P = ctx
const L = ctx.list
const only = process.argv.slice(2).map(Number)
let fail = 0

function clone(level) { return JSON.parse(JSON.stringify(level)) }
function run(g, sec) { for (let i = 0; i < sec * 60 && g.state !== "won" && g.state !== "lost"; i++) ctx.update(g, 1 / 60) }

// Spelar upp en lista med skott [{dx,dy,abilityAt}] från början.
function play(level, shots) {
    const g = ctx.newGame(clone(level))
    run(g, 1.5)
    for (const s of shots) {
        if (g.state !== "aim") break
        ctx.aim(g, s.dx, s.dy); ctx.launch(g)
        let t = 0
        while (g.state === "flying" && t < 10) {
            ctx.update(g, 1 / 60); t += 1 / 60
            if (s.abilityAt !== undefined && t >= s.abilityAt) ctx.useAbility(g)
        }
        let w = 0
        while (g.state === "waiting" && w < 8) { ctx.update(g, 1 / 60); w += 1 / 60 }
    }
    return g
}

L.forEach((level, idx) => {
    if (only.length && !only.includes(idx + 1)) return
    // 1. Står still
    const g0 = ctx.newGame(clone(level))
    const trolls0 = g0.trolls
    const start = g0.world.bodies.map(b => [b.x, b.y])
    run(g0, 8)
    const drift = Math.max(...g0.world.bodies.map((b, i) => Math.hypot(b.x - start[i][0], b.y - start[i][1])))
    // Tivolit: trollen i vagnar och gondoler gungar lite (de rullar fram och tillbaka
    // när vagnen bromsar), men allt är tillbaka efter 8 s eftersom perioderna delar 8 s.
    const stable = g0.trolls === trolls0 && g0.score === 0 && drift < (level.world === "fair" ? 0.35 : 0.1)
    if (!stable) fail++
    // 2. Går att klara (girig sökning)
    const shots = []
    const angles = [], pulls = [1.4, 1.7, 2.0, 2.2]
    for (let a = 5; a <= 70; a += 2.5) angles.push(a)
    let best = null
    for (let k = 0; k < level.cones.length; k++) {
        const type = level.cones[k]
        const abil = ctx.CONES[type].ability
        best = null
        for (const a of angles) for (const p of pulls) for (const ab of (abil === "none" ? [undefined] : level.world === "moon" ? [undefined, 1.0, 1.6, 2.2] : [undefined, 0.6, 0.9, 1.2])) {
            const r = a * Math.PI / 180
            const cand = shots.concat([{ dx: -Math.cos(r) * p, dy: -Math.sin(r) * p, abilityAt: ab }])
            const g = play(level, cand)
            const val = (trolls0 - g.trolls) * 100000 + g.score
            if (!best || val > best.val) best = { val, shot: cand[cand.length - 1], g }
        }
        shots.push(best.shot)
        if (best.g.state === "won") break
    }
    const g = best.g
    const won = g.state === "won"
    if (!won) fail++
    const st = won ? ctx.stars(level, g.score) : 0
    console.log(`${idx + 1}. ${level.name.padEnd(14)} stilla: ${stable ? "ja" : "NEJ (drift " + drift.toFixed(2) + ")"}` +
        `  klarad: ${won ? "ja" : "NEJ"} med ${shots.length}/${level.cones.length} kottar, poäng ${g.score}, stjärnor ${st}, troll kvar ${g.trolls}`)
})
console.log(fail ? `${fail} fel` : "alla banor ok")
process.exit(fail ? 1 : 0)
