#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Skapar spelets alla ljud från grunden med numpy (inga inspelningar, inga
# lånade ljud). Kör: python3 tools/make_sounds.py  (kräver numpy, scipy, oggenc)
# Bakgrundsljuden blir .ogg och loopar sömlöst; effekterna blir korta .wav.
import os, subprocess, wave
import numpy as np
from scipy.signal import butter, sosfilt

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "sounds")
rng = np.random.default_rng(2026)


def t_of(sec):
    return np.arange(int(sec * SR)) / SR


def periodic_noise(n, lo, hi, tilt=0.0):
    """Brus med frekvenser mellan lo och hi Hz. Skapas i frekvensplanet, så
    det är periodiskt och loopar utan skarv."""
    f = np.fft.rfftfreq(n, 1 / SR)
    # Mjuka kanter (logistiska) så att det inte låter som radiobrus
    w = 1 / (1 + np.exp(-(np.log2(np.maximum(f, 1)) - np.log2(lo)) * 6)) * 1 / (1 + np.exp((np.log2(np.maximum(f, 1)) - np.log2(hi)) * 6))
    spec = (rng.normal(size=len(f)) + 1j * rng.normal(size=len(f))) * w / np.maximum(f, 1) ** tilt
    spec[0] = 0
    x = np.fft.irfft(spec, n)
    return x / np.max(np.abs(x))


def slow_lfo(n, cycles, phase=0.0):
    # Ett helt antal svängningar per loop, så att loopen går ihop
    return 0.5 + 0.5 * np.sin(2 * np.pi * cycles * np.arange(n) / n + phase)


def env(n, attack, release):
    a = max(1, int(attack * SR)); r = max(1, int(release * SR))
    e = np.ones(n)
    e[:a] = np.linspace(0, 1, a)
    e[-r:] *= np.linspace(1, 0, r) ** 2
    return e


def chirp(f0, f1, sec, harm=(1.0, 0.25)):
    t = t_of(sec)
    f = np.geomspace(f0, f1, len(t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = sum(a * np.sin((i + 1) * ph) for i, a in enumerate(harm))
    return y * np.sin(np.pi * t / sec) ** 2


def place(buf, clip, at):
    """Lägger in ett ljud i en loop; det som går över slutet börjar om i början."""
    n = len(buf); i = int(at * SR) % n
    for k in range(0, len(clip)):
        buf[(i + k) % n] += clip[k]


def bird_song(kind):
    if kind == 0:   # tvåtonsvissling, som en talgoxe
        parts = []
        for _ in range(3):
            parts += [chirp(4200, 4000, 0.11), np.zeros(int(0.05 * SR)), chirp(3100, 3000, 0.13), np.zeros(int(0.07 * SR))]
        return np.concatenate(parts)
    if kind == 1:   # snabb drill
        return np.concatenate([np.concatenate([chirp(5200, 3800, 0.035), np.zeros(int(0.018 * SR))]) for _ in range(14)])
    # mjuk fallande ton
    return np.concatenate([chirp(2600, 1900, 0.35, (1, 0.4, 0.1)), np.zeros(int(0.12 * SR)), chirp(2500, 1800, 0.3, (1, 0.4, 0.1))])


def ambience_forest(sec=40):
    n = int(sec * SR)
    wind = periodic_noise(n, 80, 900, tilt=0.8) * (0.25 + 0.35 * slow_lfo(n, 3) * slow_lfo(n, 5, 1.0))
    leaves = periodic_noise(n, 1500, 4500, tilt=0.6) * 0.015 * slow_lfo(n, 4, 2.0)
    birds = np.zeros(n)
    t = 1.5
    while t < sec:
        kind = int(rng.integers(0, 3))
        song = bird_song(kind) * rng.uniform(0.12, 0.25)
        place(birds, song, t)
        t += rng.uniform(2.5, 6.0)
    return 0.55 * wind + leaves + birds


def ambience_winter(sec=40):
    n = int(sec * SR)
    # Vinden viner: två band som sakta glider upp och ned
    out = np.zeros(n)
    for lo, hi, cyc, amp in [(150, 500, 2, 0.5), (500, 1300, 3, 0.25)]:
        out += periodic_noise(n, lo, hi, tilt=0.5) * amp * (0.3 + 0.7 * slow_lfo(n, cyc, rng.uniform(0, 6)) ** 2)
    gust = periodic_noise(n, 700, 2200, tilt=0.6) * 0.06 * slow_lfo(n, 5, 0.5) ** 3
    # Glittrande iskristaller, mycket svaga
    sparkle = np.zeros(n)
    t = 2.0
    while t < sec:
        f = rng.choice([1568, 1760, 2093, 2349, 2637])
        tt = t_of(1.4)
        tone = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2.01 * f * tt)) * np.exp(-tt * 3.5)
        place(sparkle, tone * 0.06, t)
        t += rng.uniform(1.5, 4.5)
    return 0.6 * out + gust + sparkle


def gull_call():
    """Ett måsskrik: en hes ton som stiger och faller, \"kjau\"."""
    sec = rng.uniform(0.32, 0.5)
    t = t_of(sec)
    f0 = rng.uniform(1100, 1500)
    f = f0 * (1 + 0.35 * np.sin(np.pi * t / sec)) * (1 - 0.25 * t / sec)
    ph = 2 * np.pi * np.cumsum(f) / SR
    tone = np.sin(ph) + 0.6 * np.sin(2 * ph) + 0.35 * np.sin(3 * ph) + 0.2 * np.sin(4 * ph)
    rough = 1 + 0.35 * np.sin(2 * np.pi * 70 * t)           # hesheten
    return tone * rough * env(len(t), 0.03, sec * 0.5)


def ambience_sea(sec=40):
    n = int(sec * SR)
    # Vågor: brus som sväller och drar sig tillbaka, åtta gånger per loop
    swell = slow_lfo(n, 8, 0.0)
    swell2 = slow_lfo(n, 5, 1.3)
    surf = periodic_noise(n, 120, 2500, tilt=0.7) * (0.15 + 0.85 * swell ** 3)
    hiss = periodic_noise(n, 1800, 6000, tilt=0.4) * 0.18 * swell ** 4
    deep = periodic_noise(n, 40, 220, tilt=0.5) * 0.35 * (0.4 + 0.6 * swell2)
    # Skvalp mot stranden: små mjuka klunkar
    lap = np.zeros(n)
    t = 0.8
    while t < sec:
        tt = t_of(0.12)
        f = rng.uniform(260, 520)
        place(lap, np.sin(2 * np.pi * f * tt * (1 - 1.5 * tt)) * np.exp(-tt * 40) * 0.08, t)
        t += rng.uniform(0.25, 1.1)
    # Måsar på avstånd
    gulls = np.zeros(n)
    t = 2.0
    while t < sec:
        for k in range(int(rng.integers(1, 4))):
            place(gulls, gull_call() * rng.uniform(0.06, 0.14), t + k * rng.uniform(0.35, 0.55))
        t += rng.uniform(4.0, 8.0)
    return 0.7 * surf + hiss + deep + lap + gulls


def ambience_cave(sec=40):
    """Trolldiskot: discomusik i 120 bpm som hörs genom berget (20 takter = 40 s,
    så loopen går jämnt ut), med eko från grottväggarna och droppande vatten."""
    n = int(sec * SR)
    out = np.zeros(n)
    beat = 0.5                       # sekunder per taktslag
    # Kick på varje slag
    for k in range(int(sec / beat)):
        tt = t_of(0.25)
        f = 50 + 90 * np.exp(-tt * 30)
        ph = 2 * np.pi * np.cumsum(f) / SR
        place(out, np.sin(ph) * np.exp(-tt * 12) * 0.9, k * beat)
    # Klapp på 2 och 4, öppen hi-hat på efterslagen
    clap_f = butter(2, [900, 3000], "band", fs=SR, output="sos")
    hat_f = butter(2, 7000, "high", fs=SR, output="sos")
    for k in range(int(sec / beat)):
        if k % 2 == 1:
            tt = t_of(0.18)
            place(out, sosfilt(clap_f, rng.normal(size=len(tt))) * np.exp(-tt * 22) * 0.35, k * beat)
        tt = t_of(0.12)
        place(out, sosfilt(hat_f, rng.normal(size=len(tt))) * np.exp(-tt * 30) * 0.18, k * beat + beat / 2)
    # Oktavhoppande discobas och ackordstötar: Am7 – Dm7 – G – Cmaj7, två takter var
    roots = [110.0, 146.83, 98.0, 130.81]
    chords = [[220.0, 261.63, 329.63, 392.0], [293.66, 349.23, 440.0, 523.25],
              [196.0, 246.94, 293.66, 392.0], [261.63, 329.63, 392.0, 493.88]]
    for bar in range(20):
        ci = (bar // 2) % 4
        for e in range(8):           # åttondelar
            tt = t_of(0.2)
            f = roots[ci] * (2 if e % 2 else 1)
            note = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(4 * np.pi * f * tt)) * np.exp(-tt * 9) * 0.45
            place(out, note, bar * 2.0 + e * 0.25)
        for st in (0.75, 1.75):      # stötar på efterslagen
            tt = t_of(0.22)
            ch = sum(np.sin(2 * np.pi * f * tt) + 0.4 * np.sign(np.sin(2 * np.pi * f * tt)) * 0.3 for f in chords[ci])
            place(out, ch * np.exp(-tt * 14) * 0.12, bar * 2.0 + st)
    # Musiken hörs genom berget: dämpa diskanten och lägg på eko
    out = sosfilt(butter(2, 2200, "low", fs=SR, output="sos"), np.concatenate([out, out]))[n:]   # två varv: inget klick vid skarven
    echo = np.zeros(n)
    for d, g in [(0.23, 0.35), (0.47, 0.2), (0.71, 0.1)]:
        echo += np.roll(out, int(d * SR)) * g
    out = out + echo
    # Droppande vatten
    drips = np.zeros(n)
    t = 1.3
    while t < sec:
        tt = t_of(0.15)
        f = rng.uniform(900, 1600) * (1 + 2.5 * tt)
        ph = 2 * np.pi * np.cumsum(f) / SR
        place(drips, np.sin(ph) * np.exp(-tt * 35) * 0.25, t)
        t += rng.uniform(2.5, 6.0)
    return out * 0.8 + drips


def music_box(f, sec=0.9):
    """En speldosaton: ren grundton, lite fjärde överton och snabb avklingning."""
    tt = t_of(sec)
    return (np.sin(2 * np.pi * f * tt) + 0.35 * np.sin(2 * np.pi * 3.98 * f * tt) * np.exp(-tt * 12)
            + 0.15 * np.sin(2 * np.pi * 2 * f * tt)) * np.exp(-tt * 4.5) * (1 - np.exp(-tt * 600))


def ambience_candy(sec=40):
    """Godisfabriken: lekfull speldosemelodi i 120 bpm (20 takter = 40 s) över
    maskiner som tuggar och klonkar i takt."""
    n = int(sec * SR)
    out = np.zeros(n)
    beat = 0.5
    C, D, E, F, G, A, B, C2, D2, E2, G2 = 523.25, 587.33, 659.25, 698.46, 783.99, 880.0, 987.77, 1046.5, 1174.7, 1318.5, 1568.0
    # Melodi i åttondelar, fyra takter som upprepas (None = paus)
    phrase = [E2, G2, E2, C2, D2, None, G, None,
              C2, E2, D2, C2, B, None, G, None,
              A, C2, B, A, G, E, G, C2,
              D2, None, B, G, C2, None, None, None]
    for bar in range(20):
        for e in range(8):
            f = phrase[(bar % 4) * 8 + e]
            if f is not None:
                place(out, music_box(f) * 0.22, bar * 2.0 + e * 0.25)
    # Bas: C – A – F – G, staccato på slagen
    roots = [130.81, 110.0, 87.31, 98.0]
    for bar in range(20):
        r = roots[bar % 4]
        for k in range(4):
            tt = t_of(0.22)
            f = r * (1.5 if k == 2 else 1)
            place(out, (np.sin(2 * np.pi * f * tt) + 0.4 * np.sin(4 * np.pi * f * tt)) * np.exp(-tt * 14) * 0.35, bar * 2.0 + k * beat)
    # Maskinerna: ett tuggande brus på varje slag och ett klonk på ettan
    chug_f = butter(2, [200, 900], "band", fs=SR, output="sos")
    for k in range(int(sec / beat)):
        tt = t_of(0.16)
        place(out, sosfilt(chug_f, rng.normal(size=len(tt))) * np.exp(-tt * 25) * 0.25, k * beat + beat / 2)
        if k % 4 == 0:
            tt = t_of(0.3)
            clank = sum(np.sin(2 * np.pi * f * tt) * a for f, a in [(420, 1), (1130, 0.6), (2210, 0.3)])
            place(out, clank * np.exp(-tt * 18) * 0.12, k * beat)
    # Ånga som pyser då och då
    hiss_f = butter(2, [3500, 7000], "band", fs=SR, output="sos")
    for bar in range(0, 20, 4):
        tt = t_of(0.6)
        place(out, sosfilt(hiss_f, rng.normal(size=len(tt))) * np.sin(np.pi * tt / 0.6) ** 2 * 0.015, bar * 2.0 + 1.25)
    return out


# ---- Effekter ---------------------------------------------------------------

def sfx_launch():       # gummibandet smäller och kotten susar iväg
    t = t_of(0.35)
    twang = np.sin(2 * np.pi * (180 - 120 * t) * t) * np.exp(-t * 14)
    whoosh = sosfilt(butter(2, [700, 2600], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.sin(np.pi * t / 0.35) * 0.6
    return 0.8 * twang + whoosh


def thud(f, decay, noise_amt, sec=0.25):
    t = t_of(sec)
    body = np.sin(2 * np.pi * f * t * (1 - 0.3 * t)) * np.exp(-t * decay)
    click = sosfilt(butter(2, 3000, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 60) * noise_amt
    return body + click


def sfx_hit():
    return thud(140, 26, 0.6)


def sfx_break_wood():
    out = thud(220, 30, 0.8, 0.45)
    for k in range(4):
        place(out, thud(rng.uniform(300, 520), 45, 0.5, 0.12) * 0.5, 0.04 + k * 0.06)
    return out


def sfx_break_stone():
    t = t_of(0.55)
    rumble = sosfilt(butter(2, 900, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 7)
    return 0.9 * rumble + 0.6 * thud(90, 12, 0.3, 0.55)


def sfx_break_ice():
    t = t_of(0.6)
    out = np.zeros(len(t))
    for k in range(6):
        f = rng.uniform(2200, 4200)
        tt = t_of(0.35)
        place(out, np.sin(2 * np.pi * f * tt) * np.exp(-tt * 18) * 0.35, k * 0.045)
    crash = sosfilt(butter(2, 2500, "high", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 16) * 0.5
    return out + crash


def sfx_break_snow():   # mjuk puff
    t = t_of(0.35)
    return sosfilt(butter(2, [300, 1800], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.sin(np.pi * t / 0.35) ** 2 * 0.9


def sfx_troll():        # "oj!" – en grumlig ton som faller, och en puff
    t = t_of(0.5)
    f = 260 * np.exp(-t * 2.2)
    ph = 2 * np.pi * np.cumsum(f) / SR
    voice = (np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.25 * np.sin(3 * ph)) * env(len(t), 0.02, 0.25) * 0.5
    puff = sfx_break_snow()
    return voice + np.pad(puff, (0, len(t) - len(puff)))


def sfx_splash():       # plask: ett \"blopp\" och skum
    t = t_of(0.7)
    f = 900 * np.exp(-t * 9) + 180
    ph = 2 * np.pi * np.cumsum(f) / SR
    blop = np.sin(ph) * np.exp(-t * 14) * 0.6
    spray = sosfilt(butter(2, [800, 6000], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 6) * (1 - np.exp(-t * 80))
    return blop + spray


def sfx_release():      # något lossnar från taket: knak och skrammel
    t = t_of(0.5)
    crack = sosfilt(butter(2, [400, 3000], "band", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 25)
    out = crack.copy()
    for k in range(4):
        tt = t_of(0.15)
        f = rng.uniform(2500, 4000)
        place(out, np.sin(2 * np.pi * f * tt) * np.exp(-tt * 30) * 0.3, 0.05 + k * 0.07)
    return out


def sfx_crystal():      # kotten studsar mot en kristall: klar klang
    t = t_of(0.9)
    out = np.zeros(len(t))
    for f, a in [(1975.5, 1.0), (2637.0, 0.6), (3951.0, 0.35), (5274.0, 0.2)]:
        out += a * np.sin(2 * np.pi * f * t) * np.exp(-t * (4 + f / 1500))
    return out * (1 - np.exp(-t * 400))


def sfx_boing():        # gelé: en fjädrande ton som stiger och darrar
    t = t_of(0.45)
    f = 180 * (1 + 2.2 * (1 - np.exp(-t * 9))) * (1 + 0.06 * np.sin(2 * np.pi * 18 * t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) + 0.3 * np.sin(2 * ph)) * np.exp(-t * 6) * (1 - np.exp(-t * 300))


def sfx_squish():       # marshmallow: ett mjukt, kladdigt tryck
    t = t_of(0.3)
    noise = sosfilt(butter(2, [150, 1200], "band", fs=SR, output="sos"), rng.normal(size=len(t)))
    wob = 1 + 0.5 * np.sin(2 * np.pi * 22 * t)
    return noise * wob * np.sin(np.pi * t / 0.3) ** 1.5 * 1.2


def sfx_break_candy():  # polkagris: krispigt knäck och lite glas
    t = t_of(0.45)
    out = sosfilt(butter(2, 2500, "high", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 30) * 0.7
    for k in range(5):
        tt = t_of(0.2)
        place(out, np.sin(2 * np.pi * rng.uniform(1800, 3200) * tt) * np.exp(-tt * 25) * 0.3, 0.02 + k * 0.05)
    return out


def sfx_ability():
    return chirp(600, 1800, 0.18, (1, 0.3)) * 0.7


def sfx_burst():
    t = t_of(0.8)
    boom = sosfilt(butter(2, 500, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 5) * 1.2
    return boom + 0.7 * thud(60, 6, 0.0, 0.8)


def marimba(freqs, step, sec):
    out = np.zeros(int(sec * SR))
    for i, f in enumerate(freqs):
        tt = t_of(0.6)
        note = (np.sin(2 * np.pi * f * tt) + 0.25 * np.sin(2 * np.pi * 4 * f * tt) * np.exp(-tt * 20)) * np.exp(-tt * 6)
        place(out, note * 0.6, i * step)
    return out


def sfx_win():
    return marimba([523.25, 659.25, 783.99, 1046.5], 0.12, 1.1)


def sfx_lose():
    return marimba([392.0, 329.63, 261.63], 0.2, 1.1)


# ---- Skriv filer ------------------------------------------------------------

def normalize(y, peak):
    return y / np.max(np.abs(y)) * peak


def write_wav(path, y):
    y = np.clip(y, -1, 1)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((y * 32767).astype("<i2").tobytes())


def main(only=None):
    """Skapar alla ljud, eller bara de som räknas upp:
    python3 tools/make_sounds.py candy boing squish   (bakgrundsljud anges med världens namn)"""
    os.makedirs(OUT, exist_ok=True)
    ambiences = [("forest", ambience_forest), ("winter", ambience_winter), ("sea", ambience_sea),
                 ("cave", ambience_cave), ("candy", ambience_candy)]
    for name, fn in ambiences:
        if only and name not in only:
            continue
        tmp = os.path.join(OUT, name + ".tmp.wav")
        write_wav(tmp, normalize(fn(), 0.5))
        subprocess.run(["oggenc", "-Q", "-q", "2", "-o", os.path.join(OUT, "ambience-" + name + ".ogg"), tmp], check=True)
        os.remove(tmp)
    effects = {"launch": sfx_launch, "hit": sfx_hit, "break-wood": sfx_break_wood, "break-stone": sfx_break_stone,
               "break-ice": sfx_break_ice, "break-snow": sfx_break_snow, "troll": sfx_troll, "ability": sfx_ability,
               "burst": sfx_burst, "win": sfx_win, "lose": sfx_lose, "splash": sfx_splash,
               "release": sfx_release, "crystal": sfx_crystal,
               "boing": sfx_boing, "squish": sfx_squish, "break-candy": sfx_break_candy}
    for name, fn in effects.items():
        if only and name not in only:
            continue
        write_wav(os.path.join(OUT, name + ".wav"), normalize(fn(), 0.8))
    for f in sorted(os.listdir(OUT)):
        print(f, os.path.getsize(os.path.join(OUT, f)) // 1024, "kB")


if __name__ == "__main__":
    import sys
    main(sys.argv[1:] or None)
