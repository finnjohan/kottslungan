// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Game.js" as Game
import "Levels.js" as Levels
import "Physics.js" as Physics

// Själva spelplanen: fysik, ritning och sikte.
Item {
    id: view
    property int levelNumber: 1
    property bool running: true
    readonly property var level: Levels.list[levelNumber - 1]

    property var game: null
    property int score: 0
    property int trollsLeft: 0
    property string state: "aim"
    property var queue: []            // kottar som väntar (typer)
    property string currentType: ""
    property var dots: []

    signal finished(bool won, int score, int bonus)

    // ---- Koordinater --------------------------------------------------
    readonly property real ppm: width / Game.WORLD_W
    readonly property real viewBottom: -1.3          // meter under marken som syns
    readonly property real originY: height + viewBottom * ppm
    function px(x) { return x * ppm }
    function py(y) { return originY - y * ppm }
    function worldX(sx) { return sx / ppm }
    function worldY(sy) { return (originY - sy) / ppm }

    property var sprites: ({})
    property var currentSprite: null

    readonly property bool winter: level.world === "winter"
    readonly property bool sea: level.world === "sea"
    readonly property bool cave: level.world === "cave"
    readonly property bool moon: level.world === "moon"
    readonly property bool candy: level.world === "candy"
    property double lastBoing: 0
    readonly property real shoreM: sea ? Game.GROUND.sea.shore : -1

    Scenery {
        anchors.fill: parent
        groundY: view.originY
        night: root.isDark
        world: view.level.world
        shoreX: view.sea ? view.px(view.shoreM) : -1
        ceilingY: view.cave ? view.py(Game.GROUND.cave.ceiling) : height * 0.14
    }

    // Ekorren och slangbellan
    Image {
        source: "../assets/squirrel.svg"
        width: 2.3 * view.ppm; height: width * 220 / 200
        x: view.px(Game.SLING_X - 3.15); y: view.py(0) - height + view.ppm * 0.05
        sourceSize: Qt.size(Math.ceil(width * 1.5), Math.ceil(height * 1.5))
    }

    // Kottar som väntar på sin tur
    Row {
        x: view.px(0.3); y: view.py(0) - height
        spacing: view.ppm * 0.08
        layoutDirection: Qt.RightToLeft
        Repeater {
            model: view.queue
            Image {
                width: 2 * Game.CONES[modelData].r * view.ppm; height: width
                source: "../assets/cone-" + modelData + ".svg"
                sourceSize: Qt.size(Math.ceil(width * 1.5), Math.ceil(width * 1.5))
            }
        }
    }

    readonly property real slingH: 3.8
    readonly property real slingW: slingH * 60 / 200
    readonly property point backTip: Qt.point(Game.SLING_X + 0.36, 3.7)
    readonly property point frontTip: Qt.point(Game.SLING_X - 0.36, 3.7)
    property point pouch: Qt.point(Game.SLING_X, Game.SLING_Y)

    Band { from: view.backTip; to: view.pouch; ppm: view.ppm; originY: view.originY }

    Image {
        id: slingshot
        source: "../assets/slingshot.svg"
        width: view.slingW * view.ppm; height: view.slingH * view.ppm
        x: view.px(Game.SLING_X) - width / 2; y: view.py(0) - height
        sourceSize: Qt.size(Math.ceil(width * 1.5), Math.ceil(height * 1.5))
    }

    // Spelfigurerna läggs här
    Item { id: layer; anchors.fill: parent }

    Band { from: view.frontTip; to: view.pouch; ppm: view.ppm; originY: view.originY; z: 2 }

    // Havet framför skär och skrov: det som är under ytan syns inte
    Rectangle {
        visible: view.sea
        z: 2
        x: view.px(view.shoreM); y: view.py(0)
        width: parent.width - x; height: parent.height - y
        gradient: Gradient {
            GradientStop { position: 0; color: root.isDark ? "#B81E4466" : "#D02F7DB4" }
            GradientStop { position: 1; color: root.isDark ? "#0E2238" : "#1A4E7A" }
        }
    }
    Waves {
        visible: view.sea
        z: 2
        x: view.px(view.shoreM); width: parent.width - x
        height: view.ppm * 0.35
        y: view.py(0) - height * 0.5
        opacity: root.isDark ? 0.55 : 0.85
        running: visible && view.running
        duration: 3600
    }
    // Månen speglar sig i vattnet på kvällen
    Repeater {
        model: view.sea && root.isDark ? 6 : 0
        Rectangle {
            z: 2
            readonly property real w: Math.min(view.width, view.height) * (0.1 - index * 0.012)
            x: view.width * 0.78 + Math.min(view.width, view.height) * 0.06 - w / 2
            y: view.py(0) + (index + 0.6) * (view.height - view.py(0)) / 7
            width: w; height: Math.max(2, view.ppm * 0.06); radius: height / 2
            color: "#F2EBC8"; opacity: 0.55
        }
    }
    // Strandkanten: sanden sluttar ned i vattnet
    Rectangle {
        visible: view.sea
        z: 2
        x: view.px(view.shoreM) - width * 0.6; y: view.py(0) - view.ppm * 0.1
        width: view.ppm * 1.2; height: view.ppm * 0.5
        radius: height / 2
        color: root.isDark ? "#8C7A5A" : "#F0D9A4"
    }

    // Bana som prickar
    Repeater {
        model: view.dots
        Rectangle {
            z: 3
            width: Math.max(4, view.ppm * (0.16 - index * 0.004)); height: width; radius: width / 2
            x: view.px(modelData.x) - width / 2; y: view.py(modelData.y) - height / 2
            color: "#FFFFFF"; opacity: 0.85 - index * 0.025
        }
    }

    Item { id: effects; anchors.fill: parent; z: 4 }

    // ---- Komponenter --------------------------------------------------
    Component { id: spriteComp; BodySprite {} }

    Component {
        id: poofComp
        Item {
            id: poof
            property color tint: "#FFFFFF"
            property real size: 60
            width: size; height: size
            Repeater {
                model: 6
                Rectangle {
                    readonly property real a: index * Math.PI / 3
                    width: poof.size * 0.4; height: width; radius: width / 2
                    color: poof.tint
                    x: poof.size / 2 - width / 2 + Math.cos(a) * poof.size * 0.5 * anim.t
                    y: poof.size / 2 - height / 2 + Math.sin(a) * poof.size * 0.5 * anim.t
                    opacity: 0.8 * (1 - anim.t)
                    scale: 0.6 + anim.t
                }
            }
            QtObject { id: anim; property real t: 0 }
            NumberAnimation { target: anim; property: "t"; from: 0; to: 1; duration: 600; running: true
                              onFinished: poof.destroy() }
        }
    }

    Component {
        id: popupComp
        Label {
            id: pop
            property real startY: 0
            font.weight: Font.Bold
            font.pixelSize: view.ppm * 0.7
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
            NumberAnimation on y { from: pop.startY; to: pop.startY - view.ppm * 1.5; duration: 1000; running: true }
            NumberAnimation on opacity { from: 1; to: 0; duration: 1000; running: true; onFinished: pop.destroy() }
        }
    }

    // ---- Spelets gång ---------------------------------------------------
    function start() {
        for (var k in sprites) sprites[k].destroy()
        if (currentSprite) currentSprite.destroy()
        sprites = {}
        currentSprite = null
        dots = []
        game = Game.newGame(JSON.parse(JSON.stringify(level)))
        processEvents()
        syncAll()
        lastTick = Date.now()
    }

    function makeSprite(body) {
        var s = spriteComp.createObject(layer, { body: body, winter: view.winter, sea: view.sea, cave: view.cave, moon: view.moon, candy: view.candy, ppm: Qt.binding(function () { return view.ppm }),
                                                 originY: Qt.binding(function () { return view.originY }) })
        s.refresh()
        s.sync()
        return s
    }

    function poof(x, y, tint, size) {
        poofComp.createObject(effects, { x: px(x) - size * ppm / 2, y: py(y) - size * ppm / 2,
                                         size: size * ppm, tint: tint })
    }

    function popup(x, y, text) {
        var p = popupComp.createObject(effects, { text: text, startY: py(y) - ppm })
        p.x = px(x) - p.width / 2
    }

    function processEvents() {
        var ev = Game.takeEvents(game)
        for (var i = 0; i < ev.length; i++) {
            var e = ev[i], b = e.body
            if (e.type === "add") {
                sprites[b.id] = makeSprite(b)
            } else if (e.type === "load") {
                if (currentSprite) currentSprite.destroy()
                currentSprite = makeSprite(b)
                sprites[b.id] = currentSprite
                currentType = b.data.type
                pouch = Qt.point(Game.SLING_X, Game.SLING_Y)
            } else if (e.type === "launch") {
                root.playSound("launch")
                currentSprite = null
                pouch = Qt.point(Game.SLING_X, Game.SLING_Y)
                dots = []
            } else if (e.type === "hurt") {
                if (sprites[b.id]) sprites[b.id].refresh()
            } else if (e.type === "destroy") {
                if (!e.splash) root.playSound(b.kind === "troll" ? "troll"
                                              : b.data.mat === "powder" || b.data.mat === "chandelier" ? "break-wood"
                                              : b.data.mat === "stalactite" ? "break-stone"
                                              : b.data.mat === "discoball" ? "break-ice"
                                              : b.data.mat === "moonrock" || b.data.mat === "chocolate" ? "break-stone"
                                              : b.data.mat === "jelly" || b.data.mat === "marshmallow" ? "squish"
                                              : b.data.mat === "candycane" ? "break-candy"
                                              : "break-" + b.data.mat)
                if (sprites[b.id]) { sprites[b.id].destroy(); delete sprites[b.id] }
                var tint = b.kind === "troll" ? (winter ? "#DDEBF3" : moon ? "#C9D2DA" : "#A6B58A") : b.data.mat === "wood" ? "#C79A66"
                         : b.data.mat === "snow" ? "#FFFFFF" : b.data.mat === "powder" ? "#B23A2A"
                         : b.data.mat === "discoball" ? "#D8E0E8" : b.data.mat === "chandelier" ? "#FFE68A"
                         : b.data.mat === "stalactite" ? "#8C8178"
                         : b.data.mat === "metal" ? "#C9D2DA" : b.data.mat === "moonrock" ? "#A8A39A"
                         : b.data.mat === "jelly" ? "#FF8FA8" : b.data.mat === "marshmallow" ? "#FFF0F6"
                         : b.data.mat === "chocolate" ? "#7A4A2E" : b.data.mat === "candycane" ? "#FF6A7E"
                         : b.data.mat === "stone" ? "#B9BDC2" : "#E6F7FF"
                poof(e.x, e.y, tint, b.kind === "troll" ? 2.2 : 1.4)
                if (e.points > 0) popup(e.x, e.y, e.points)
            } else if (e.type === "remove") {
                if (sprites[b.id]) { sprites[b.id].destroy(); delete sprites[b.id] }
                poof(b.x, b.y, "#E9DCC4", 0.9)
            } else if (e.type === "burst") {
                root.playSound("burst")
                poof(e.x, e.y, "#FFB347", 5)
                poof(e.x, e.y, "#FFE08A", 3)
            } else if (e.type === "ability") {
                if (e.ability !== "burst") root.playSound("ability")
                if (e.ability === "dash") poof(b.x, b.y, "#FFFFFF", 1.0)
            } else if (e.type === "release") {
                root.playSound("release")
                if (sprites[b.id]) sprites[b.id].refresh()
            } else if (e.type === "pop") {
                root.playSound("pop")
                if (sprites[b.id]) sprites[b.id].refresh()
                poof(e.x, e.y, "#D0F2FF", 1.8)
            } else if (e.type === "boing" || e.type === "squish") {
                // Högst ett godisljud per 120 ms, annars blir en rasande stapel bara brus
                var now = Date.now()
                if (now - lastBoing > 120) { lastBoing = now; root.playSound(e.type) }
            } else if (e.type === "ping") {
                root.playSound("crystal")
                poof(e.x, e.y, "#8FF0FF", 0.8)
            } else if (e.type === "splash") {
                root.playSound("splash")
                poof(e.x, 0.1, "#BFE3FA", Math.max(1.2, e.size * 1.6))
                poof(e.x, 0.4, "#FFFFFF", Math.max(0.8, e.size))
            } else if (e.type === "explode") {
                root.playSound("burst")
                poof(e.x, e.y, "#FF8A3D", 6)
                poof(e.x, e.y, "#FFE08A", 3.5)
                poof(e.x, e.y, "#5A5A5A", 4.5)
            } else if (e.type === "impact") {
                root.playSound("hit")
            } else if (e.type === "won") {
                root.playSound("win")
                if (e.bonus > 0) popup(Game.SLING_X, 5, "+" + e.bonus)
                endTimer.won = true; endTimer.bonus = e.bonus; endTimer.start()
            } else if (e.type === "lost") {
                root.playSound("lose")
                endTimer.won = false; endTimer.bonus = 0; endTimer.start()
            }
        }
        score = game.score
        trollsLeft = game.trolls
        state = game.state
        queue = game.queue.slice()
    }

    function syncAll() {
        for (var k in sprites) sprites[k].sync()
    }

    Timer {
        id: endTimer
        property bool won: false
        property int bonus: 0
        interval: 1300
        onTriggered: view.finished(won, view.score, bonus)
    }

    property double lastTick: 0
    Timer {
        interval: 16
        repeat: true
        running: view.running && view.game !== null && Qt.application.state === Qt.ApplicationActive
        onRunningChanged: view.lastTick = Date.now()
        onTriggered: {
            var now = Date.now()
            var dt = Math.min(0.05, (now - view.lastTick) / 1000)
            view.lastTick = now
            Game.update(view.game, dt)
            view.processEvents()
            view.syncAll()
        }
    }

    // ---- Sikte ----------------------------------------------------------
    MouseArea {
        anchors.fill: parent
        property bool aiming: false
        onPressed: {
            if (!view.game) return
            if (view.state === "aim") {
                var wx = view.worldX(mouse.x), wy = view.worldY(mouse.y)
                // Dra var som helst i vänstra delen av planen
                aiming = wx < Game.SLING_X + 6
                if (aiming) update(wx, wy, true)
            } else if (view.state === "flying") {
                Game.useAbility(view.game)
                view.processEvents()
            }
        }
        property real startX: 0
        property real startY: 0
        function update(wx, wy, first) {
            if (first) { startX = wx; startY = wy }
            var p = Game.aim(view.game, wx - startX, wy - startY)
            if (!p) return
            view.pouch = Qt.point(p.x, p.y)
            if (view.currentSprite) view.currentSprite.sync()
            var dx = view.game.pullX, dy = view.game.pullY
            view.dots = Math.sqrt(dx * dx + dy * dy) > 0.35 ? Game.trajectory(view.game, 16, view.moon ? 8 : 5) : []
        }
        onPositionChanged: if (aiming) update(view.worldX(mouse.x), view.worldY(mouse.y), false)
        onReleased: {
            if (!aiming) return
            aiming = false
            var launched = Game.launch(view.game)
            if (!launched) {
                view.pouch = Qt.point(Game.SLING_X, Game.SLING_Y)
                if (view.currentSprite) view.currentSprite.sync()
                view.dots = []
            }
            view.processEvents()
        }
    }
}
