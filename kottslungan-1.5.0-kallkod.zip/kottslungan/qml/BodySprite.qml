// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// Ritar en kropp ur fysiken: block, troll, klippa eller kotte.
Item {
    id: sprite
    property var body: null
    property real ppm: 30            // pixlar per meter
    property real originY: 0         // pixelrad för y = 0
    property real damage: 0          // 0..1, hur skadad
    property bool winter: false      // vinterskogen: snö på klippor, troll med mössa
    property bool sea: false         // sjörövarviken: sjörövartroll, skär och skeppsskrov
    property bool cave: false        // trollgrottan: discotroll, droppsten, kristaller
    property bool candy: false       // godisfabriken: bagartroll
    property bool moon: false        // trollen på månen: plåt, månsten, antenner och bubbelhjälm
    property bool hanging: false     // hänger i taket (kedjan ritas)
    property bool helmet: false      // trollet har bubbelhjälm
    readonly property bool floating: !!(body && body.data && body.data.floating)
    readonly property string mat: body && body.data && body.data.mat ? body.data.mat : ""
    readonly property bool picture: mat === "powder" || mat === "stalactite" || mat === "discoball" || mat === "chandelier"
    readonly property string rockStyle: body && body.data && body.data.style ? body.data.style : "rock"
    readonly property string kind: body ? body.kind : ""
    readonly property bool isCircle: body && body.shape === "circle"

    width: body ? (isCircle ? 2 * body.r : 2 * body.hw) * ppm : 0
    height: body ? (isCircle ? 2 * body.r : 2 * body.hh) * ppm : 0

    function sync() {
        if (!body) return
        x = body.x * ppm - width / 2
        y = originY - body.y * ppm - height / 2
        rotation = -body.angle * 180 / Math.PI
    }

    function refresh() {
        hanging = !!(body && body.data && body.data.hanging)
        helmet = !!(body && body.data && body.data.helmet)
        if (body && body.data && body.data.maxHp) damage = Math.max(0, 1 - body.data.hp / body.data.maxHp)
    }

    // ---- Svävande sten: ett svagt sken under, som en kraft som håller den uppe ----
    Rectangle {
        visible: sprite.floating && sprite.hanging
        width: sprite.width * 1.1; height: Math.max(4, sprite.ppm * 0.35)
        x: (sprite.width - width) / 2; y: sprite.height - height * 0.3
        radius: height / 2
        opacity: 0.55
        gradient: Gradient {
            GradientStop { position: 0; color: "#9FE8FF" }
            GradientStop { position: 1; color: "transparent" }
        }
        SequentialAnimation on opacity {
            running: parent.visible && Qt.application.state === Qt.ApplicationActive
            loops: Animation.Infinite
            NumberAnimation { to: 0.2; duration: 1100; easing.type: Easing.InOutSine }
            NumberAnimation { to: 0.6; duration: 1100; easing.type: Easing.InOutSine }
        }
    }

    // ---- Block ------------------------------------------------------------
    Rectangle {
        id: blockRect
        anchors.fill: parent
        visible: sprite.kind === "block" && !sprite.picture
        readonly property string mat: sprite.body && sprite.body.data && sprite.body.data.mat ? sprite.body.data.mat : ""
        // Gelé i tre färger efter kroppens nummer
        readonly property var jellyTop: ["#FF7A96", "#9BE86E", "#FFC46B"]
        readonly property var jellyBottom: ["#E0385E", "#5DB83A", "#F0932A"]
        readonly property int jellyIndex: sprite.body ? sprite.body.id % 3 : 0
        radius: Math.min(width, height) * (mat === "marshmallow" ? 0.4 : mat === "jelly" ? 0.22 : 0.12)
        clip: mat === "candycane"
        border.width: Math.max(1, Math.min(width, height) * 0.08)
        border.color: mat === "wood" ? "#6E4520" : mat === "stone" ? "#55595F" : mat === "snow" ? "#A9BCCB"
                      : mat === "metal" ? "#5E6A76" : mat === "moonrock" ? "#5A5650"
                      : mat === "jelly" ? jellyBottom[jellyIndex] : mat === "marshmallow" ? "#E3B3C8"
                      : mat === "chocolate" ? "#3E200F" : mat === "candycane" ? "#C8384A" : "#7DBDE6"
        gradient: Gradient {
            GradientStop { position: 0; color: blockRect.mat === "wood" ? "#C08A50" : blockRect.mat === "stone" ? "#A9ADB3"
                                               : blockRect.mat === "snow" ? "#FFFFFF" : blockRect.mat === "metal" ? "#E6ECF2"
                                               : blockRect.mat === "moonrock" ? "#B3ADA4"
                                               : blockRect.mat === "jelly" ? blockRect.jellyTop[blockRect.jellyIndex]
                                               : blockRect.mat === "marshmallow" ? "#FFFFFF"
                                               : blockRect.mat === "chocolate" ? "#8A5636"
                                               : blockRect.mat === "candycane" ? "#FFFFFF" : "#E4F6FF" }
            GradientStop { position: 1; color: blockRect.mat === "wood" ? "#97612F" : blockRect.mat === "stone" ? "#7C8086"
                                               : blockRect.mat === "snow" ? "#DCE7EF" : blockRect.mat === "metal" ? "#9AA6B2"
                                               : blockRect.mat === "moonrock" ? "#7E786E"
                                               : blockRect.mat === "jelly" ? blockRect.jellyBottom[blockRect.jellyIndex]
                                               : blockRect.mat === "marshmallow" ? "#F7D6E4"
                                               : blockRect.mat === "chocolate" ? "#5A321C"
                                               : blockRect.mat === "candycane" ? "#F4ECEC" : "#A9DCF7" }
        }
        opacity: mat === "ice" ? 0.85 : mat === "jelly" ? 0.9 : 1
        // Glans på gelén
        Rectangle {
            visible: blockRect.mat === "jelly"
            x: parent.width * 0.15; y: parent.height * 0.12
            width: parent.width * 0.35; height: Math.max(2, parent.height * 0.14); radius: height / 2
            color: "#FFFFFF"; opacity: 0.55
        }
        // Rutor i chokladkakan
        Repeater {
            model: blockRect.mat === "chocolate" ? Math.max(1, Math.round(Math.max(sprite.width, sprite.height) / (sprite.ppm * 0.6))) - 1 : 0
            Rectangle {
                readonly property bool horizontal: sprite.width >= sprite.height
                readonly property int n: Math.max(1, Math.round(Math.max(sprite.width, sprite.height) / (sprite.ppm * 0.6)))
                color: "#3E200F"; opacity: 0.6
                x: horizontal ? (index + 1) * sprite.width / n - width / 2 : sprite.width * 0.1
                y: horizontal ? sprite.height * 0.1 : (index + 1) * sprite.height / n - height / 2
                width: horizontal ? Math.max(1, sprite.ppm * 0.04) : sprite.width * 0.8
                height: horizontal ? sprite.height * 0.8 : Math.max(1, sprite.ppm * 0.04)
            }
        }
        // Röda ränder på polkagrisen
        Repeater {
            model: blockRect.mat === "candycane" ? Math.ceil(Math.max(sprite.width, sprite.height) / (sprite.ppm * 0.28)) + 2 : 0
            Rectangle {
                readonly property bool horizontal: sprite.width >= sprite.height
                color: "#E0384E"
                width: horizontal ? Math.max(2, sprite.ppm * 0.1) : sprite.width * 2
                height: horizontal ? sprite.height * 2 : Math.max(2, sprite.ppm * 0.1)
                x: horizontal ? (index - 1) * sprite.ppm * 0.28 : -sprite.width / 2
                y: horizontal ? -sprite.height / 2 : (index - 1) * sprite.ppm * 0.28
                rotation: 35
            }
        }
        // Ådring längs den långa sidan
        Repeater {
            model: blockRect.mat === "wood" ? 2 : 0
            Rectangle {
                readonly property bool horizontal: sprite.width >= sprite.height
                color: "#7A4C24"; opacity: 0.55
                x: horizontal ? sprite.width * 0.1 : sprite.width * (0.33 + index * 0.33) - width / 2
                y: horizontal ? sprite.height * (0.33 + index * 0.33) - height / 2 : sprite.height * 0.1
                width: horizontal ? sprite.width * 0.8 : Math.max(1, sprite.width * 0.07)
                height: horizontal ? Math.max(1, sprite.height * 0.07) : sprite.height * 0.8
            }
        }
        // Nitar i plåten
        Repeater {
            model: blockRect.mat === "metal" ? 2 : 0
            Rectangle {
                readonly property bool horizontal: sprite.width >= sprite.height
                readonly property real d: Math.max(2, Math.min(sprite.width, sprite.height) * 0.3)
                width: d; height: d; radius: d / 2
                color: "#6E7A86"
                x: horizontal ? (index === 0 ? sprite.width * 0.12 : sprite.width * 0.88 - d) : sprite.width / 2 - d / 2
                y: horizontal ? sprite.height / 2 - d / 2 : (index === 0 ? sprite.height * 0.1 : sprite.height * 0.9 - d)
            }
        }
        // Små kratrar i månstenen
        Repeater {
            model: blockRect.mat === "moonrock" ? 3 : 0
            Rectangle {
                readonly property real d: Math.min(sprite.width, sprite.height) * (0.22 + index * 0.06)
                width: d; height: d; radius: d / 2
                color: "#6C665D"; opacity: 0.7
                x: sprite.width * [0.18, 0.55, 0.72][index] - d / 2 + d / 2
                y: sprite.height * [0.25, 0.55, 0.2][index]
            }
        }
        // Ett tunt snölager på trä och sten i vinterskogen
        Rectangle {
            visible: sprite.winter && (blockRect.mat === "wood" || blockRect.mat === "stone") && sprite.width > sprite.height
            width: parent.width; height: Math.max(2, parent.height * 0.3)
            radius: blockRect.radius
            color: "#F6FAFD"
        }
        Image {
            anchors.fill: parent
            source: "../assets/crack.svg"
            opacity: sprite.damage > 0.35 ? Math.min(1, sprite.damage * 1.3) : 0
            sourceSize: Qt.size(128, 128)
        }
    }

    // ---- Kedja till taket ------------------------------------------------
    Rectangle {
        visible: sprite.hanging && sprite.body.data.chain > 0
        width: Math.max(2, sprite.ppm * 0.06)
        height: visible ? sprite.body.data.chain * sprite.ppm + 2 : 0
        x: sprite.width / 2 - width / 2
        y: -height + 1
        color: "#C9A23C"
        border.color: "#7A5E14"; border.width: 1
    }

    // ---- Krutfat, droppsten, discokula och ljuskrona (bilder) -------------
    Image {
        anchors.fill: parent
        visible: sprite.kind === "block" && sprite.picture
        source: !visible ? "" : sprite.mat === "powder" ? "../assets/keg.svg"
              : sprite.mat === "stalactite" ? "../assets/stalactite.svg"
              : sprite.mat === "discoball" ? "../assets/discoball.svg" : "../assets/chandelier.svg"
        sourceSize: Qt.size(Math.max(16, Math.ceil(width * 1.5)), Math.max(16, Math.ceil(height * 1.5)))
        Image {
            anchors.fill: parent
            source: "../assets/crack.svg"
            opacity: sprite.damage > 0.35 ? Math.min(1, sprite.damage * 1.3) : 0
            sourceSize: Qt.size(128, 128)
        }
    }

    // ---- Skeppsskrov ------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: sprite.kind === "rock" && sprite.rockStyle === "ship"
        radius: Math.min(width, height) * 0.06
        color: "#7A4A26"
        border.color: "#3E230F"; border.width: 2
        // plankor
        Repeater {
            model: sprite.rockStyle === "ship" ? Math.max(2, Math.round(sprite.height / (sprite.ppm * 0.4))) : 0
            Rectangle { y: (index + 1) * sprite.height / (Math.round(sprite.height / (sprite.ppm * 0.4)) + 1)
                        width: sprite.width; height: Math.max(1, sprite.ppm * 0.04); color: "#4E2E14"; opacity: 0.6 }
        }
        // reling och däck
        Rectangle { width: parent.width; height: Math.max(4, sprite.ppm * 0.16); color: "#A06A3C"; border.color: "#3E230F"; border.width: 1 }
        // ventiler
        Repeater {
            model: sprite.rockStyle === "ship" ? Math.max(1, Math.floor(sprite.width / (sprite.ppm * 1.4))) : 0
            Rectangle {
                readonly property real d: sprite.ppm * 0.42
                width: d; height: d; radius: d / 2
                x: (index + 0.5) * sprite.width / Math.max(1, Math.floor(sprite.width / (sprite.ppm * 1.4))) - d / 2
                y: sprite.ppm * 0.45
                color: "#2A1A0C"; border.color: "#E2B13C"; border.width: Math.max(1, sprite.ppm * 0.05)
            }
        }
    }

    // ---- Kristall (studsig) --------------------------------------------------
    Image {
        anchors.fill: parent
        visible: sprite.kind === "rock" && sprite.rockStyle === "crystal"
        source: visible ? "../assets/crystal.svg" : ""
        sourceSize: Qt.size(Math.max(16, Math.ceil(width * 1.5)), Math.max(16, Math.ceil(height * 1.5)))
    }

    // ---- Klippa (och skär i havet) -----------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: sprite.kind === "rock" && sprite.rockStyle !== "ship" && sprite.rockStyle !== "crystal"
        radius: Math.min(width, height) * (sprite.rockStyle === "crater" ? 0.35 : 0.08)
        color: sprite.moon ? "#86878E" : "#76716A"
        border.color: "#4E4A44"; border.width: 2
        Rectangle { width: parent.width
                    height: sprite.rockStyle === "isle" ? Math.max(4, sprite.ppm * 0.22) : Math.max(4, parent.height * (sprite.winter ? 0.16 : 0.1))
                    radius: parent.radius
                    color: sprite.rockStyle === "isle" ? "#D9B97A" : sprite.winter ? "#F4F8FB"
                           : sprite.moon ? "#C4C5CC"
                           : sprite.cave ? "#5A4A66" : "#5E8F4A" }
        Rectangle { x: parent.width * 0.2; y: parent.height * 0.4; width: parent.width * 0.25; height: parent.height * 0.18; radius: height / 2; color: "#6A665F" }
        Rectangle { x: parent.width * 0.6; y: parent.height * 0.62; width: parent.width * 0.2; height: parent.height * 0.14; radius: height / 2; color: "#6A665F" }
    }

    // ---- Troll och kottar -------------------------------------------------
    Image {
        anchors.fill: parent
        visible: sprite.isCircle
        smooth: true
        sourceSize: Qt.size(Math.max(32, Math.ceil(parent.width * 1.5)), Math.max(32, Math.ceil(parent.width * 1.5)))
        source: !sprite.body ? ""
                : sprite.kind === "troll" ? "../assets/troll-" + sprite.body.data.type
                                            + ((sprite.body.data.type === "small" || sprite.body.data.type === "medium")
                                               ? (sprite.winter ? "-winter" : sprite.sea ? "-sea" : sprite.cave ? "-cave" : sprite.moon ? "-moon" : sprite.candy ? "-candy" : "") : "")
                                            + ".svg"
                : sprite.kind === "cone" ? "../assets/cone-" + sprite.body.data.type + ".svg" : ""
    }
    Image {
        anchors.fill: parent
        visible: sprite.kind === "troll" && sprite.damage > 0.3
        source: visible ? "../assets/hurt.svg" : ""
        sourceSize: Qt.size(Math.max(32, Math.ceil(parent.width * 1.5)), Math.max(32, Math.ceil(parent.width * 1.5)))
    }

    // ---- Bubbelhjälm (trollen på månen) -----------------------------------
    Rectangle {
        visible: sprite.kind === "troll" && sprite.helmet
        width: sprite.width * 1.22; height: width; radius: width / 2
        x: (sprite.width - width) / 2; y: (sprite.height - height) / 2 - sprite.height * 0.04
        color: "#2EA8E0F8"
        border.color: "#D0F2FF"; border.width: Math.max(1.5, sprite.width * 0.035)
        Rectangle {
            x: parent.width * 0.2; y: parent.height * 0.12
            width: parent.width * 0.3; height: parent.height * 0.14; radius: height / 2
            rotation: -30
            color: "#FFFFFF"; opacity: 0.75
        }
        Rectangle {
            x: parent.width * 0.72; y: parent.height * 0.62
            width: parent.width * 0.08; height: width; radius: width / 2
            color: "#FFFFFF"; opacity: 0.6
        }
    }
}
