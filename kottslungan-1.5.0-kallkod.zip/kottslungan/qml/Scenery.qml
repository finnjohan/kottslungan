// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// Himmel, sol eller måne, kullar med granar och mark. groundY är markens
// y-koordinat i pixlar uppifrån. world är "forest" (sommar) eller "winter".
Item {
    id: scene
    property real groundY: height * 0.85
    property bool night: false
    property string world: "forest"
    readonly property bool winter: world === "winter"
    readonly property bool sea: world === "sea"
    readonly property bool cave: world === "cave"
    readonly property bool moon: world === "moon"
    readonly property bool candy: world === "candy"
    // Grottan: takets underkant i pixlar uppifrån
    property real ceilingY: height * 0.14
    // Havet: var stranden slutar (pixlar från vänster). Negativt = ingen strand.
    property real shoreX: width * 0.2
    readonly property bool animate: scene.visible && Qt.application.state === Qt.ApplicationActive

    Rectangle {
        id: sky
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: scene.candy ? (scene.night ? "#2A1240" : "#F7C6DE")
                                               : scene.moon ? (scene.night ? "#000002" : "#05070F")
                                               : scene.cave ? (scene.night ? "#0C0814" : "#3A2A4A")
                                               : scene.winter ? (scene.night ? "#071A2B" : "#A9C9E2")
                                               : scene.sea ? (scene.night ? "#0A1636" : "#5FB2E8")
                                               : (scene.night ? "#0E1A33" : "#7EC3EC") }
            GradientStop { position: 0.75; color: scene.candy ? (scene.night ? "#6A2A6E" : "#FFF1E0")
                                                  : scene.moon ? (scene.night ? "#0A0E1E" : "#1B2440")
                                                  : scene.cave ? (scene.night ? "#22163A" : "#6A4A6E")
                                                  : scene.winter ? (scene.night ? "#1D3B4F" : "#EEF4F9")
                                                  : scene.sea ? (scene.night ? "#3A3B66" : "#FCE9C8")
                                                  : (scene.night ? "#2C3A5C" : "#D6EEF8") }
        }
    }

    // Norrsken på vinterkvällen: mjuka band som sakta skiftar
    Item {
        id: aurora
        visible: scene.winter && scene.night
        anchors.fill: parent
        property real t: 0
        NumberAnimation on t { from: 0; to: 2 * Math.PI; duration: 14000; loops: Animation.Infinite
                               running: aurora.visible && Qt.application.state === Qt.ApplicationActive }
        Repeater {
            model: 3
            Rectangle {
                width: scene.width * (0.7 - index * 0.12)
                height: scene.height * 0.09
                radius: height / 2
                x: scene.width * (0.08 + index * 0.17) + Math.sin(aurora.t + index * 1.7) * scene.width * 0.03
                y: scene.height * (0.12 + index * 0.08)
                rotation: -8 + index * 5
                opacity: 0.32 + 0.14 * Math.sin(aurora.t * 2 + index)
                gradient: Gradient {
                    GradientStop { position: 0; color: "transparent" }
                    GradientStop { position: 0.5; color: index === 1 ? "#7AF2C0" : "#48D7A0" }
                    GradientStop { position: 1; color: "transparent" }
                }
            }
        }
    }

    // Sol eller måne (vintersolen står lågt och är blek)
    Rectangle {
        visible: !scene.cave && !scene.moon && !scene.candy
        x: parent.width * 0.78; y: parent.height * (scene.winter && !scene.night ? 0.22 : 0.1)
        width: Math.min(parent.width, parent.height) * 0.12; height: width; radius: width / 2
        color: scene.night ? "#F2EBC8" : (scene.winter ? "#FFE9B0" : "#FFD95A")
        opacity: scene.night ? 0.9 : 1
    }
    Rectangle {
        visible: scene.night && !scene.cave && !scene.moon && !scene.candy
        x: parent.width * 0.78 + width * 0.35; y: parent.height * 0.1 - width * 0.12
        width: Math.min(parent.width, parent.height) * 0.12; height: width; radius: width / 2
        color: scene.winter ? "#0B2032" : "#13213D"
    }
    Repeater {
        model: scene.night && !scene.cave ? (scene.winter ? 30 : 18) : 0
        Rectangle {
            width: 2; height: 2; radius: 1; color: "#FFFFFF"; opacity: 0.6 + (index % 3) * 0.13
            x: (index * 137) % scene.width; y: (index * 59) % (scene.groundY * 0.45)
        }
    }
    // ---- Trollen på månen --------------------------------------------------------
    // Stjärnor (alltid, ingen luft som skymmer), några som blinkar, och jorden
    Repeater {
        model: scene.moon ? 70 : 0
        Rectangle {
            readonly property real s: index % 7 === 0 ? 3 : (index % 3 === 0 ? 2 : 1.5)
            width: s; height: s; radius: s / 2; color: index % 5 === 0 ? "#CFE3FF" : "#FFFFFF"
            x: (index * 137.5) % scene.width; y: (index * 61.3) % (scene.groundY * 0.7)
            opacity: 0.5 + (index % 4) * 0.15
            SequentialAnimation on opacity {
                running: scene.moon && scene.animate && index % 6 === 0
                loops: Animation.Infinite
                NumberAnimation { to: 0.15; duration: 900 + index * 23 }
                NumberAnimation { to: 1; duration: 900 + index * 23 }
            }
        }
    }
    Image {
        visible: scene.moon
        source: visible ? "../assets/earth.svg" : ""
        readonly property real size: Math.min(scene.width, scene.height) * 0.17
        width: size; height: size
        x: scene.width * 0.72; y: scene.height * 0.07
        sourceSize: Qt.size(256, 256)
    }
    // Ett stjärnfall då och då
    Rectangle {
        id: shooting
        visible: scene.moon && t > 0 && t < 1
        property real t: 0
        width: scene.width * 0.08; height: 2; radius: 1
        rotation: 18
        x: scene.width * (0.15 + 0.4 * t); y: scene.height * (0.08 + 0.12 * t)
        opacity: 1 - t
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0; color: "transparent" }
            GradientStop { position: 1; color: "#FFFFFF" }
        }
        SequentialAnimation on t {
            running: scene.moon && scene.animate
            loops: Animation.Infinite
            PauseAnimation { duration: 6500 }
            NumberAnimation { from: 0; to: 1; duration: 900 }
            PropertyAction { value: 0 }
        }
    }
    Image {
        visible: scene.moon
        source: visible ? "../assets/moon-far.svg" : ""
        width: parent.width
        height: parent.height * 0.36
        y: scene.groundY - height + 2
        sourceSize: Qt.size(1600, 300)
        opacity: scene.night ? 0.7 : 1
    }

    Image {
        visible: !scene.sea && !scene.cave && !scene.moon && !scene.candy
        source: scene.winter ? "../assets/hills-winter.svg" : "../assets/hills.svg"
        width: parent.width
        height: parent.height * 0.36
        y: scene.groundY - height + 2
        sourceSize: Qt.size(1600, 300)
        opacity: scene.night ? (scene.winter ? 0.55 : 0.45) : 1
    }
    // ---- Trollgrottan ------------------------------------------------------------
    // Bakre grottväggar med stalagmiter och kristaller
    Image {
        visible: scene.cave
        source: visible ? "../assets/cave-back.svg" : ""
        width: parent.width
        height: parent.height * 0.5
        y: scene.groundY - height + 2
        sourceSize: Qt.size(1600, 400)
        opacity: scene.night ? 0.8 : 1
    }
    // Discoljus: färgade ljuskäglor som sveper fram och tillbaka
    Item {
        id: lights
        visible: scene.cave
        anchors.fill: parent
        property real t: 0
        NumberAnimation on t { from: 0; to: 2 * Math.PI; duration: 9000; loops: Animation.Infinite
                               running: lights.visible && scene.animate }
        Repeater {
            model: scene.cave ? 4 : 0
            Rectangle {
                readonly property var colors: ["#FF5FD2", "#2EC4D6", "#FFE14A", "#7CFF8A"]
                width: scene.width * 0.07
                height: scene.groundY - scene.ceilingY
                x: scene.width * (0.2 + index * 0.2) - width / 2
                y: scene.ceilingY
                transformOrigin: Item.Top
                rotation: 28 * Math.sin(lights.t * (index % 2 === 0 ? 1 : -1) + index * 1.3)
                opacity: scene.night ? 0.3 : 0.22
                gradient: Gradient {
                    GradientStop { position: 0; color: colors[index] }
                    GradientStop { position: 1; color: "transparent" }
                }
            }
        }
        // Ljusprickar från discokulan som glider över väggarna
        Repeater {
            model: scene.cave ? 16 : 0
            Rectangle {
                readonly property var colors: ["#FFFFFF", "#FF8FE0", "#8FF0FF", "#FFF59A"]
                readonly property real s: Math.max(3, scene.height * 0.012)
                width: s; height: s; radius: s / 2
                color: colors[index % 4]
                opacity: 0.7
                x: ((index * 0.137 + lights.t / (2 * Math.PI)) % 1) * scene.width
                y: scene.ceilingY + ((index * 0.29) % 1) * (scene.groundY - scene.ceilingY) * 0.8
            }
        }
    }

    // ---- Havet ----------------------------------------------------------------
    // Fjärran hav med öar, fyr och segelbåt
    Image {
        visible: scene.sea
        source: visible ? "../assets/sea-far.svg" : ""
        width: parent.width
        height: parent.height * 0.36
        y: scene.groundY - height + 2
        sourceSize: Qt.size(1600, 300)
        opacity: scene.night ? 0.55 : 1
    }
    // Måsar som seglar över himlen
    Repeater {
        model: scene.sea ? 3 : 0
        Image {
            id: gull
            source: "../assets/gull.svg"
            width: scene.height * (0.07 - index * 0.012); height: width * 0.4
            sourceSize: Qt.size(120, 48)
            opacity: scene.night ? 0.5 : 0.95
            property real t: index * 0.37
            x: -width + (t % 1) * (scene.width + 2 * width)
            y: scene.groundY * (0.18 + index * 0.13) + Math.sin(t * 25 + index) * scene.height * 0.02
            transform: Scale { origin.y: gull.height / 2; yScale: 0.75 + 0.25 * Math.sin(gull.t * 160) }
            NumberAnimation on t { from: index * 0.37; to: 1 + index * 0.37; duration: 26000 + index * 7000
                                   loops: Animation.Infinite; running: scene.animate }
        }
    }
    // Vattnet framför stranden och vågor som rör sig
    Rectangle {
        visible: scene.sea
        x: Math.max(0, scene.shoreX); y: scene.groundY
        width: parent.width - x; height: parent.height - y
        gradient: Gradient {
            GradientStop { position: 0; color: scene.night ? "#1E4466" : "#2F7DB4" }
            GradientStop { position: 1; color: scene.night ? "#0E2238" : "#1A4E7A" }
        }
    }
    Waves {
        visible: scene.sea
        x: Math.max(0, scene.shoreX); width: parent.width - x
        height: Math.max(6, (parent.height - scene.groundY) * 0.14)
        y: scene.groundY - height * 0.45
        opacity: scene.night ? 0.5 : 0.9
        running: visible && scene.animate
        duration: 5200
    }
    // Månen speglar sig i vattnet
    Repeater {
        model: scene.sea && scene.night ? 6 : 0
        Rectangle {
            readonly property real w: Math.min(scene.width, scene.height) * (0.1 - index * 0.012)
            x: scene.width * 0.78 + Math.min(scene.width, scene.height) * 0.06 - w / 2
            y: scene.groundY + (index + 0.5) * (scene.height - scene.groundY) / 7
            width: w; height: 3; radius: 1.5
            color: "#F2EBC8"; opacity: 0.6
        }
    }
    // ---- Godisfabriken ---------------------------------------------------------
    // Kugghjul som snurrar högt upp
    Repeater {
        model: scene.candy ? 3 : 0
        Image {
            readonly property real s: scene.height * [0.22, 0.15, 0.18][index]
            source: "../assets/gear.svg"
            width: s; height: s
            sourceSize: Qt.size(160, 160)
            x: scene.width * [0.4, 0.5, 0.64][index] - s / 2
            y: scene.groundY * [0.3, 0.2, 0.26][index] - s / 2
            opacity: scene.night ? 0.55 : 0.85
            RotationAnimation on rotation {
                from: index === 1 ? 360 : 0; to: index === 1 ? 0 : 360
                duration: [16000, 11000, 14000][index]; loops: Animation.Infinite
                running: scene.animate
            }
        }
    }
    // Fabriksbyggnaderna med rör, skorstenar och jätteklubbor
    Image {
        visible: scene.candy
        source: visible ? "../assets/candy-factory.svg" : ""
        width: parent.width
        height: parent.height * 0.5
        y: scene.groundY - height + 2
        sourceSize: Qt.size(1600, 400)
        opacity: scene.night ? 0.6 : 1
    }
    // Neonskyltar som lyser på kvällen
    Repeater {
        model: scene.candy && scene.night ? 3 : 0
        Rectangle {
            readonly property var colors: ["#FF5FD2", "#2EC4D6", "#FFE14A"]
            width: scene.width * 0.08; height: scene.height * 0.035; radius: height / 2
            x: scene.width * [0.3, 0.55, 0.78][index]
            y: scene.groundY - scene.height * [0.36, 0.3, 0.38][index]
            color: "transparent"
            border.color: colors[index]; border.width: Math.max(2, height * 0.25)
            opacity: 0.6 + 0.4 * ((Math.floor(neonTimer.tick / (index + 1))) % 2)
        }
    }
    Timer { id: neonTimer; property int tick: 0; interval: 700; repeat: true
            running: scene.candy && scene.night && scene.animate; onTriggered: tick++ }
    // Löpband med godis som rullar förbi
    Item {
        visible: scene.candy
        clip: true
        width: parent.width
        height: scene.height * 0.06
        y: scene.groundY - height - scene.height * 0.05
        Item {
            id: belt
            height: parent.height
            readonly property real tile: height * 5
            width: parent.width + tile
            property real phase: 0
            x: -phase * tile
            Image {
                anchors.fill: parent
                source: "../assets/candy-belt.svg"
                fillMode: Image.Tile
                sourceSize: Qt.size(Math.max(8, Math.round(belt.tile)), Math.max(2, Math.round(belt.height)))
            }
            NumberAnimation on phase { from: 1; to: 0; duration: 3000; loops: Animation.Infinite
                                       running: scene.candy && scene.animate }
        }
    }

    // Marken: gräs och jord, snö, eller sand vid havet
    Rectangle {
        y: scene.groundY
        width: scene.sea ? Math.max(0, scene.shoreX) : parent.width; height: parent.height - y
        color: scene.winter ? (scene.night ? "#7F93A6" : "#D3E0EA")
               : scene.candy ? (scene.night ? "#7A3A6A" : "#F2A7C8")
               : scene.moon ? (scene.night ? "#4A4B52" : "#8E8F96")
               : scene.cave ? (scene.night ? "#1A1424" : "#3E3046")
               : scene.sea ? (scene.night ? "#6E5E44" : "#D9B97A")
               : (scene.night ? "#3B2A1E" : "#6B4A2E")
        Rectangle {
            width: parent.width; height: Math.max(6, parent.height * (scene.winter ? 0.25 : 0.18))
            color: scene.winter ? (scene.night ? "#B4C6D6" : "#FFFFFF")
                   : scene.candy ? (scene.night ? "#B884A8" : "#FFFFFF")
                   : scene.moon ? (scene.night ? "#6E6F78" : "#B9BAC1")
                   : scene.cave ? (scene.night ? "#3A2E4A" : "#5A4A66")
                   : scene.sea ? (scene.night ? "#8C7A5A" : "#F0D9A4")
                   : (scene.night ? "#2F5A33" : "#5FA04A")
        }
    }

    // Kratrar i månmarken
    Repeater {
        model: scene.moon ? 7 : 0
        Rectangle {
            readonly property real w: scene.width * (0.05 + (index % 3) * 0.025)
            x: scene.width * ((index * 0.153 + 0.03) % 1); y: scene.groundY + (scene.height - scene.groundY) * (0.3 + (index % 3) * 0.2)
            width: w; height: w * 0.18; radius: height / 2
            color: "#000000"; opacity: 0.18
        }
    }

    // Rutigt golv i godisfabriken
    Row {
        visible: scene.candy
        y: scene.groundY + Math.max(6, (scene.height - scene.groundY) * 0.18)
        Repeater {
            model: scene.candy ? 24 : 0
            Rectangle {
                width: scene.width / 24; height: (scene.height - scene.groundY) * 0.4
                color: index % 2 ? (scene.night ? "#9A4E86" : "#FFFFFF") : (scene.night ? "#6A2A5E" : "#F7C6DE")
            }
        }
    }

    // Snöfall: några flingor som sakta faller och vajar
    Repeater {
        model: scene.winter ? 28 : 0
        Rectangle {
            id: flake
            readonly property real speed: 0.6 + (index % 5) * 0.15
            readonly property real size: Math.max(2, scene.height * (0.006 + (index % 3) * 0.003))
            width: size; height: size; radius: size / 2
            color: "#FFFFFF"
            opacity: 0.85
            property real fall: (index * 0.137) % 1
            x: ((index * 211) % 1000) / 1000 * scene.width + Math.sin(fall * 12 + index) * scene.width * 0.015
            y: (fall % 1) * scene.groundY
            NumberAnimation on fall {
                from: (index * 0.137) % 1; to: 1 + (index * 0.137) % 1
                duration: 9000 / flake.speed; loops: Animation.Infinite
                running: scene.visible && Qt.application.state === Qt.ApplicationActive
            }
        }
    }

    // Dansgolv: rutor i marken som blinkar i takt
    Row {
        visible: scene.cave
        y: scene.groundY
        x: scene.width * 0.55
        Repeater {
            model: scene.cave ? 10 : 0
            Rectangle {
                readonly property var colors: ["#FF5FD2", "#2EC4D6", "#FFE14A", "#7CFF8A"]
                width: scene.width * 0.045; height: Math.max(4, (scene.height - scene.groundY) * 0.25)
                color: colors[(index + Math.floor(lights.t * 2)) % 4]
                opacity: 0.55 + 0.35 * ((index + Math.floor(lights.t * 3)) % 2)
                border.color: "#1A1424"; border.width: 1
            }
        }
    }
    // Grottans tak
    Image {
        visible: scene.cave
        source: visible ? "../assets/cave-ceiling.svg" : ""
        width: parent.width
        y: 0
        height: scene.ceilingY * 1.25
        sourceSize: Qt.size(1600, 400)
        fillMode: Image.Stretch
    }
}
