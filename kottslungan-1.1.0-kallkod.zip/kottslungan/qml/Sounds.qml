// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import QtMultimedia 5.12

// Bakgrundsljud (en loop per värld) och korta ljudeffekter.
// Alla ljud är skapade för spelet med tools/make_sounds.py.
Item {
    id: sounds
    property bool ambienceOn: true
    property bool effectsOn: true
    property string world: "forest"            // "" = inget bakgrundsljud
    readonly property bool active: Qt.application.state === Qt.ApplicationActive
    readonly property bool shouldPlay: ambienceOn && active && world !== ""

    Audio {
        id: ambience
        source: sounds.world !== "" ? Qt.resolvedUrl("../assets/sounds/ambience-" + sounds.world + ".ogg") : ""
        loops: Audio.Infinite
        volume: 0.45
        onSourceChanged: if (sounds.shouldPlay) play()
    }
    onShouldPlayChanged: shouldPlay ? ambience.play() : ambience.pause()
    Component.onCompleted: if (shouldPlay) ambience.play()

    readonly property var names: ["launch", "hit", "break-wood", "break-stone", "break-ice", "break-snow",
                                  "troll", "ability", "burst", "win", "lose"]
    property var effects: ({})
    property double lastHit: 0

    Component {
        id: effectComp
        SoundEffect { volume: 0.7 }
    }

    function play(name) {
        if (!effectsOn) return
        // Många stötar på en gång blir bara brus: högst en smäll per 90 ms
        if (name === "hit") {
            var now = Date.now()
            if (now - lastHit < 90) return
            lastHit = now
        }
        var e = effects[name]
        if (!e) {
            e = effectComp.createObject(sounds, { source: Qt.resolvedUrl("../assets/sounds/" + name + ".wav") })
            effects[name] = e
        }
        e.play()
    }

    // Läs in effekterna i förväg så att första skottet inte hackar
    Timer {
        interval: 500; running: true
        onTriggered: {
            for (var i = 0; i < sounds.names.length; i++) {
                var n = sounds.names[i]
                if (!sounds.effects[n])
                    sounds.effects[n] = effectComp.createObject(sounds, { source: Qt.resolvedUrl("../assets/sounds/" + n + ".wav") })
            }
        }
    }
}
