// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Levels.js" as Levels

// En värld i banvalet: en liten bild av landskapet med namn och stjärnor,
// och under den ett rutnät med världens banor.
Column {
    id: section
    property var world: null
    readonly property string worldId: world ? world.id : ""
    readonly property bool open: world !== null && root.unlocked(world.first)
    spacing: units.gu(1)

    Item {
        width: parent.width
        height: units.gu(8)
        Rectangle {
            id: bannerMask
            anchors.fill: parent
            radius: units.gu(1.5)
            clip: true
            color: "transparent"
            Scenery {
                width: parent.width; height: units.gu(16)
                y: parent.height - height * 0.88
                groundY: height * 0.84
                night: root.isDark
                world: section.worldId
                opacity: section.open ? 1 : 0.55
            }
        }
        Label {
            anchors { left: parent.left; leftMargin: units.gu(2); verticalCenter: parent.verticalCenter }
            text: section.world ? root.tr(section.world.name) : ""
            textSize: Label.Large
            font.weight: Font.Bold
            color: "#FFFFFF"
            style: Text.Outline; styleColor: section.worldId === "winter" ? "#2A4A66" : "#2E5A2A"
        }
        Row {
            anchors { right: parent.right; rightMargin: units.gu(2); verticalCenter: parent.verticalCenter }
            spacing: units.gu(0.8)
            Icon {
                anchors.verticalCenter: parent.verticalCenter
                width: units.gu(2.6); height: width
                name: section.open ? "starred" : "lock"
                color: section.open ? "#F2B705" : "#FFFFFF"
            }
            Label {
                anchors.verticalCenter: parent.verticalCenter
                text: !section.world ? ""
                      : section.open ? root.worldStars(section.world) + " / " + section.world.count * 3
                      : root.tr("Clear level %1 to open").arg(section.world.first - 1)
                font.weight: Font.Bold
                color: "#FFFFFF"
                style: Text.Outline; styleColor: section.worldId === "winter" ? "#2A4A66" : "#2E5A2A"
            }
        }
    }

    Grid {
        id: grid
        width: parent.width
        columns: Math.max(3, Math.floor(width / units.gu(16)))
        readonly property real cellW: width / columns
        Repeater {
            model: section.world ? section.world.count : 0
            Item {
                width: grid.cellW; height: units.gu(14)
                readonly property int n: section.world.first + index
                readonly property bool open: root.unlocked(n)
                readonly property bool winter: section.worldId === "winter"
                AbstractButton {
                    anchors { fill: parent; margins: units.gu(0.8) }
                    enabled: parent.open
                    onClicked: root.playLevel(parent.n)
                    Rectangle {
                        anchors.fill: parent
                        radius: units.gu(1.5)
                        color: !parent.parent.open ? theme.palette.normal.base
                               : parent.parent.winter ? (root.isDark ? "#24404F" : "#E4F0F8")
                               : (root.isDark ? "#2F4A30" : "#E3F1DA")
                        border.color: !parent.parent.open ? theme.palette.normal.base
                                      : parent.parent.winter ? "#5E8FB0" : "#5E8F4A"
                        border.width: units.dp(2)
                        opacity: parent.parent.open ? 1 : 0.6
                    }
                    Column {
                        anchors.centerIn: parent
                        width: parent.width - units.gu(1)
                        spacing: units.gu(0.4)
                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: parent.parent.parent.n
                            textSize: Label.XLarge
                            font.weight: Font.Bold
                        }
                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                            text: root.tr(Levels.list[parent.parent.parent.n - 1].name)
                            textSize: Label.Small
                        }
                        Item {
                            anchors.horizontalCenter: parent.horizontalCenter
                            readonly property int n: parent.parent.parent.n
                            width: lock.visible ? lock.width : levelStars.width
                            height: units.gu(2.2)
                            Stars { id: levelStars; visible: !lock.visible; count: root.starsFor(parent.n); size: units.gu(2.2) }
                            Icon { id: lock; visible: !root.unlocked(parent.n); name: "lock"; width: units.gu(2.2); height: width
                                   color: theme.palette.normal.backgroundSecondaryText }
                        }
                    }
                }
            }
        }
    }
}
