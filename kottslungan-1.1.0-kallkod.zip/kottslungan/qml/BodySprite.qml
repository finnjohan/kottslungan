// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// Ritar en kropp ur fysiken: block, troll, klippa eller kotte.
Item {
    id: sprite
    property var body: null
    property real ppm: 30            // pixlar per meter
    property real originY: 0         // pixelrad för y = 0
    property real damage: 0          // 0..1, hur skadad
    property bool winter: false      // vinterskogen: snö på klippor, troll med mössa
    readonly property string kind: body ? body.kind : ""
    readonly property bool isCircle: body && body.shape === "circle"

    width: body ? (isCircle ? 2 * body.r : 2 * body.hw) * ppm : 0
    height: body ? (isCircle ? 2 * body.r : 2 * body.hh) * ppm : 0

    function sync() {
        if (!body) return
        x = body.x * ppm - width / 2
        y = originY - body.y * ppm - height / 2
        rotation = -body.angle * 180 / Math.PI
    }

    function refresh() {
        if (body && body.data && body.data.maxHp) damage = Math.max(0, 1 - body.data.hp / body.data.maxHp)
    }

    // ---- Block ------------------------------------------------------------
    Rectangle {
        id: blockRect
        anchors.fill: parent
        visible: sprite.kind === "block"
        readonly property string mat: sprite.body && sprite.body.data && sprite.body.data.mat ? sprite.body.data.mat : ""
        radius: Math.min(width, height) * 0.12
        border.width: Math.max(1, Math.min(width, height) * 0.08)
        border.color: mat === "wood" ? "#6E4520" : mat === "stone" ? "#55595F" : mat === "snow" ? "#A9BCCB" : "#7DBDE6"
        gradient: Gradient {
            GradientStop { position: 0; color: blockRect.mat === "wood" ? "#C08A50" : blockRect.mat === "stone" ? "#A9ADB3"
                                               : blockRect.mat === "snow" ? "#FFFFFF" : "#E4F6FF" }
            GradientStop { position: 1; color: blockRect.mat === "wood" ? "#97612F" : blockRect.mat === "stone" ? "#7C8086"
                                               : blockRect.mat === "snow" ? "#DCE7EF" : "#A9DCF7" }
        }
        opacity: mat === "ice" ? 0.85 : 1
        // Ådring längs den långa sidan
        Repeater {
            model: blockRect.mat === "wood" ? 2 : 0
            Rectangle {
                readonly property bool horizontal: sprite.width >= sprite.height
                color: "#7A4C24"; opacity: 0.55
                x: horizontal ? sprite.width * 0.1 : sprite.width * (0.33 + index * 0.33) - width / 2
                y: horizontal ? sprite.height * (0.33 + index * 0.33) - height / 2 : sprite.height * 0.1
                width: horizontal ? sprite.width * 0.8 : Math.max(1, sprite.width * 0.07)
                height: horizontal ? Math.max(1, sprite.height * 0.07) : sprite.height * 0.8
            }
        }
        // Ett tunt snölager på trä och sten i vinterskogen
        Rectangle {
            visible: sprite.winter && (blockRect.mat === "wood" || blockRect.mat === "stone") && sprite.width > sprite.height
            width: parent.width; height: Math.max(2, parent.height * 0.3)
            radius: blockRect.radius
            color: "#F6FAFD"
        }
        Image {
            anchors.fill: parent
            source: "../assets/crack.svg"
            opacity: sprite.damage > 0.35 ? Math.min(1, sprite.damage * 1.3) : 0
            sourceSize: Qt.size(128, 128)
        }
    }

    // ---- Klippa -----------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: sprite.kind === "rock"
        radius: Math.min(width, height) * 0.08
        color: "#76716A"
        border.color: "#4E4A44"; border.width: 2
        Rectangle { width: parent.width; height: Math.max(4, parent.height * (sprite.winter ? 0.16 : 0.1)); radius: parent.radius
                    color: sprite.winter ? "#F4F8FB" : "#5E8F4A" }
        Rectangle { x: parent.width * 0.2; y: parent.height * 0.4; width: parent.width * 0.25; height: parent.height * 0.18; radius: height / 2; color: "#6A665F" }
        Rectangle { x: parent.width * 0.6; y: parent.height * 0.62; width: parent.width * 0.2; height: parent.height * 0.14; radius: height / 2; color: "#6A665F" }
    }

    // ---- Troll och kottar -------------------------------------------------
    Image {
        anchors.fill: parent
        visible: sprite.isCircle
        smooth: true
        sourceSize: Qt.size(Math.max(32, Math.ceil(parent.width * 1.5)), Math.max(32, Math.ceil(parent.width * 1.5)))
        source: !sprite.body ? ""
                : sprite.kind === "troll" ? "../assets/troll-" + sprite.body.data.type
                                            + (sprite.winter && (sprite.body.data.type === "small" || sprite.body.data.type === "medium") ? "-winter" : "")
                                            + ".svg"
                : sprite.kind === "cone" ? "../assets/cone-" + sprite.body.data.type + ".svg" : ""
    }
    Image {
        anchors.fill: parent
        visible: sprite.kind === "troll" && sprite.damage > 0.3
        source: visible ? "../assets/hurt.svg" : ""
        sourceSize: Qt.size(Math.max(32, Math.ceil(parent.width * 1.5)), Math.max(32, Math.ceil(parent.width * 1.5)))
    }
}
