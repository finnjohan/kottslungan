// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// Himmel, sol eller måne, kullar med granar och mark. groundY är markens
// y-koordinat i pixlar uppifrån. world är "forest" (sommar) eller "winter".
Item {
    id: scene
    property real groundY: height * 0.85
    property bool night: false
    property string world: "forest"
    readonly property bool winter: world === "winter"

    Rectangle {
        id: sky
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: scene.winter ? (scene.night ? "#071A2B" : "#A9C9E2")
                                                            : (scene.night ? "#0E1A33" : "#7EC3EC") }
            GradientStop { position: 0.75; color: scene.winter ? (scene.night ? "#1D3B4F" : "#EEF4F9")
                                                               : (scene.night ? "#2C3A5C" : "#D6EEF8") }
        }
    }

    // Norrsken på vinterkvällen: mjuka band som sakta skiftar
    Item {
        id: aurora
        visible: scene.winter && scene.night
        anchors.fill: parent
        property real t: 0
        NumberAnimation on t { from: 0; to: 2 * Math.PI; duration: 14000; loops: Animation.Infinite
                               running: aurora.visible && Qt.application.state === Qt.ApplicationActive }
        Repeater {
            model: 3
            Rectangle {
                width: scene.width * (0.7 - index * 0.12)
                height: scene.height * 0.09
                radius: height / 2
                x: scene.width * (0.08 + index * 0.17) + Math.sin(aurora.t + index * 1.7) * scene.width * 0.03
                y: scene.height * (0.12 + index * 0.08)
                rotation: -8 + index * 5
                opacity: 0.32 + 0.14 * Math.sin(aurora.t * 2 + index)
                gradient: Gradient {
                    GradientStop { position: 0; color: "transparent" }
                    GradientStop { position: 0.5; color: index === 1 ? "#7AF2C0" : "#48D7A0" }
                    GradientStop { position: 1; color: "transparent" }
                }
            }
        }
    }

    // Sol eller måne (vintersolen står lågt och är blek)
    Rectangle {
        x: parent.width * 0.78; y: parent.height * (scene.winter && !scene.night ? 0.22 : 0.1)
        width: Math.min(parent.width, parent.height) * 0.12; height: width; radius: width / 2
        color: scene.night ? "#F2EBC8" : (scene.winter ? "#FFE9B0" : "#FFD95A")
        opacity: scene.night ? 0.9 : 1
    }
    Rectangle {
        visible: scene.night
        x: parent.width * 0.78 + width * 0.35; y: parent.height * 0.1 - width * 0.12
        width: Math.min(parent.width, parent.height) * 0.12; height: width; radius: width / 2
        color: scene.winter ? "#0B2032" : "#13213D"
    }
    Repeater {
        model: scene.night ? (scene.winter ? 30 : 18) : 0
        Rectangle {
            width: 2; height: 2; radius: 1; color: "#FFFFFF"; opacity: 0.6 + (index % 3) * 0.13
            x: (index * 137) % scene.width; y: (index * 59) % (scene.groundY * 0.45)
        }
    }
    Image {
        source: scene.winter ? "../assets/hills-winter.svg" : "../assets/hills.svg"
        width: parent.width
        height: parent.height * 0.36
        y: scene.groundY - height + 2
        sourceSize: Qt.size(1600, 300)
        opacity: scene.night ? (scene.winter ? 0.55 : 0.45) : 1
    }
    // Marken: gräs och jord, eller snö
    Rectangle {
        y: scene.groundY
        width: parent.width; height: parent.height - y
        color: scene.winter ? (scene.night ? "#7F93A6" : "#D3E0EA") : (scene.night ? "#3B2A1E" : "#6B4A2E")
        Rectangle {
            width: parent.width; height: Math.max(6, parent.height * (scene.winter ? 0.25 : 0.18))
            color: scene.winter ? (scene.night ? "#B4C6D6" : "#FFFFFF") : (scene.night ? "#2F5A33" : "#5FA04A")
        }
    }

    // Snöfall: några flingor som sakta faller och vajar
    Repeater {
        model: scene.winter ? 28 : 0
        Rectangle {
            id: flake
            readonly property real speed: 0.6 + (index % 5) * 0.15
            readonly property real size: Math.max(2, scene.height * (0.006 + (index % 3) * 0.003))
            width: size; height: size; radius: size / 2
            color: "#FFFFFF"
            opacity: 0.85
            property real fall: (index * 0.137) % 1
            x: ((index * 211) % 1000) / 1000 * scene.width + Math.sin(fall * 12 + index) * scene.width * 0.015
            y: (fall % 1) * scene.groundY
            NumberAnimation on fall {
                from: (index * 0.137) % 1; to: 1 + (index * 0.137) % 1
                duration: 9000 / flake.speed; loops: Animation.Infinite
                running: scene.visible && Qt.application.state === Qt.ApplicationActive
            }
        }
    }
}
