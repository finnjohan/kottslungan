.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Banorna som data. y är underkanten (marken ligger på y = 0).
// Hjälpfunktionerna bygger stolpar, bjälkar, block och troll.

var T = 0.25        // tjocklek på plankor

function col(x, y, h, mat) { return { mat: mat || "wood", x: x, y: y, w: mat === "stone" ? 0.35 : T, h: h } }
function beam(x, y, w, mat) { return { mat: mat || "wood", x: x, y: y, w: w, h: mat === "stone" ? 0.35 : T } }
function block(x, y, w, h, mat) { return { mat: mat || "wood", x: x, y: y, w: w, h: h } }
function troll(x, y, size) { return { troll: size || "small", x: x, y: y } }
function rock(x, y, w, h) { return { rock: true, x: x, y: y, w: w, h: h } }

// En våning: två stolpar och en bjälke. Returnerar delarna och höjden ovanpå.
function floor(out, x, y, width, height, mat, beamMat) {
    var half = width / 2 - T / 2
    var c = col(x - half, y, height, mat), d = col(x + half, y, height, mat)
    out.push(c, d)
    var b = beam(x, y + height, width + 0.2, beamMat || mat)
    out.push(b)
    return y + height + b.h
}

function level(name, cones, stars, build, world) {
    var items = []
    build(items)
    return { name: name, cones: cones, stars: stars, items: items, world: world || "forest" }
}
function winter(name, cones, stars, build) { return level(name, cones, stars, build, "winter") }

// Världarna i den ordning de spelas. first är numret på första banan.
var worlds = [
    { id: "forest", name: "Summer forest", first: 1, count: 10 },
    { id: "winter", name: "Winter forest", first: 11, count: 10 }
]

function worldOf(n) {
    for (var i = worlds.length - 1; i >= 0; i--) if (n >= worlds[i].first) return worlds[i]
    return worlds[0]
}

var list = [
    // 1. En liten koja
    level("First cone", ["spruce", "spruce", "spruce"], [0, 10000, 15000], function (o) {
        var top = floor(o, 22, 0, 2.4, 2.0, "wood")
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "small"))
    }),

    // 2. Två kojor
    level("Two huts", ["spruce", "spruce", "spruce"], [0, 13000, 18000], function (o) {
        floor(o, 19, 0, 2.2, 1.8, "wood")
        o.push(troll(19, 0, "small"))
        var top = floor(o, 25, 0, 2.6, 2.4, "wood")
        o.push(troll(25, 0, "medium"))
        o.push(troll(25, top, "small"))
    }),

    // 3. Ett högt torn
    level("Watchtower", ["spruce", "pine", "spruce"], [0, 15000, 22000], function (o) {
        var y = floor(o, 23, 0, 2.4, 2.0, "wood")
        o.push(troll(23, 0, "small"))
        y = floor(o, 23, y, 2.4, 2.0, "wood")
        o.push(troll(23, y - 2.0 - T, "medium"))
        y = floor(o, 23, y, 2.0, 1.6, "wood")
        o.push(troll(23, y, "small"))
    }),

    // 4. Ispalatset
    level("Ice palace", ["pine", "pine", "spruce"], [0, 14000, 20000], function (o) {
        o.push(block(20, 0, 0.6, 2.4, "ice"), block(22.4, 0, 0.6, 2.4, "ice"))
        o.push(beam(21.2, 2.4, 3.2, "ice"))
        o.push(troll(21.2, 0, "medium"))
        o.push(block(24.8, 0, 0.6, 2.4 + T, "ice"))
        o.push(beam(23.6, 2.4 + T, 3.2, "ice"))
        o.push(troll(23.6, 0, "small"))
        o.push(block(21.2, 2.4 + T, 0.6, 1.4, "ice"), block(23.6, 2.65 + T, 0.6, 1.2, "ice"))
        o.push(troll(22.4, 2.65 + T, "small"))
    }),

    // 5. Stenbunkern
    level("Stone bunker", ["acorn", "spruce", "acorn"], [0, 13000, 18000], function (o) {
        o.push(block(21, 0, 0.6, 1.6, "stone"), block(24, 0, 0.6, 1.6, "stone"))
        o.push(beam(22.5, 1.6, 3.8, "wood"))
        o.push(troll(22.5, 0, "large"))
        o.push(block(22.5, 1.6 + T, 1.0, 1.0, "wood"))
        o.push(troll(22.5, 2.6 + T, "small"))
    }),

    // 6. På klippan
    level("On the cliff", ["chestnut", "spruce", "pine"], [0, 14000, 20000], function (o) {
        o.push(rock(24, 0, 6, 3))
        var y = floor(o, 23, 3, 2.2, 2.0, "wood")
        o.push(troll(23, 3, "medium"))
        y = floor(o, 25.2, 3, 2.0, 1.6, "ice")
        o.push(troll(25.2, 3, "small"))
        o.push(troll(23, 5.0 + T, "small"))
    }),

    // 7. Två torn och en bro
    level("The bridge", ["spruce", "pine", "acorn", "spruce"], [0, 23000, 32000], function (o) {
        var y1 = floor(o, 19.5, 0, 2.0, 2.4, "wood")
        var top1 = floor(o, 19.5, y1, 1.6, 1.4, "wood")
        o.push(troll(19.5, 0, "small"))
        var y2 = floor(o, 26.5, 0, 2.0, 2.4, "stone", "wood")
        floor(o, 26.5, y2, 1.6, 1.4, "wood")
        o.push(troll(26.5, 0, "medium"))
        o.push(beam(23, top1, 7.6, "wood"))
        o.push(troll(23, top1 + T, "small"))
        o.push(troll(23, 0, "large"))
    }),

    // 8. Pyramiden
    level("Pyramid", ["pine", "chestnut", "spruce"], [0, 13000, 18000], function (o) {
        var s = 1.0, x0 = 20.5
        for (var row = 0; row < 4; row++)
            for (var i = 0; i < 6 - row; i++) {
                var mat = row === 0 ? "stone" : (row === 3 ? "ice" : "wood")
                o.push(block(x0 + row * s / 2 + i * s, row * (s - 0.02), s - 0.02, s - 0.02, mat))
            }
        o.push(troll(x0 + 1.5 * s + 1.0, 4 * (s - 0.02), "medium"))
        o.push(troll(x0 - 1.2, 0, "small"))
        o.push(troll(x0 + 6.4, 0, "small"))
    }),

    // 9. Fästningen
    level("Fortress", ["acorn", "chestnut", "pine", "spruce"], [0, 23000, 32000], function (o) {
        o.push(block(19.5, 0, 0.6, 3.0, "stone"))
        var y = floor(o, 22, 0, 3.0, 2.2, "wood")
        o.push(troll(22, 0, "elder"))
        y = floor(o, 22, y, 2.4, 1.8, "ice", "wood")
        o.push(troll(22, y - 1.8 - T, "small"))
        o.push(block(24.6, 0, 0.6, 3.0, "stone"))
        o.push(beam(25.8, 3.0, 2.8, "wood"))
        o.push(block(27, 0, 0.6, 3.0, "stone"))
        o.push(troll(25.8, 0, "medium"))
        o.push(troll(25.8, 3.0 + T, "small"))
    }),

    // 10. Trollens by
    level("Troll village", ["spruce", "pine", "acorn", "chestnut", "spruce"], [0, 32000, 46000], function (o) {
        floor(o, 17.5, 0, 2.0, 1.8, "wood")
        o.push(troll(17.5, 0, "small"))
        o.push(rock(22.5, 0, 3, 1.5))
        var y = floor(o, 22.5, 1.5, 2.4, 2.0, "stone", "wood")
        o.push(troll(22.5, 1.5, "large"))
        y = floor(o, 22.5, y, 2.0, 1.6, "wood")
        o.push(troll(22.5, y - 1.6 - T, "small"))
        o.push(troll(22.5, y, "medium"))
        var y3 = floor(o, 27.5, 0, 2.4, 2.6, "ice", "wood")
        floor(o, 27.5, y3, 2.0, 1.6, "ice", "wood")
        o.push(troll(27.5, 0, "elder"))
        o.push(troll(27.5, y3, "small"))
    }),
    // ---- Vinterskogen ------------------------------------------------------

    // 11. Första snön
    winter("First snow", ["spruce", "spruce", "spruce"], [0, 14000, 20000], function (o) {
        var top = floor(o, 22, 0, 2.4, 2.0, "wood", "snow")
        o.push(troll(22, 0, "small"))
        o.push(troll(22, top, "frost"))
        o.push(block(25.5, 0, 1.0, 1.0, "snow"), block(25.5, 1.0, 0.8, 0.8, "snow"))
        o.push(troll(25.5, 1.8, "small"))
    }),

    // 12. Igloon
    winter("The igloo", ["spruce", "pine", "spruce"], [0, 14000, 20000], function (o) {
        var x0 = 20.2, s = 0.8
        for (var r = 0; r < 2; r++) {
            o.push(block(x0 - r * 0.05, r * s, s, s, "snow"))
            o.push(block(x0 + 3.0 + r * 0.05, r * s, s, s, "snow"))
        }
        o.push(beam(x0 + 1.5, 2 * s, 4.0, "ice"))
        o.push(block(x0 + 0.8, 2 * s + T, 0.9, 0.7, "snow"), block(x0 + 2.2, 2 * s + T, 0.9, 0.7, "snow"))
        o.push(block(x0 + 1.5, 2 * s + T + 0.7, 1.6, 0.6, "snow"))
        o.push(troll(x0 + 1.5, 0, "medium"))
        o.push(troll(x0 + 1.5, 2 * s + T + 1.3, "frost"))
        o.push(troll(26.5, 0, "small"))
    }),

    // 13. Isen på sjön: hal mark och istorn
    winter("Frozen lake", ["pine", "spruce", "pine"], [0, 18000, 26000], function (o) {
        var y = floor(o, 20.5, 0, 2.2, 2.2, "ice")
        o.push(troll(20.5, 0, "frost"))
        o.push(troll(20.5, y, "small"))
        y = floor(o, 24.5, 0, 2.2, 1.6, "ice")
        y = floor(o, 24.5, y, 1.8, 1.6, "ice")
        o.push(troll(24.5, 0, "medium"))
        o.push(troll(24.5, y, "frost"))
    }),

    // 14. Snötrollets lya
    winter("Snow troll's den", ["acorn", "chestnut", "spruce"], [0, 12000, 17000], function (o) {
        o.push(rock(26.5, 0, 4, 1.2))
        o.push(block(20.8, 0, 0.6, 2.4, "stone"), block(24.2, 0, 0.6, 2.4, "stone"))
        o.push(beam(22.5, 2.4, 4.2, "wood"))
        o.push(block(22.5, 2.4 + T, 2.0, 0.7, "snow"))
        o.push(troll(22.5, 0, "snow"))
        o.push(troll(26.5, 1.2, "small"))
    }),

    // 15. Istappstornet
    winter("Icicle tower", ["pine", "acorn", "spruce", "pine"], [0, 20000, 29000], function (o) {
        var y = floor(o, 23.5, 0, 2.6, 2.0, "ice", "wood")
        o.push(troll(23.5, 0, "medium"))
        y = floor(o, 23.5, y, 2.2, 1.8, "ice", "wood")
        o.push(troll(23.5, y - 1.8 - T, "frost"))
        y = floor(o, 23.5, y, 1.8, 1.4, "ice")
        o.push(troll(23.5, y - 1.4 - T, "small"))
        o.push(troll(23.5, y, "frost"))
    }),

    // 16. Hoppbacken: trappsteg av klippa
    winter("Ski jump", ["spruce", "pine", "acorn"], [0, 13000, 18000], function (o) {
        o.push(rock(20.5, 0, 2.0, 1.0), rock(23.0, 0, 3.0, 2.0), rock(26.5, 0, 4.0, 3.2))
        o.push(block(20.5, 1.0, 0.9, 0.9, "snow"))
        o.push(troll(20.5, 1.9, "small"))
        floor(o, 23.0, 2.0, 1.8, 1.4, "wood", "snow")
        o.push(troll(23.0, 2.0, "frost"))
        floor(o, 26.5, 3.2, 2.0, 1.6, "ice", "wood")
        o.push(troll(26.5, 3.2, "medium"))
    }),

    // 17. Vedboden
    winter("Woodshed", ["acorn", "spruce", "chestnut", "spruce"], [0, 24000, 34000], function (o) {
        // Vedtravar av liggande klabbar
        for (var r = 0; r < 3; r++) {
            o.push(block(19.6, r * 0.48, 1.6, 0.48, "wood"))
            o.push(block(27.4, r * 0.48, 1.6, 0.48, "wood"))
        }
        o.push(troll(19.6, 1.44, "small"))
        o.push(troll(27.4, 1.44, "small"))
        var y = floor(o, 23.5, 0, 3.4, 2.2, "wood")
        o.push(troll(23.5, 0, "snow"))
        o.push(block(22.55, y, 0.5, 1.2, "snow"), block(24.45, y, 0.5, 1.2, "snow"))
        o.push(beam(23.5, y + 1.2, 2.6, "wood"))
        o.push(troll(23.5, y, "frost"))
    }),

    // 18. Frusna fästningen
    winter("Frozen fortress", ["acorn", "pine", "chestnut", "spruce"], [0, 28000, 40000], function (o) {
        o.push(block(19.8, 0, 0.6, 2.8, "stone"))
        var y = floor(o, 22.3, 0, 3.0, 2.0, "ice", "stone")
        o.push(troll(22.3, 0, "elder"))
        y = floor(o, 22.3, y, 2.4, 1.6, "ice", "wood")
        o.push(troll(22.3, y - 1.6 - T, "frost"))
        o.push(troll(22.3, y, "small"))
        o.push(block(25.0, 0, 0.6, 2.8, "stone"))
        o.push(beam(26.3, 2.8, 3.0, "ice"))
        o.push(block(27.6, 0, 0.6, 2.8, "stone"))
        o.push(troll(26.3, 0, "medium"))
        o.push(troll(26.3, 2.8 + T, "frost"))
    }),

    // 19. Norrskenstornet
    winter("Aurora tower", ["pine", "acorn", "chestnut", "pine", "spruce"], [0, 28000, 40000], function (o) {
        var y = floor(o, 24, 0, 2.8, 2.0, "stone", "wood")
        o.push(troll(24, 0, "large"))
        y = floor(o, 24, y, 2.4, 1.8, "wood")
        o.push(troll(24, y - 1.8 - T, "medium"))
        y = floor(o, 24, y, 2.0, 1.6, "ice", "wood")
        o.push(troll(24, y - 1.6 - T, "frost"))
        o.push(block(24, y, 1.4, 1.0, "snow"))
        o.push(troll(24, y + 1.0, "small"))
        o.push(block(19.5, 0, 1.0, 1.0, "snow"))
        o.push(troll(19.5, 1.0, "frost"))
    }),

    // 20. Vinterborgen
    winter("Winter castle", ["spruce", "pine", "acorn", "chestnut", "pine", "spruce"], [0, 36000, 51000], function (o) {
        floor(o, 17.5, 0, 2.0, 1.6, "ice", "snow")
        o.push(troll(17.5, 0, "frost"))
        o.push(rock(22.5, 0, 3.4, 1.4))
        var y = floor(o, 22.5, 1.4, 2.6, 2.0, "stone", "wood")
        o.push(troll(22.5, 1.4, "snow"))
        y = floor(o, 22.5, y, 2.0, 1.6, "ice", "wood")
        o.push(troll(22.5, y - 1.6 - T, "small"))
        o.push(troll(22.5, y, "frost"))
        var y3 = floor(o, 27.5, 0, 2.4, 2.4, "stone", "wood")
        floor(o, 27.5, y3, 2.0, 1.6, "snow", "wood")
        o.push(troll(27.5, 0, "elder"))
        o.push(troll(27.5, y3, "medium"))
    })
]
