.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Spelregler utan QML-beroenden: banan byggs upp i fysikvärlden, kottar
// skjuts, stötar ger skada, troll och block försvinner, poäng och stjärnor.
.import "Physics.js" as P

var WORLD_W = 29.5
var WORLD_H = 18
var SLING_X = 4.2
var SLING_Y = 3.3
var MAX_PULL = 2.2
var MAX_SPEED = 21
var DT = 1 / 60
var SETTLE_TIME = 1.2         // ingen skada medan banan sätter sig

// ---- Kottar ----------------------------------------------------------------
// ability: "none" | "split" | "dash" | "burst"
var CONES = {
    spruce:   { r: 0.32, density: 6,  ability: "none",  name: "Spruce cone" },
    pine:     { r: 0.28, density: 6,  ability: "split", name: "Pine cone" },
    acorn:    { r: 0.25, density: 10, ability: "dash",  name: "Acorn" },
    chestnut: { r: 0.36, density: 6,  ability: "burst", name: "Chestnut" }
}

// ---- Material och troll -----------------------------------------------------
var MATERIALS = {
    wood:  { density: 2.0, friction: 0.7, hp: 9,  score: 500 },
    stone: { density: 5.0, friction: 0.8, hp: 22, score: 1000 },
    ice:   { density: 1.5, friction: 0.15, hp: 4, score: 300 },
    snow:  { density: 0.9, friction: 0.5, hp: 3,  score: 200 },
    // Krutfat: smäller när det går sönder (men inte om det ramlar i vattnet)
    powder: { density: 1.2, friction: 0.6, hp: 3, score: 800, explosive: true },
    // Trollgrottan: droppsten och discokulan hänger i taket tills de träffas
    stalactite: { density: 4.0, friction: 0.7, hp: 12, score: 600 },
    discoball:  { density: 5.0, friction: 0.5, hp: 14, score: 2000 },
    chandelier: { density: 4.0, friction: 0.6, hp: 10, score: 1500 },
    // Trollen på månen: plåt från rymdbasen och månsten (som också kan sväva)
    metal:    { density: 3.0, friction: 0.5, hp: 14, score: 800 },
    moonrock: { density: 3.5, friction: 0.9, hp: 12, score: 700 },
    // Godisfabriken: gelé studsar, marshmallows är mjuka och tar emot stötar,
    // choklad är tung och tålig, polkagrisstänger fungerar som trä.
    jelly:       { density: 1.3, friction: 0.6, hp: 7,  score: 400, bounce: 0.7 },
    marshmallow: { density: 0.5, friction: 0.9, hp: 10, score: 300, soft: 0.25 },
    chocolate:   { density: 4.5, friction: 0.8, hp: 18, score: 900 },
    candycane:   { density: 2.2, friction: 0.6, hp: 10, score: 500 },
    // Luftslottet: ballonger spricker vid första stöten
    balloon:     { density: 0.3, friction: 0.5, hp: 1,  score: 300 },
    // Vulkanön: obsidian är hårt och halt vulkanglas. Glödande sten spricker
    // i en kaskad av gnistor som skadar allt runt omkring.
    obsidian:    { density: 4.0, friction: 0.4, hp: 14, score: 900 },
    magma:       { density: 3.5, friction: 0.8, hp: 5,  score: 1200, ember: true }
}

var KEG_RADIUS = 3.2          // krutfatets sprängradie (m)
var KEG_STRENGTH = 55
var EMBER_RADIUS = 2.4        // glödande stenens gnistregn: mindre än krutfatets smäll
var EMBER_STRENGTH = 34

var TROLLS = {
    small:  { r: 0.40, density: 2, hp: 4,  score: 5000 },
    medium: { r: 0.55, density: 2, hp: 8,  score: 5000 },
    large:  { r: 0.75, density: 2, hp: 14, score: 7000 },
    elder:  { r: 0.70, density: 2.5, hp: 20, score: 10000 },
    // Vinterskogen: frosttrollet är halt och glider av bjälkar,
    // snötrollet är stort och har tjock päls som tar emot en del av stöten.
    frost:  { r: 0.50, density: 2, hp: 7,  score: 6000, friction: 0.12, rolling: 9 },
    snow:   { r: 0.85, density: 2, hp: 18, score: 9000, armor: 0.7 },
    // Sjörövarviken: kaptenen med trekantig hatt
    captain: { r: 0.72, density: 2.5, hp: 16, score: 10000 },
    // Trollgrottan: diskjockeyn med hörlurar
    dj:      { r: 0.75, density: 2.5, hp: 18, score: 12000 },
    // Trollen på månen: befälhavaren i rymddräkt
    astronaut: { r: 0.75, density: 2.5, hp: 18, score: 12000 },
    // Godisfabriken: sockerbagaren med stor kockmössa
    baker:     { r: 0.75, density: 2.5, hp: 18, score: 12000 },
    // Tivolit: tivolits starke man, med tjocka armar som tar emot en del av stöten
    strongman: { r: 0.78, density: 2.5, hp: 20, score: 12000, armor: 0.8 },
    // Luftslottet: stormtrollet
    storm:     { r: 0.78, density: 2.5, hp: 20, score: 12000 },
    // Vulkanön: lavakungen med krona av obsidian och tjock, sotig hud
    lavaking:  { r: 0.8, density: 2.5, hp: 20, score: 12000, armor: 0.85 }
}

// Marken i varje värld
var GROUND = {
    forest: { friction: 0.9 },
    winter: { friction: 0.45 },
    // Havet: stranden slutar vid shore, längre ut är det vatten
    sea:    { friction: 0.7, shore: 11 },
    // Grottan: tak på 9,6 m höjd som kottarna studsar mot
    cave:   { friction: 0.8, ceiling: 9.6 },
    // Månen: låg gravitation och lägre utgångsfart, så att kottarna når lika långt
    // men flyger långsamt i höga bågar. Allt rasar i slow motion, så stötarna
    // räknas lite hårdare (damage). Trollen bär bubbelhjälm.
    moon:   { friction: 0.8, gravity: -3.6, speed: 13.2, damage: 1.25, helmets: true },
    // Godisfabriken: vanligt golv, det nya sitter i godiset
    candy:  { friction: 0.8 },
    // Tivolit: sågspån på marken. Det nya är studsmattor och åkattraktioner som rör sig.
    fair:   { friction: 0.8 },
    // Luftslottet: ekorren står på ett moln som slutar vid shore. Längre ut finns
    // bara luft: det som ramlar faller ned och försvinner (inget plask).
    sky:    { friction: 0.8, shore: 8.6, noWater: true },
    // Vulkanön: en lavasjö börjar vid shore. Det som ramlar i lavan brinner upp.
    volcano: { friction: 0.85, shore: 9.6, lava: true }
}

var BALLOON_RISE = 2.5        // m/s för ballonger som flyger iväg

var TRAMPOLINE_BOUNCE = 0.95  // studsmattorna skickar tillbaka nästan hela farten

var CRYSTAL_BOUNCE = 0.75     // studs mot kristaller

var HELMET_POP = 1.0          // så hård stöt (efter HIT_THRESHOLD) som spräcker en bubbelhjälm
var HIT_THRESHOLD = 1.2       // impulser under detta gör ingen skada
var CONE_BONUS = 3000         // per kotte som blir över

// ---- Ny omgång ---------------------------------------------------------------

function newGame(level) {
    var g = {
        level: level,
        world: P.makeWorld(),
        queue: level.cones.slice(),
        current: null,         // kotten i slangbellan eller i luften
        flying: [],            // alla kottar i rörelse (delning ger flera)
        state: "aim",          // aim | flying | waiting | won | lost
        score: 0,
        trolls: 0,
        events: [],
        time: 0,
        stateTime: 0,
        abilityUsed: false,
        pullX: 0, pullY: 0,
        rides: [],             // fasta kroppar som rör sig (tivolit)
        clock: 0               // tid för åkattraktionerna, går även efter vinst/förlust
    }
    // Marken
    var ground = GROUND[level.world || "forest"]
    if (ground.gravity !== undefined) g.world.gravity = ground.gravity
    g.gravity = ground.gravity !== undefined ? ground.gravity : P.GRAVITY
    g.maxSpeed = ground.speed || MAX_SPEED
    g.damageScale = ground.damage || 1
    g.helmets = !!ground.helmets
    g.shore = ground.shore !== undefined ? ground.shore : null
    g.noWater = !!ground.noWater
    g.lava = !!ground.lava
    // Vindbyar: rektanglar där kottarna får en extra acceleration (ax, ay)
    g.winds = (level.decor || []).filter(function (d) { return d.type === "wind" })
    g.rising = []
    g.ceiling = ground.ceiling !== undefined ? ground.ceiling : null
    if (g.ceiling !== null)
        P.addBody(g.world, P.makeBody({ shape: "box", x: WORLD_W / 2, y: g.ceiling + 1, w: 200, h: 2, isStatic: true,
                                        friction: 0.6, kind: "ceiling" }))
    if (g.shore !== null)
        P.addBody(g.world, P.makeBody({ shape: "box", x: g.shore - 100, y: -1, w: 200, h: 2, isStatic: true,
                                        friction: ground.friction, kind: "ground" }))
    else
        P.addBody(g.world, P.makeBody({ shape: "box", x: WORLD_W / 2, y: -1, w: 200, h: 2, isStatic: true,
                                        friction: ground.friction, kind: "ground" }))
    var items = level.items
    for (var i = 0; i < items.length; i++) addItem(g, items[i])
    loadNext(g)
    return g
}

function addItem(g, it) {
    var b
    if (it.troll) {
        var t = TROLLS[it.troll]
        // Hög vinkeldämpning fungerar som rullmotstånd: trollen står kvar
        b = P.makeBody({ shape: "circle", x: it.x, y: it.y + t.r, r: t.r, density: t.density,
                         friction: t.friction !== undefined ? t.friction : 0.8,
                         angularDamping: t.rolling !== undefined ? t.rolling : 12,
                         kind: "troll", data: { type: it.troll, hp: t.hp, maxHp: t.hp, helmet: g.helmets } })
        g.trolls++
    } else if (it.rock) {
        b = P.makeBody({ shape: "box", x: it.x, y: it.y + it.h / 2, w: it.w, h: it.h, isStatic: true,
                         angle: it.angle || 0,
                         friction: it.style === "trampoline" ? 0.3 : 0.9,
                         restitution: it.style === "crystal" ? CRYSTAL_BOUNCE : it.style === "trampoline" ? TRAMPOLINE_BOUNCE : 0,
                         kind: "rock", data: { style: it.style || "rock" } })
        // Åkattraktioner: fasta kroppar som flyttas varje steg (se moveRides)
        if (it.move) {
            b.data.move = JSON.parse(JSON.stringify(it.move))
            b.data.move.x0 = b.x; b.data.move.y0 = b.y
            g.rides.push(b)
        }
    } else if (it.ball) {
        var mb = MATERIALS[it.mat]
        b = P.makeBody({ shape: "circle", x: it.x, y: it.y + it.r, r: it.r, density: mb.density, friction: mb.friction,
                         angularDamping: 3,
                         kind: "block", data: { mat: it.mat, hp: mb.hp * Math.max(1, it.r * it.r * 4), maxHp: 0 } })
        b.data.maxHp = b.data.hp
    } else {
        var m = MATERIALS[it.mat]
        b = P.makeBody({ shape: "box", x: it.x, y: it.y + it.h / 2, w: it.w, h: it.h, angle: it.angle || 0,
                         density: m.density, friction: m.friction, restitution: m.bounce || 0,
                         kind: "block", data: { mat: it.mat, hp: m.hp * Math.max(1, it.w * it.h * 1.5), maxHp: 0 } })
        b.data.maxHp = b.data.hp
    }
    if (it.hang !== undefined) hang(b, it.hang)
    if (it.balloon !== undefined) b.data.balloon = true
    if (it.group !== undefined) b.data.group = it.group
    if (it.heldBy !== undefined) b.data.heldBy = it.heldBy
    if (it.string !== undefined) b.data.string = it.string
    if (it.float) b.data.floating = true      // svävar fritt (månen), ingen kedja
    P.addBody(g.world, b)
    g.events.push({ type: "add", body: b })
    return b
}

// Hänger i taket: står still (som om den satt fast) tills något träffar den.
// chain är kedjans längd i meter mellan taket och föremålets ovansida.
function hang(b, chain) {
    b.data.hanging = true
    b.data.chain = chain
    b.data.saved = { invMass: b.invMass, invI: b.invI }
    b.invMass = 0; b.invI = 0
}

function release(g, b) {
    if (!b.alive || !b.data.hanging) return
    b.data.hanging = false
    b.invMass = b.data.saved.invMass; b.invI = b.data.saved.invI
    b.vx = 0; b.vy = -0.5
    g.events.push({ type: "release", body: b })
}

function loadNext(g) {
    g.abilityUsed = false
    g.pullX = 0; g.pullY = 0
    if (g.queue.length === 0) { g.current = null; return false }
    var type = g.queue.shift()
    var c = CONES[type]
    // Kotten ligger i slangbellan men är inte med i fysiken förrän den skjuts
    g.current = P.makeBody({ shape: "circle", x: SLING_X, y: SLING_Y, r: c.r, density: c.density,
                             friction: 0.5, restitution: 0.25, kind: "cone", data: { type: type, launched: false, still: 0, age: 0 } })
    g.events.push({ type: "load", body: g.current })
    g.state = "aim"
    g.stateTime = 0
    return true
}

// ---- Sikte och skott -------------------------------------------------------

// Sätter hur långt kotten dras bakåt (relativt slangbellan). Returnerar
// kottens position.
function aim(g, dx, dy) {
    if (g.state !== "aim" || !g.current) return null
    var d = Math.sqrt(dx * dx + dy * dy)
    if (d > MAX_PULL) { dx *= MAX_PULL / d; dy *= MAX_PULL / d }
    // Kotten får inte dras ned genom marken
    if (SLING_Y + dy < g.current.r) dy = g.current.r - SLING_Y
    g.pullX = dx; g.pullY = dy
    g.current.x = SLING_X + dx
    g.current.y = SLING_Y + dy
    return { x: g.current.x, y: g.current.y }
}

function launchVelocity(dx, dy, maxSpeed) {
    var d = Math.sqrt(dx * dx + dy * dy)
    if (d < 1e-6) return { vx: 0, vy: 0 }
    var s = (maxSpeed || MAX_SPEED) * Math.min(1, d / MAX_PULL)
    return { vx: -dx / d * s, vy: -dy / d * s }
}

// Banan som kotten skulle ta (utan hinder), för de prickade punkterna.
function trajectory(g, count, every) {
    var v = launchVelocity(g.pullX, g.pullY, g.maxSpeed)
    var x = SLING_X + g.pullX, y = SLING_Y + g.pullY, vx = v.vx, vy = v.vy
    var out = []
    var ld = 1 / (1 + DT * P.LINEAR_DAMPING)
    for (var i = 1; i <= count * every; i++) {
        vy += DT * g.gravity
        vx *= ld; vy *= ld
        x += DT * vx; y += DT * vy
        if (y < 0 || (g.ceiling !== null && y > g.ceiling)) break
        if (i % every === 0) out.push({ x: x, y: y })
    }
    return out
}

function launch(g) {
    if (g.state !== "aim" || !g.current) return false
    var d = Math.sqrt(g.pullX * g.pullX + g.pullY * g.pullY)
    if (d < 0.35) {            // för lite drag: lägg tillbaka
        aim(g, 0, 0)
        return false
    }
    var v = launchVelocity(g.pullX, g.pullY, g.maxSpeed)
    var c = g.current
    c.vx = v.vx; c.vy = v.vy
    c.w = -v.vx * 0.8
    c.data.launched = true
    P.addBody(g.world, c)
    g.flying = [c]
    g.state = "flying"
    g.stateTime = 0
    g.events.push({ type: "launch", body: c })
    return true
}

// Tryck under flygningen: kottens förmåga.
function useAbility(g) {
    if (g.state !== "flying" || g.abilityUsed || !g.current || !g.current.alive) return false
    var c = g.current, type = c.data.type, ab = CONES[type].ability
    if (ab === "none") return false
    g.abilityUsed = true
    if (ab === "split") {
        var sp = P.speed(c), ang = Math.atan2(c.vy, c.vx)
        for (var k = -1; k <= 1; k += 2) {
            var a = ang + k * 0.22
            var n = P.makeBody({ shape: "circle", x: c.x, y: c.y + k * 0.05, r: c.r, density: c.density, friction: 0.5,
                                 restitution: 0.25, kind: "cone",
                                 data: { type: type, launched: true, still: 0, age: c.data.age, child: true } })
            n.vx = Math.cos(a) * sp; n.vy = Math.sin(a) * sp; n.w = c.w
            P.addBody(g.world, n)
            g.flying.push(n)
            g.events.push({ type: "add", body: n })
        }
    } else if (ab === "dash") {
        var s = P.speed(c)
        if (s > 0.1) { var f = Math.min(36, s * 2.2) / s; c.vx *= f; c.vy *= f }
        // Ekollonet blir tyngre i farten och slår igenom trä
        c.data.dash = true
    } else if (ab === "burst") {
        burst(g, c)
    }
    g.events.push({ type: "ability", body: c, ability: ab })
    return true
}

function burst(g, c) {
    var hit = P.explode(g.world, c.x, c.y, 3.0, 50)
    for (var i = 0; i < hit.length; i++) {
        var b = hit[i].body
        if (b === c) continue
        damage(g, b, hit[i].power * 0.2, c.x, c.y)
    }
    g.events.push({ type: "burst", x: c.x, y: c.y })
    removeCone(g, c)
}

// ---- Skada -----------------------------------------------------------------

function damage(g, b, amount, x, y) {
    if (!b.alive || (b.kind !== "troll" && b.kind !== "block")) return
    if (b.data.balloon && b.data.hanging) { popBalloon(g, b); return }
    // Bubbelhjälmen tar hela stöten. En hård stöt spräcker den.
    if (b.kind === "troll" && b.data.helmet) {
        if (amount >= HELMET_POP) {
            b.data.helmet = false
            g.events.push({ type: "pop", body: b, x: b.x, y: b.y + b.r * 0.4 })
        }
        return
    }
    if (b.kind === "troll" && TROLLS[b.data.type].armor) amount *= TROLLS[b.data.type].armor
    b.data.hp -= amount
    g.events.push({ type: "hurt", body: b })
    if (b.data.hp <= 0) destroy(g, b, x, y)
}

function destroy(g, b, x, y, splash) {
    if (!b.alive) return
    var pts = 0
    if (b.kind === "troll") { pts = TROLLS[b.data.type].score; g.trolls-- }
    else if (b.kind === "block") pts = MATERIALS[b.data.mat].score
    P.removeBody(g.world, b)
    g.score += pts
    g.events.push({ type: "destroy", body: b, points: pts, x: b.x, y: b.y, splash: !!splash })
    if (!splash && b.kind === "block" && MATERIALS[b.data.mat].explosive) explodeKeg(g, b)
    if (!splash && b.kind === "block" && MATERIALS[b.data.mat].ember) emberBurst(g, b)
    // En plattform som ballonger höll har gått sönder: ballongerna flyger iväg
    if (b.data.heldBy !== undefined) freeGroup(g, b.data.heldBy)
}

// Krutfatet smäller: knuffar och skadar allt runt omkring (och kan tända andra fat)
function explodeKeg(g, keg) {
    var hit = P.explode(g.world, keg.x, keg.y, KEG_RADIUS, KEG_STRENGTH)
    g.events.push({ type: "explode", x: keg.x, y: keg.y })
    for (var i = 0; i < hit.length; i++) {
        var b = hit[i].body
        if (b.kind === "cone") continue
        damage(g, b, hit[i].power * 0.25, keg.x, keg.y)
    }
}

// Den glödande stenen spricker: gnistor och het sten skadar det som står nära
// (och kan få andra glödande stenar att spricka)
function emberBurst(g, rock) {
    var hit = P.explode(g.world, rock.x, rock.y, EMBER_RADIUS, EMBER_STRENGTH)
    g.events.push({ type: "ember", x: rock.x, y: rock.y })
    for (var i = 0; i < hit.length; i++) {
        var b = hit[i].body
        if (b.kind === "cone") continue
        damage(g, b, hit[i].power * 0.25, rock.x, rock.y)
    }
}

function inWater(g, b) {
    return g.shore !== null && !g.noWater && b.x > g.shore + 0.2 && b.y < -0.15
}

// ---- Luftslottet: ballonger och vind -------------------------------------------

// En ballong har spruckit: plattformarna den höll faller, och gruppens andra
// ballonger flyger iväg uppåt.
function popBalloon(g, b) {
    if (!b.alive) return
    var group = b.data.group
    destroy(g, b, b.x, b.y)
    g.events.push({ type: "balloon", x: b.x, y: b.y })
    freeGroup(g, group)
}

// Släpp allt i en ballonggrupp: plattformen faller och ballongerna flyger iväg.
function freeGroup(g, group) {
    var bodies = g.world.bodies.slice()
    for (var i = 0; i < bodies.length; i++) {
        var o = bodies[i]
        if (!o.alive || !o.data) continue
        if (o.data.heldBy === group && o.data.hanging) release(g, o)
        else if (o.data.balloon && o.data.group === group && o.data.hanging) {
            o.data.hanging = false
            o.data.chain = 0
            o.vy = BALLOON_RISE
            g.rising.push(o)
            g.events.push({ type: "hurt", body: o })
        }
    }
}

function blowWind(g) {
    for (var i = 0; i < g.flying.length; i++) {
        var c = g.flying[i]
        for (var k = 0; k < g.winds.length; k++) {
            var w = g.winds[k]
            if (c.x >= w.x0 && c.x <= w.x1 && c.y >= w.y0 && c.y <= w.y1) {
                c.vx += (w.ax || 0) * DT
                c.vy += (w.ay || 0) * DT
            }
        }
    }
}

function removeCone(g, c) {
    if (c.alive) P.removeBody(g.world, c)
    c.alive = false
    var i = g.flying.indexOf(c)
    if (i >= 0) g.flying.splice(i, 1)
    g.events.push({ type: "remove", body: c })
}

function _handleHits(g, hits) {
    if (g.time < SETTLE_TIME) return
    for (var i = 0; i < hits.length; i++) {
        var h = hits[i], imp = h.impulse
        if (imp < HIT_THRESHOLD) continue
        var a = h.a, b = h.b
        // Det som hänger i taket lossnar när det träffas
        // Ballonger spricker; plattformar som en ballong håller lossnar bara när ballongen spricker
        if (a.data && a.data.balloon) { popBalloon(g, a); continue }
        if (b.data && b.data.balloon) { popBalloon(g, b); continue }
        if (a.data && a.data.hanging && a.data.heldBy === undefined) release(g, a)
        if (b.data && b.data.hanging && b.data.heldBy === undefined) release(g, b)
        // Kristallerna studsar kotten tillbaka
        if ((a.kind === "rock" && a.data.style === "crystal" && b.kind === "cone") ||
            (b.kind === "rock" && b.data.style === "crystal" && a.kind === "cone"))
            g.events.push({ type: "ping", x: h.x, y: h.y })
        var amount = (imp - HIT_THRESHOLD) * g.damageScale
        // Ekollon i full fart slår extra hårt
        if ((a.kind === "cone" && a.data.dash) || (b.kind === "cone" && b.data.dash)) amount *= 1.6
        // Godis: gelé studsar och marshmallows tar emot stöten
        var ma = a.kind === "block" ? MATERIALS[a.data.mat] : null
        var mb = b.kind === "block" ? MATERIALS[b.data.mat] : null
        var amountA = amount, amountB = amount
        // (marshmallown själv trycks ihop men går nästan inte sönder: knuffa bort den i stället)
        if (mb && mb.soft) { amountA *= mb.soft; amountB *= 0.15 }
        if (ma && ma.soft) { amountB *= ma.soft; amountA *= 0.15 }
        if (amount > 1 && ((ma && ma.bounce) || (mb && mb.bounce))) g.events.push({ type: "boing", x: h.x, y: h.y })
        if (imp > 2 && ((a.kind === "rock" && a.data.style === "trampoline") || (b.kind === "rock" && b.data.style === "trampoline")))
            g.events.push({ type: "boing", x: h.x, y: h.y })
        if (amount > 1 && ((ma && ma.soft) || (mb && mb.soft))) g.events.push({ type: "squish", x: h.x, y: h.y })
        if (a.kind !== "cone") damage(g, a, amountA, h.x, h.y)
        if (b.kind !== "cone") damage(g, b, amountB, h.x, h.y)
        if (amount > 2) g.events.push({ type: "impact", x: h.x, y: h.y, power: amount })
    }
}

// ---- Uppdatering -------------------------------------------------------------

function update(g, dt) {
    var steps = Math.max(1, Math.min(4, Math.round(dt / DT)))
    for (var s = 0; s < steps; s++) _step(g)
}

// ---- Åkattraktioner -------------------------------------------------------------
// Fasta kroppar (invMass = 0) som flyttas: farten sätts så att kroppen hamnar rätt
// efter steget. Motorn flyttar alla kroppar med sin fart, och friktionen mot farten
// gör att det som står på en plattform följer med.
//   line:   p = start + (ax, ay) · sin(2π t / period + phase)
//   circle: p = (cx, cy) + r · (cos θ, sin θ) + (ox, oy), θ = 2π t / period + phase
// Kroppen vrids aldrig, så en gondol hänger alltid rakt.
function ridePos(m, t) {
    var a = 2 * Math.PI * t / m.period + (m.phase || 0)
    if (m.type === "circle") return { x: m.cx + m.r * Math.cos(a) + (m.ox || 0), y: m.cy + m.r * Math.sin(a) + (m.oy || 0) }
    var s = Math.sin(a) - Math.sin(m.phase || 0)
    return { x: m.x0 + (m.ax || 0) * s, y: m.y0 + (m.ay || 0) * s }
}

function moveRides(g) {
    for (var i = 0; i < g.rides.length; i++) {
        var b = g.rides[i], p = ridePos(b.data.move, g.clock + DT)
        b.vx = (p.x - b.x) / DT
        b.vy = (p.y - b.y) / DT
        b.w = 0
    }
    g.clock += DT
}

// Står allt still? Det som åker med en attraktion (rör den, eller något som rör den)
// räknas som stilla, annars skulle spelet vänta i onödan efter varje skott.
function settled(g, limit) {
    if (g.rides.length === 0) return P.isSettled(g.world, limit)
    var riding = {}, queue = g.rides.slice(), k
    for (k = 0; k < queue.length; k++) riding[queue[k].id] = true
    while (queue.length > 0) {
        var r = queue.pop()
        for (k in g.world.arbiters) {
            var arb = g.world.arbiters[k], o = arb.a === r ? arb.b : arb.b === r ? arb.a : null
            if (o && o.invMass > 0 && !riding[o.id] && o.y > r.y) { riding[o.id] = true; queue.push(o) }
        }
    }
    var bodies = g.world.bodies
    for (var i = 0; i < bodies.length; i++) {
        var b = bodies[i]
        if (b.invMass === 0 || riding[b.id]) continue
        if (P.speed(b) > limit || Math.abs(b.w) > limit * 2) return false
    }
    return true
}

function _step(g) {
    if (g.rides.length > 0) moveRides(g)
    if (g.winds.length > 0) blowWind(g)
    // Ballonger som flyger iväg försvinner ovanför skärmen
    for (var r = g.rising.length - 1; r >= 0; r--) {
        if (g.rising[r].y > WORLD_H + 2) { P.removeBody(g.world, g.rising[r]); g.events.push({ type: "remove", body: g.rising[r], silent: true }); g.rising.splice(r, 1) }
    }
    if (g.state === "won" || g.state === "lost") {
        P.step(g.world, DT)
        return
    }
    var hits = P.step(g.world, DT)
    g.time += DT
    g.stateTime += DT
    _handleHits(g, hits)

    // Troll och block som ramlar utanför världen
    for (var i = g.world.bodies.length - 1; i >= 0; i--) {
        var b = g.world.bodies[i]
        if (b.invMass === 0) continue
        if (inWater(g, b)) {
            // Plask! Det som ramlar i havet sjunker
            g.events.push({ type: "splash", lava: g.lava, x: b.x, y: 0, size: b.shape === "circle" ? b.r * 2 : Math.max(b.hw, b.hh) * 2 })
            if (b.kind === "cone") removeCone(g, b)
            else destroy(g, b, b.x, 0, true)
        } else if (b.y < -4 || b.x < -6 || b.x > WORLD_W + 8) {
            if (b.kind === "cone") removeCone(g, b)
            else destroy(g, b, b.x, b.y)
        }
    }

    // Kottar som stannat eller flugit länge försvinner
    for (i = g.flying.length - 1; i >= 0; i--) {
        var c = g.flying[i]
        c.data.age += DT
        c.data.still = P.speed(c) < 0.3 ? c.data.still + DT : 0
        if (c.data.still > 1.0 || c.data.age > 9) removeCone(g, c)
    }

    if (g.state === "flying" && g.flying.length === 0) { g.state = "waiting"; g.stateTime = 0 }

    // Alla troll borta: vänta en kort stund (eller tills allt lugnat sig) och vinn
    if (g.trolls === 0) {
        g.clearTime = (g.clearTime || 0) + DT
        if (g.clearTime > 2.5 || (g.clearTime > 0.8 && settled(g, 0.25))) {
            var left = g.queue.length + (g.current && !g.current.data.launched ? 1 : 0)
            var bonus = left * CONE_BONUS
            g.score += bonus
            g.state = "won"
            g.events.push({ type: "won", bonus: bonus, left: left })
        }
        return
    }

    // Allt har lugnat sig efter skottet: nästa kotte, eller förlust om de är slut
    if (g.state === "waiting" && (settled(g, 0.25) || g.stateTime > 6)) {
        if (!loadNext(g)) {
            g.state = "lost"
            g.events.push({ type: "lost" })
        }
    }
}

function stars(level, score) {
    var s = 0
    for (var i = 0; i < level.stars.length; i++) if (score >= level.stars[i]) s = i + 1
    return s
}

function takeEvents(g) {
    var e = g.events
    g.events = []
    return e
}
