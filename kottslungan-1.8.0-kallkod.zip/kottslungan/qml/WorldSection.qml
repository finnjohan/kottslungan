// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Levels.js" as Levels

// En värld i banvalet: en liten bild av landskapet med namn och stjärnor,
// och under den ett rutnät med världens banor.
Column {
    id: section
    property var world: null
    readonly property string worldId: world ? world.id : ""
    readonly property bool open: world !== null && root.unlocked(world.first)
    spacing: units.gu(1)

    Item {
        width: parent.width
        height: units.gu(8)
        Rectangle {
            id: bannerMask
            anchors.fill: parent
            radius: units.gu(1.5)
            clip: true
            color: "transparent"
            Scenery {
                width: parent.width; height: units.gu(16)
                y: parent.height - height * 0.88
                groundY: height * 0.84
                night: root.isDark
                world: section.worldId
                opacity: section.open ? 1 : 0.55
            }
        }
        Label {
            anchors { left: parent.left; leftMargin: units.gu(2); verticalCenter: parent.verticalCenter }
            text: section.world ? root.tr(section.world.name) : ""
            textSize: Label.Large
            font.weight: Font.Bold
            color: "#FFFFFF"
            style: Text.Outline; styleColor: section.worldId === "winter" ? "#2A4A66" : section.worldId === "sea" ? "#1B3E66" : section.worldId === "cave" ? "#3A1E52" : section.worldId === "moon" ? "#1B2440" : section.worldId === "candy" ? "#A83A78" : section.worldId === "fair" ? "#8A1A1E" : section.worldId === "sky" ? "#2A5A9A" : section.worldId === "volcano" ? "#7A2410" : "#2E5A2A"
        }
        Row {
            anchors { right: parent.right; rightMargin: units.gu(2); verticalCenter: parent.verticalCenter }
            spacing: units.gu(0.8)
            Icon {
                anchors.verticalCenter: parent.verticalCenter
                width: units.gu(2.6); height: width
                name: section.open ? "starred" : "lock"
                color: section.open ? "#F2B705" : "#FFFFFF"
            }
            Label {
                anchors.verticalCenter: parent.verticalCenter
                text: !section.world ? ""
                      : section.open ? root.worldStars(section.world) + " / " + section.world.count * 3
                      : root.tr("Clear level %1 to open").arg(section.world.first - 1)
                font.weight: Font.Bold
                color: "#FFFFFF"
                style: Text.Outline; styleColor: section.worldId === "winter" ? "#2A4A66" : section.worldId === "sea" ? "#1B3E66" : section.worldId === "cave" ? "#3A1E52" : section.worldId === "moon" ? "#1B2440" : section.worldId === "candy" ? "#A83A78" : section.worldId === "fair" ? "#8A1A1E" : section.worldId === "sky" ? "#2A5A9A" : section.worldId === "volcano" ? "#7A2410" : "#2E5A2A"
            }
        }
    }

    Grid {
        id: grid
        width: parent.width
        columns: Math.max(3, Math.floor(width / units.gu(16)))
        readonly property real cellW: width / columns
        Repeater {
            model: section.world ? section.world.count : 0
            Item {
                width: grid.cellW; height: units.gu(14)
                readonly property int n: section.world.first + index
                readonly property bool open: root.unlocked(n)
                readonly property bool winter: section.worldId === "winter"
                readonly property bool sea: section.worldId === "sea"
                readonly property bool cave: section.worldId === "cave"
                readonly property bool moon: section.worldId === "moon"
                readonly property bool candy: section.worldId === "candy"
                readonly property bool fair: section.worldId === "fair"
                readonly property bool sky: section.worldId === "sky"
                readonly property bool volcano: section.worldId === "volcano"
                AbstractButton {
                    anchors { fill: parent; margins: units.gu(0.8) }
                    enabled: parent.open
                    onClicked: root.playLevel(parent.n)
                    Rectangle {
                        anchors.fill: parent
                        radius: units.gu(1.5)
                        color: !parent.parent.open ? theme.palette.normal.base
                               : parent.parent.winter ? (root.isDark ? "#24404F" : "#E4F0F8")
                               : parent.parent.sea ? (root.isDark ? "#1F3550" : "#FBF0D9")
                               : parent.parent.cave ? (root.isDark ? "#2E1E42" : "#EFE2F7")
                               : parent.parent.moon ? (root.isDark ? "#1E2233" : "#E6E8EE")
                               : parent.parent.candy ? (root.isDark ? "#45203E" : "#FCE4F0")
                               : parent.parent.fair ? (root.isDark ? "#3E1E22" : "#FFF0D8")
                               : parent.parent.sky ? (root.isDark ? "#1E2E4E" : "#E4F2FF")
                               : parent.parent.volcano ? (root.isDark ? "#3E1A14" : "#FFE6D4")
                               : (root.isDark ? "#2F4A30" : "#E3F1DA")
                        border.color: !parent.parent.open ? theme.palette.normal.base
                                      : parent.parent.winter ? "#5E8FB0" : parent.parent.sea ? "#2F7DB4" : parent.parent.cave ? "#8A5CA8" : parent.parent.moon ? "#6E7A9A" : parent.parent.candy ? "#E0609E" : parent.parent.fair ? "#D8383E" : parent.parent.sky ? "#5A9AD8" : parent.parent.volcano ? "#E0541E" : "#5E8F4A"
                        border.width: units.dp(2)
                        opacity: parent.parent.open ? 1 : 0.6
                    }
                    Column {
                        anchors.centerIn: parent
                        width: parent.width - units.gu(1)
                        spacing: units.gu(0.4)
                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: parent.parent.parent.n
                            textSize: Label.XLarge
                            font.weight: Font.Bold
                        }
                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                            text: root.tr(Levels.list[parent.parent.parent.n - 1].name)
                            textSize: Label.Small
                        }
                        Item {
                            anchors.horizontalCenter: parent.horizontalCenter
                            readonly property int n: parent.parent.parent.n
                            width: lock.visible ? lock.width : levelStars.width
                            height: units.gu(2.2)
                            Stars { id: levelStars; visible: !lock.visible; count: root.starsFor(parent.n); size: units.gu(2.2) }
                            Icon { id: lock; visible: !root.unlocked(parent.n); name: "lock"; width: units.gu(2.2); height: width
                                   color: theme.palette.normal.backgroundSecondaryText }
                        }
                    }
                }
            }
        }
    }
}
